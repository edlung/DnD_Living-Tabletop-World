import { createRequire } from 'node:module';
const require = createRequire('/Users/oleksandr/Documents/living-tabletop-world-dev-pack-v1.2/');
const { chromium } = require('@playwright/test');
const SP = new URL('./', import.meta.url).pathname;
const URL0 = 'file://' + SP + 'demo/preview.html';
const [w, h, tag, ...steps] = process.argv.slice(2);
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: +w, height: +h }, deviceScaleFactor: 1 });
p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') console.log('console', m.type(), m.text()); });
p.on('pageerror', (e) => console.log('pageerror', e.message));
await p.goto(URL0 + (steps[0] && steps[0].startsWith('#') ? steps.shift() : ''));
await p.waitForLoadState('networkidle');
await p.evaluate(() => { Math.random = () => 0.72; });
let n = 0;
for (const s of steps) {
  if (s === 'shot') { await p.waitForTimeout(250); await p.screenshot({ path: `${SP}shots/${tag}-${++n}.png` }); continue; }
  await p.evaluate((a) => { const e = document.querySelector(`[data-a="${a}"]`); if (!e) throw new Error('no ' + a); e.dispatchEvent(new MouseEvent('click', { bubbles: true })); }, s);
}
await p.waitForTimeout(250);
await p.screenshot({ path: `${SP}shots/${tag}-${++n}.png` });
console.log('ok', tag, n);
await b.close();
