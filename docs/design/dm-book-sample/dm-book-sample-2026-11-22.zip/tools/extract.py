#!/usr/bin/env python3
"""Pulls the campaign data the DM book demo shows, verbatim, into demo/data.js."""
import json, sys
from pathlib import Path
R = Path('/Users/oleksandr/Documents/living-tabletop-world-dev-pack-v1.2/campaigns')
OUT = Path(sys.argv[1])
def J(p): return json.loads((R / p).read_text())
def sheet(pkg, key):
    e = next(x for x in pkg['entities'] if x['key'] == key)
    s = e.get('sheet')
    if s: return {'ac': s['armorClass'], 'hp': s['hitPoints']['max'], 'abilities': s['abilities'], 'skills': s['skills']['proficient'], 'weapons': s['weapons'], 'cls': s['classes'][0]['classId'], 'level': s['classes'][0]['level'], 'slots': s['spellSlots']['max'], 'spells': [x for sc in s['spellcasting'] for x in sc['spells']], 'cast': (s['spellcasting'][0]['ability'] if s['spellcasting'] else None)}
    b = e['statBlock']
    return {'name': e['name'], 'description': e.get('description', ''), 'ac': b['armorClass'], 'hp': b['hitPoints']['max'], 'init': b['initiativeBonus'], 'attacks': b['attacks']}
def camp(dir_, sessions, world_keys):
    pkg = J(f'{dir_}/package.json'); cast = J(f'{dir_}/source/cast.json'); world = J(f'{dir_}/source/world.json')
    clues = J(f'{dir_}/source/clues.json'); hand = J(f'{dir_}/source/handouts.json')
    clues = clues if isinstance(clues, list) else clues.get('clues', clues)
    hand = hand if isinstance(hand, list) else hand.get('handouts', hand)
    party = pkg['party']
    SP = json.loads(Path('/Users/oleksandr/Documents/living-tabletop-world-dev-pack-v1.2/packages/rules/src/srd/ru/spells.json').read_text())
    heroes = [dict(h, sheet=sheet(pkg, h['key'])) for h in cast['heroes'] if h['key'] in party]
    encs = []
    for e in pkg['encounters']:
        foes = [sheet(pkg, c['entity']) for c in e['combatants'] if c['side'] != 'party']
        fi = iter(range(99))
        pos = [{'id': (c['entity'] if c['side'] == 'party' else 'foe%d' % next(fi)), 'x': c['position']['x'], 'y': c['position']['y']} for c in e['combatants']]
        encs.append({k: e.get(k) for k in ('key', 'title', 'location', 'trigger', 'objective', 'tactics', 'peaceful', 'defeat', 'battlefield')} | {'foes': foes, 'pos': pos})
    ids = sorted({x for h in heroes for x in h['sheet']['spells']})
    spells = {i: {k: SP[i]['ru'][k] for k in ('name', 'castingTime', 'description')} for i in ids}
    return {'spells': spells, 'brief': {k: pkg['brief'].get(k) for k in ('intent', 'tone', 'duration', 'include', 'exclude')}, 'meet': {k: world.get(k) for k in ('sessionDuration', 'sessionCount', 'audience', 'defaultPlayers', 'recurring')}, 'world': {k: world.get(k) for k in world_keys}, 'locations': world['locations'], 'chapters': [{'n': s['number'], 'title': s['title'], 'location': s['location'], 'goal': s['goal']} for s in sessions],
            'npcs': cast['npcs'], 'heroes': heroes, 'clues': clues, 'handouts': hand, 'encounters': encs}
lh_s = sum((J(f'lighthouse/source/act-{i}.json') for i in range(1, 5)), [])
lh = camp('lighthouse', lh_s, ['title', 'pitch', 'tone', 'safety', 'progression', 'order', 'routes'])
lh['e1'] = lh_s[0]; lh['e2'] = lh_s[1]; lh['acts'] = lh_s
lh['pins'] = J('lighthouse/source/world-map.json')['pins']; lh['beats'] = J('lighthouse/source/table-routes.json')['chapters']
out = {'lh': lh}
for k, d in (('rc', 'noir-2026/rain-check'), ('mc', 'dark-fantasy-2026/marrow-crown')):
    ss = sum((J(f'{d}/source/sessions-{i}.json') for i in range(1, 5)), [])
    c = camp(d, ss, ['title', 'genre', 'audience', 'pitch', 'tone', 'tableGuidance', 'boundaries'])
    c['e1'] = ss[0]
    out[k] = c
OUT.write_text('window.DATA = ' + json.dumps(out, ensure_ascii=False, separators=(',', ':')) + ';\n')
print(OUT, OUT.stat().st_size, {k: [len(v['npcs']), len(v['heroes']), len(v['clues']), len(v['handouts']), len(v['encounters'])] for k, v in out.items()})
