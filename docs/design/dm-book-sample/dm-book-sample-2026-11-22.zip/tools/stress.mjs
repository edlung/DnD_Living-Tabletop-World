// Plays fights at random in all three books and reports any script error.
import { createRequire } from 'node:module';
const require = createRequire('/Users/oleksandr/Documents/living-tabletop-world-dev-pack-v1.2/');
const { chromium } = require('@playwright/test');
const SP = new URL('./', import.meta.url).pathname;
const b = await chromium.launch(); const errs = [];
for (const [hash, pre, fid] of [['#lh', ['next', 'next', 'next'], 's3-keepers'], ['#mc', ['next', 'next'], 'm-sitters']]) for (let run = 0; run < 12; run++) {
  const p = await b.newPage({ viewport: { width: 1180, height: 820 } });
  p.on('pageerror', (e) => errs.push(`${hash} run ${run}: ${e.message}`));
  await p.goto('file://' + SP + 'demo/preview.html' + hash); await p.waitForLoadState('domcontentloaded');
  const out = await p.evaluate(([pre, fid, run]) => {
    const click = (a) => { const e = document.querySelector(`[data-a="${a}"]`) || document.querySelector(`[data-a^="${a}"]`); if (!e) return false; e.dispatchEvent(new MouseEvent('click', { bubbles: true })); return true; };
    click('openbook'); if (run % 4 === 3) { click('gsel:' + window.__book.st.meet.sel); const k = Object.keys(window.DATA[window.__book.st.skin].heroes)[0]; const hk = window.DATA[window.__book.st.skin].heroes[0].key; click('gsel:' + hk); click('seat:' + hk); }
    click('start'); pre.forEach(click); click('open:' + fid); click('fight:' + fid);
    let steps = 0, seen = new Set();
    while (window.__book.st.fight && steps++ < 400) {
      const f = window.__book.st.fight;
      if (f.over) { seen.add('over:' + f.over); click('fend'); break; }
      if (f.offer) { seen.add('offer'); click(Math.random() < 0.5 ? 'fstand:0' : 'fstand:1'); continue; }
      if (Math.random() < 0.1) { click('fmap'); click('tok:'); click('cell:'); click('fmap'); }
      const acts = [...document.querySelectorAll('[data-a^="fact:"]:not([disabled])')];
      if (acts.length && Math.random() < 0.6) acts[Math.floor(Math.random() * acts.length)].click();
      const t = [...document.querySelectorAll('[data-a^="ftarget:"]')];
      if (t.length) { t[Math.floor(Math.random() * t.length)].click(); seen.add('target'); }
      else if (click('fcast')) seen.add('cast'); else if (click('fnext')) seen.add('next'); else click('pass');
      for (const x of window.__book.st.fight ? window.__book.st.fight.list : []) { if (x.side === 'party' && x.hp <= 0) seen.add('down'); if (x.stable) seen.add('stable'); if (x.fate) seen.add('fate'); }
    }
    return [steps, [...seen].join(','), window.__book.st.journal.map((j) => j.text).slice(-1)[0]];
  }, [pre, fid, run]);
  console.log(hash, run, JSON.stringify(out));
  await p.close();
}
console.log(errs.length ? 'ERRORS\n' + errs.join('\n') : 'no script errors');
await b.close();
