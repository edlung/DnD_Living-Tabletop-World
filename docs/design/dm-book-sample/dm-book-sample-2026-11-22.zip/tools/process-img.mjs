// Builds demo/img from campaign runtime art, the lighthouse table skin and the DM book originals. Rerunnable.
import { createRequire } from 'node:module';
import { existsSync, readdirSync, writeFileSync, readFileSync } from 'node:fs';
const require = createRequire('/Users/oleksandr/Documents/living-tabletop-world-dev-pack-v1.2/');
const sharp = require('sharp');
const [dst] = process.argv.slice(2);
const HOME = process.env.HOME;
const C = '/Users/oleksandr/Documents/living-tabletop-world-dev-pack-v1.2/campaigns/';
const DIRS = { lh: C + 'lighthouse/assets/', rc: C + 'noir-2026/rain-check/assets/', mc: C + 'dark-fantasy-2026/marrow-crown/assets/' };
const NEW = HOME + '/Documents/living-tabletop-world-art/dm-book-2026-11-22/out/';
const OLD = HOME + '/Documents/living-tabletop-world-art/lighthouse-table-skin-2026-11-21/out/';
const data = JSON.parse(readFileSync(dst + '/../data.js', 'utf8').replace(/^window\.DATA = /, '').replace(/;\s*$/, ''));
const names = { lh: new Set(), rc: new Set(), mc: new Set() };
const put = async (skin, name, src, kind) => {
  if (!existsSync(src)) return false;
  const out = `${dst}/${skin}-${name}.webp`;
  let s = sharp(src);
  if (kind === 'scene') s = s.resize({ width: 1280, withoutEnlargement: true }).webp({ quality: 72 });
  else if (kind === 'place') s = s.resize({ width: 960, withoutEnlargement: true }).webp({ quality: 70 });
  else if (kind === 'face') s = s.resize(480, 480, { fit: 'cover', position: 'top' }).webp({ quality: 78 });
  else if (kind === 'object') s = s.resize({ width: 720, withoutEnlargement: true }).webp({ quality: 80, alphaQuality: 90 });
  else if (kind === 'icon') s = s.trim().resize(192, 192, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp({ quality: 86, alphaQuality: 92 });
  else if (kind === 'tile') s = s.resize(512, 512).webp({ quality: 80 });
  else if (kind === 'divider') s = s.trim().resize({ width: 900 }).webp({ quality: 86, alphaQuality: 92 });
  else if (kind === 'emblem') s = s.trim().resize(320, 320, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp({ quality: 86, alphaQuality: 92 });
  else if (kind === 'small') s = s.trim().resize({ width: 256 }).webp({ quality: 86, alphaQuality: 92 });
  await s.toFile(out); names[skin].add(name); return true;
};
for (const skin of ['lh', 'rc', 'mc']) {
  const d = data[skin], rt = DIRS[skin] + 'runtime/';
  await put(skin, 'cover', rt + 'cover.webp', 'scene');
  for (const p of [...d.npcs, ...d.heroes]) (await put(skin, p.key, rt + p.key + '.webp', 'face')) || (await put(skin, p.key, DIRS[skin] + 'table/npcs-' + p.key + '.webp', 'face'));
  for (const l of d.locations) await put(skin, 'at-' + l.key, rt + (l.art || l.key) + '.webp', 'place');
  for (const e of d.encounters) await put(skin, 'bm-' + e.location, DIRS[skin] + 'battle-maps/' + e.location + '.webp', 'scene');
}
for (const n of ['harbor', 'ship']) await put('lh', n, DIRS.lh + 'runtime/' + n + '.webp', 'scene');
await put('lh', 'automaton', DIRS.lh + 'runtime/automaton.webp', 'object');
await put('lh', 'notebook', DIRS.lh + 'runtime/notebook.webp', 'icon');
for (const n of ['rain-cemetery']) await put('rc', n, DIRS.rc + 'runtime/' + n + '.webp', 'scene');
for (const n of ['crowd-photo', 'duck-umbrella', 'hire-envelope', 'police-card', 'savely-umbrella']) await put('rc', n, DIRS.rc + 'runtime/' + n + '.webp', 'object');
for (const n of ['salt-mouth', 'hanging-teeth', 'breath-stairs']) await put('mc', n, DIRS.mc + 'runtime/' + n + '.webp', 'scene');
for (const n of ['token-hollowed', 'fat-lamp', 'stas-rope', 'irma-hook']) await put('mc', n, DIRS.mc + 'runtime/' + n + '.webp', 'object');
// lighthouse table skin (2026-11-21)
for (const n of ['ico-dice', 'ico-fight', 'ico-rest', 'ico-map', 'ico-box', 'ico-clock']) await put('lh', n, OLD + n + '.png', 'icon');
await put('lh', 'ui-paper', OLD + 'ui-paper.png', 'tile'); await put('lh', 'ui-cover', OLD + 'ui-cloth.png', 'tile');
await put('lh', 'ui-divider', OLD + 'ui-divider.png', 'divider'); await put('lh', 'ui-emblem', OLD + 'ui-emblem.png', 'emblem'); await put('lh', 'ui-corner', OLD + 'ui-corner.png', 'small');
await put('lh', 'ev-lantern', OLD + 'puzzle-lantern.png', 'scene');
await put('lh', 'ev-wind', OLD + 'puzzle-wind.png', 'scene');
await put('lh', 'ui-break', OLD + 'ui-break.png', 'scene');
await put('lh', 'world-map', DIRS.lh + 'world-map/world-map.webp', 'scene');
// DM book originals (2026-11-22)
for (const f of readdirSync(NEW).filter((x) => x.endsWith('.png'))) {
  const [, skin, name] = f.match(/^(lh|rc|mc)-(.+)\.png$/);
  const kind = name.startsWith('ev-') ? 'scene' : name.startsWith('ico-') ? 'icon' : name === 'ui-paper' || name === 'ui-cover' ? 'tile' : name === 'ui-divider' ? 'divider' : name === 'ui-emblem' ? 'emblem' : 'small';
  await put(skin, name, NEW + f, kind);
}
writeFileSync(dst + '/../img.js', 'window.IMG = ' + JSON.stringify(Object.fromEntries(Object.entries(names).map(([k, v]) => [k, [...v].sort()]))) + ';\n');
console.log(Object.entries(names).map(([k, v]) => `${k}: ${v.size}`).join(', '));
