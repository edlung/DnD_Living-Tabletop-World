import { createRequire } from 'node:module';
import { auditPage } from '/Users/oleksandr/.claude/skills/ui-layout-audit/audit.mjs';
const require = createRequire('/Users/oleksandr/Documents/living-tabletop-world-dev-pack-v1.2/');
const { chromium } = require('@playwright/test');
const SP = new URL('./', import.meta.url).pathname;
const URL0 = 'file://' + SP + 'demo/preview.html';
const S = {
  'lh-cover': ['#lh'], 'lh-gather': ['#lh', 'openbook'], 'lh-gather-hero': ['#lh', 'openbook', 'gsel:tess', 'seat:tess'], 'lh-meet': ['#lh', 'next', 'meet', 'tick', 'tick', 'tick', 'tick'], 'lh-pace': ['#lh', 'next', 'next', 'meet', 'tick', 'tick', 'tick', 'tick', 'close'], 'lh-cover2': ['#lh', 'openbook', 'start', 'next', 'next', 'open:s2-receipt', 'done:s2-receipt,Отряд нашёл', 'meet', 'closebook'], 'lh-gather2': ['#lh', 'openbook', 'gsel:tess', 'seat:tess', 'gsel:today', 'start', 'next', 'next', 'open:s2-receipt', 'done:s2-receipt,Отряд нашёл', 'meet', 'closebook', 'openbook'], 'rc-cover': ['#rc'], 'mc-gather': ['#mc', 'openbook'],
  'lh-open': ['#lh'], 'lh-brief': ['#lh', 'next'], 'lh-talk': ['#lh', 'next', 'open:s1-baker'], 'lh-nodice': ['#lh', 'next', 'open:s1-napkin', 'roll:s1-napkin,finn'],
  'lh-check': ['#lh', 'next', 'next', 'open:s2-lantern', 'roll:s2-lantern,tess'], 'lh-puzzle': ['#lh', 'next', 'next', 'open:s2-puzzle', 'hint:s2-puzzle'], 'lh-clue': ['#lh', 'next', 'next', 'open:s2-receipt'], 'lh-free': ['#lh', 'next', 'freeopen', 'fskill:athletics'], 'lh-banner': ['#lh', 'next', 'next', 'next', 'open:s3-keepers', 'fight:s3-keepers', 'open:s3-log'],
  'lh-fork': ['#lh', 'next', 'next', 'next', 'open:s3-ways', 'pick:s3-ways,1'], 'lh-show': ['#lh', 'next', 'next', 'next', 'open:s3-ticket', 'paper:s3-ticket'], 'lh-fightcard': ['#lh', 'next', 'next', 'next', 'open:s3-keepers'],
  'lh-fight': ['#lh', 'next', 'next', 'next', 'open:s3-keepers', 'fight:s3-keepers'], 'lh-fhit': ['#lh', 'next', 'next', 'next', 'open:s3-keepers', 'fight:s3-keepers', 'ftarget:foe0'], 'lh-fstand': ['#lh', 'next', 'next', 'next', 'open:s3-keepers', 'fight:s3-keepers', 'ftarget:foe0', 'fnext', 'ftarget:foe0'], 'lh-fheal': ['#lh', 'next', 'next', 'next', 'open:s3-keepers', 'fight:s3-keepers', 'ftarget:foe0', 'fnext', 'ftarget:foe0', 'fstand:0', 'fnext', 'fact:healing-word', 'ftarget:finn'], 'lh-fmap': ['#lh', 'next', 'next', 'next', 'open:s3-keepers', 'fight:s3-keepers', 'fmap', 'tok:tess', 'cell:5,3'], 'lh-ffoe': ['#lh', 'next', 'next', 'next', 'open:s3-keepers', 'fight:s3-keepers', 'ftarget:foe1', 'fnext', 'pass', 'pass', 'fnext'], 'lh-end': ['#lh', 'next', 'next', 'next', 'next', 'endcard', 'end:e-end'], 'lh-toc': ['#lh', 'toc'], 'lh-2s2': ['#lh', 'toc', 'toc', 'next', 'next', 'next', 'next', 'endcard', 'end:e-end', 'goch:2', 'next', 'next', 'open:2b-wind', 'roll:2b-wind,finn'], 'lh-route': ['#lh', 'toc', 'toc', 'next', 'next', 'next', 'next', 'endcard', 'end:e-end', 'goch:2', 'next', 'next', 'next', 'open:2c-route', 'tocsel:4'], 'lh-2end': ['#lh', 'toc', 'toc', 'next', 'next', 'next', 'next', 'endcard', 'end:e-end', 'goch:2', 'next', 'next', 'next', 'open:2c-route', 'tocsel:5', 'fly:5', 'endcard', 'end:e2-end'], 'lh-isle': ['#lh', 'toc', 'toc', 'next', 'next', 'next', 'next', 'endcard', 'end:e-end', 'goch:2', 'next', 'next', 'next', 'open:2c-route', 'tocsel:4', 'fly:4', 'endcard', 'end:e2-end', 'goch:4'], 'lh-route2': ['#lh', 'toc', 'toc', 'next', 'next', 'next', 'next', 'endcard', 'end:e-end', 'goch:2', 'next', 'next', 'next', 'open:2c-route', 'tocsel:4', 'fly:4', 'endcard', 'end:e2-end', 'goch:4', 'playdemo:4', 'tocsel:10'], 'lh-peek': ['#lh', 'toc', 'tocsel:1', 'page:3'],
  'lh-heroes': ['#lh', 'tab:heroes'], 'lh-npcs': ['#lh', 'tab:npcs'], 'lh-places': ['#lh', 'tab:places'], 'lh-threads': ['#lh', 'tab:threads'], 'lh-things': ['#lh', 'tab:things'], 'lh-rules': ['#lh', 'tab:rules'],
  'lh-journal': ['#lh', 'next', 'open:s1-baker', 'done:s1-baker,Поговорили', 'open:s1-fork', 'pick:s1-fork,1', 'roll:s1-napkin,finn', 'tab:journal'], 'lh-about': ['#lh', 'about'],
  'rc-open': ['#rc'], 'rc-s1': ['#rc', 'next', 'open:r-portrait'], 'rc-fork': ['#rc', 'next', 'open:r-fork1'], 'rc-s2': ['#rc', 'next', 'next', 'open:r-klara'], 'rc-npcs': ['#rc', 'tab:npcs'], 'rc-things': ['#rc', 'tab:things'],
  'mc-open': ['#mc'], 'mc-s1': ['#mc', 'next', 'open:m-exhale'], 'mc-fightcard': ['#mc', 'next', 'next', 'open:m-sitters'], 'mc-fight': ['#mc', 'next', 'next', 'open:m-sitters', 'fight:m-sitters'], 'mc-fmap': ['#mc', 'next', 'next', 'open:m-sitters', 'fight:m-sitters', 'fmap'], 'mc-heroes': ['#mc', 'tab:heroes'], 'mc-rules': ['#mc', 'tab:rules'],
};
const args = process.argv.slice(2);
const widths = (args.find((a) => a.startsWith('--w=')) || '--w=1440,1024,768,390').slice(4).split(',').map(Number);
const only = args.filter((a) => !a.startsWith('--'));
const names = only.length ? only : Object.keys(S);
const H = { 1180: 820, 1440: 900, 1024: 768, 768: 1024, 390: 844, 2560: 1300, 320: 640 };
const browser = await chromium.launch();
const tally = {};
for (const w of widths) for (const name of names) {
  const ctx = await browser.newContext({ viewport: { width: w, height: H[w] }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message)); page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  const [hash, ...rest] = S[name]; const steps = /cover|gather/.test(name) ? rest : ['openbook', 'start', ...rest];
  await page.goto(URL0 + hash); await page.waitForLoadState('networkidle');
  await page.evaluate(() => { Math.random = () => 0.72; });
  for (const a of steps) await page.evaluate((x) => { const e = document.querySelector(`[data-a="${x}"]`); if (!e) throw new Error('no ' + x); e.dispatchEvent(new MouseEvent('click', { bubbles: true })); }, a);
  await page.waitForTimeout(250);
  const res = await auditPage(page, { interactive: false });
  const items = Array.isArray(res) ? res : (res.findings || res.issues || []);
  const lines = items.map((f) => `${f.level || ''} ${f.rule} @ ${String(f.where).slice(0, 80)} :: ${String(f.detail).slice(0, 170)}`);
  for (const f of items) tally[f.rule] = (tally[f.rule] || 0) + 1;
  if (lines.length || errs.length) { console.log(`\n== ${name} ${w} == ${lines.length} findings ${errs.length ? 'ERRORS ' + errs.join('|') : ''}`); console.log(lines.slice(0, 10).join('\n')); }
  await page.screenshot({ path: `${SP}audit/${name}-${w}.png` });
  await ctx.close();
}
await browser.close();
console.log('\nTALLY', JSON.stringify(tally));
