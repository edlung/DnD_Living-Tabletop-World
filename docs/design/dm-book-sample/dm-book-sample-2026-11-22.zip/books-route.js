// Chapter 2 of the lighthouse and the free route after it: pages, links and the campaign's own rules of order.
// Same sources as books.js: 'c' campaign verbatim, 'w' written by Sonnet 5.5 (lh-text2.js), 'b' the book's own line.
(function () {
  const D = window.DATA, T = window.LHTEXT2, B = window.BOOKS.lh, lh = D.lh, miss = window.BOOK_MISS;
  const by = (arr, key) => arr.find((x) => x.key === key);
  const seg = (t, a, b) => { const i = a ? t.indexOf(a) : 0; const j = b ? t.indexOf(b, i + 1) : t.length; if (i < 0 || j < 0) { miss.push(['seg', a, b]); return ''; } return t.slice(i, j).trim(); };
  const quote = (t, a) => { const i = t.indexOf('«' + a); if (i < 0) { miss.push(['quote', a]); return ''; } return t.slice(i + 1, t.indexOf('»', i)); };
  const mark = (t, pairs) => { for (const [ph, id] of pairs) { if (!t.includes(ph)) miss.push(['mark', ph]); t = t.replace(ph, `[[${id}|${ph}]]`); } return t; };
  const c = (t) => ({ t, src: 'c' }), b = (t) => ({ t, src: 'b' }), w = (id) => ({ t: T.words[id], src: 'w' });
  const pre = (paras, p) => paras.map((t) => ({ t: t.replace(/\[\[/g, '[[' + p + '-'), src: 'w' }));
  const personRows = (p) => [['Как выглядит', p.look], ['Чего хочет', p.want], ['Как говорит', p.voice], ['Граница', p.boundary]].filter((r) => r[1]).map(([k, v]) => ({ k, v, src: 'c' }));
  const place = (k) => by(lh.locations, k).name;
  const e2 = lh.e2, S = e2.scenes, acts = lh.acts;
  const runa = by(lh.npcs, 'runa'), spool = by(lh.npcs, 'spool');
  const cPlate = by(lh.clues, 'route-plate'), cLabel = by(lh.clues, 'courier-label');
  const hKey = by(lh.handouts, 'handout-runa-letter'), hRoute = by(lh.handouts, 'handout-route');
  const other = e2.consequences.find((x) => x.if.includes('другой остров'));

  B.route = {
    start: [1, 2], free: [3, 4, 5, 6, 7, 8], tail: [9, 10, 11, 12], order: lh.world.order,
    tailWhy: 'Совет созывают, когда отряд решит, что видел достаточно. В кампании: «' + seg(lh.world.order, 'Не запирайте путь') + '»',
    gate: { 10: 'В кампании условие одно: «' + lh.world.routes.find((r) => r[1] === 'winter')[2] + '».' },
    skip: seg(acts[8].scenes[0].play, 'Пропущенный остров', ' Каждый игрок'),
  };

  const open2 = B.pages.find((p) => p.id === 'lh-2-open');
  delete open2.brief.demoEnd;
  const ahead = { 3: { t: c(e2.end), img: 'at-orchard' }, 4: { t: w('end-library'), img: 'at-library' }, 5: { t: w('end-market'), img: 'at-market' } };
  const pages2 = [
    { id: 'lh-2-s1', chapter: 2, kind: 'scene', title: S[0].title, place: 'ship', img: 'ship', imgLevel: 'place', imgCap: place('ship'),
      paras: pre(T.scenes.scene1, '2a'), fork: '2a-fork',
      brief: { lead: seg(S[0].play, 'Обязанности меняются', ' Прочитайте'), rows: [['Броски', S[0].check], ['Если игрок не выбирает', S[0].failForward], ['Время', `${S[0].minutes} минут`]] } },
    { id: 'lh-2-s2', chapter: 2, kind: 'scene', title: S[1].title, place: 'ship', img: 'ev-wind', imgLevel: 'scene', imgCap: S[1].title,
      paras: pre(T.scenes.scene2, '2b'), fork: '2b-fork',
      brief: { lead: seg(S[1].play, 'Покажите две карты', ' Команда может'), rows: [['Броски', S[1].check], ['Если не вышло', S[1].failForward], ['Время', `${S[1].minutes} минут`]] } },
    { id: 'lh-2-s3', chapter: 2, kind: 'scene', title: S[2].title, place: 'ship', img: 'ship', imgLevel: 'place', imgCap: place('ship'),
      paras: pre(T.scenes.scene3, '2c'), fork: '2c-route',
      brief: { lead: seg(S[2].play, 'Игроки могут ответить', ' Затем выбирают'), rows: [['Броски', S[2].check], ['Если потеряли кассету', S[2].failForward], ['Ведущему', e2.dmNote], ['Время', `${S[2].minutes} минут`]] } },
    { id: 'lh-2-end', chapter: 2, kind: 'end', title: 'Курс проложен', place: 'ship', img: 'ship', imgLevel: 'place', imgCap: place('ship'),
      paras: [b('Куда полетит «Чайник»? Последний кадр главы появится здесь, когда игроки выберут остров.')], fork: '2c-route', offText: ['e2-end'],
      dyn(st) {
        const d = st.dest; if (!d) return {};
        const a = ahead[d], ch = lh.chapters.find((x) => x.n === d);
        if (!a) return { paras: [b(`Игроки выбрали главу ${d}, «${ch.title}». Последнего кадра для такого выбора в кампании нет: расскажите его сами.`)] };
        return { paras: [a.t], img: a.img, imgLevel: 'event', imgCap: 'Впереди: ' + place(ch.location) };
      },
      brief: { lead: 'Последний кадр главы книга подбирает под остров, который выбрали игроки. В кампании он написан только для сада; для библиотеки и базара кадр дописан по описанию места.', rows: [['Если выбрали не сад', other.then], ['Отдых', e2.rest]] } },
  ];
  const npcOf = { 3: ['pom', 'Пом тихо добавляет', ['И позавчера тоже']], 4: ['saffra', 'говорит Сафра', ['Прекрасно']], 5: ['vey', 'Вей раскрывает три кармана', ['Редчайшая точность!']] };
  const islands = [3, 4, 5].map((n) => {
    const e = acts[n - 1], [who, phrase] = npcOf[n];
    return { id: `lh-${n}-open`, chapter: n, kind: 'opening', title: e.title, place: e.location, img: 'at-' + e.location, imgLevel: 'place', imgCap: place(e.location),
      paras: [c(mark(e.readAloud, [[phrase, `i${n}-${who}`]]))],
      brief: { lead: e.goal, rows: [['Сколько играть', e.duration], ['Ведущему', e.dmNote]], demoEnd: true, demoPlay: true } };
  });
  const at = B.pages.indexOf(open2);
  B.pages.splice(at + 1, 0, ...pages2, ...islands);

  Object.assign(B.links, {
    '2a-corner': { t: 'check', title: 'Свой уголок и обязанность', nodice: seg(S[0].check, 'Вклад каждого'), yes: w('corner-done') },
    '2a-letter': { t: 'show', title: hKey.title, paper: hKey.text, task: hKey.task },
    '2a-fork': { t: 'fork', title: 'Чем занята команда?', options: [{ label: S[0].choices[0], go: '2a-corner' }, { label: S[0].choices[1], go: '2a-letter' }, { label: S[0].choices[2], result: S[0].choices[2] }] },
    '2b-plate': { t: 'clue', clue: 'route-plate', title: cPlate.name, say: w('plate-look'), look: c(cPlate.appearance), means: c(cPlate.statement), how: c(seg(S[1].play, 'Покажите две карты', ' Команда может')) },
    '2b-wind': { t: 'check', title: 'Проверить путь', img: 'ev-wind', imgCap: 'Заблудившийся ветер', skills: [['survival', 'Выживание'], ['investigation', 'Расследование']], dc: 11, when: c(seg(S[1].check, 'ускоряет выход', '; при неудаче')), yes: w('wind-yes'), no: w('wind-no') },
    '2b-puzzle': { t: 'puzzle', title: 'Три подвески', img: 'ev-wind', imgCap: 'Три подвески', ask: c(e2.puzzle.prompt), solution: c(e2.puzzle.solution), hints: e2.puzzle.hints },
    '2b-runa': { t: 'talk', who: 'runa', title: 'Руна на сигнальной лампе', img: 'runa', imgCap: runa.name, face: true, lines: [w('runa-lamp-1'), w('runa-lamp-2')], rows: personRows(runa), knows: runa.knows, secret: runa.secret, reveal: runa.reveal },
    '2b-fork': { t: 'fork', title: 'Как команда проверяет путь?', options: [{ label: S[1].choices[0], go: '2b-wind' }, { label: S[1].choices[1], gap: 'Слов для парома в книге нет: кампания называет его одной строкой, без людей на борту. Расскажите сами.', result: 'Спросили дорогу у парома' }, { label: S[1].choices[2], go: '2b-wind' }] },
    '2c-spool': { t: 'talk', who: 'spool', title: 'Шпуль спрашивает про дом', img: 'spool', imgCap: spool.name, face: true, lines: [w('spool-home-1'), w('spool-home-2')], rows: personRows(spool), knows: spool.knows, secret: spool.secret, reveal: spool.reveal },
    '2c-label': { t: 'clue', clue: 'courier-label', title: cLabel.name, say: w('label-look'), look: c(cLabel.appearance), means: c(cLabel.statement), how: c(S[2].check) },
    '2c-sound': { t: 'check', title: 'Первый звук путешествия', nodice: seg(S[2].play, 'Игроки могут ответить', ' Затем выбирают'), yes: w('sound-done') },
    '2c-pom': { t: 'clue', title: 'Письмо садовника', img: 'pom', imgCap: by(lh.npcs, 'pom').name, face: true, say: w('pom-letter'), means: c(seg(S[2].play, 'Садовник прислал')), how: c(other.then), done: 'Прочитали', gap: 'Текста письма в кампании нет: есть только строка о нём.' },
    '2c-route': { t: 'fork', title: 'Куда летим дальше?', route: true },
    'e2-end': { t: 'rest', title: 'Итоги главы', rewards: e2.reward, rest: e2.rest, consequences: e2.consequences },
  });
  for (const n of [3, 4, 5]) {
    const [who, , quotes] = npcOf[n], p = by(lh.npcs, who), e = acts[n - 1];
    B.links[`i${n}-${who}`] = { t: 'talk', who, title: p.name, img: who, imgCap: p.name, face: true, lines: quotes.map((q) => c(quote(e.readAloud, q))), rows: personRows(p), knows: p.knows, secret: p.secret, reveal: p.reveal };
  }
  B.links['n-spool'].lines = [c(quote(e2.readAloud, 'Команда укомплектована'))];
})();
// Words for stopping a meeting early and for a hero whose player is away (lh-text3.js, written earlier, src 'w').
(function () {
  const T = window.LHTEXT3, B = window.BOOKS.lh;
  B.stops = Object.fromEntries(Object.entries(T.stop).map(([k, t]) => [k, { t, src: 'w' }]));
  B.away = Object.fromEntries(Object.entries(T.away).map(([k, t]) => [k, { t, src: 'w' }]));
})();
// How a fight is played in each book: what zero hit points means, and the keepers' fight words (lh-text4.js, src 'w').
(function () {
  const BK = window.BOOKS, W = window.LHTEXT4, k = BK.lh.links['s3-keepers'], enc = window.DATA.lh.encounters.find((e) => e.key === 'dock-keepers');
  BK.lh.down = 'out'; BK.rc.down = 'stable'; BK.mc.down = 'saves';
  k.words = W;
  k.ends = { t: enc.trigger.slice(enc.trigger.indexOf('Мирные пути')), src: 'c' };
  k.fewFoes = 1;   // the demo's own rule: with two heroes at the table one keeper blocks the way
  const m = BK.mc.links['m-sitters'];
  m.ends = m.peace;
})();
