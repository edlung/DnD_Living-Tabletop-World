// The DM book: one engine, three books. State is per book; every action re-renders the open spread.
(function () {
  'use strict';
  const D = window.DATA, BOOKS = window.BOOKS, IMG = window.IMG;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : '');
  const fin = (s) => (/[.!?…»"]$/.test(s.trim()) ? s : s.trim() + '.');
  const d = (n) => 1 + Math.floor(Math.random() * n);
  const mod = (score) => Math.floor((score - 10) / 2);
  const sign = (n) => (n >= 0 ? '+' + n : '−' + Math.abs(n));

  const G = {
    talk: '<path d="M3 3.5h10a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H8.5L5 13.5v-3H3a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1z"/>',
    check: '<path d="M8 1.6l5.5 3.2v6.4L8 14.4l-5.5-3.2V4.8z"/><path d="M8 5.2l2.8 4.6H5.2z"/>',
    fight: '<path d="M2.5 2.5l7.5 7.5M13.5 2.5L6 10M3.2 9.4l3.4 3.4M12.8 9.4l-3.4 3.4M4.4 11.6l-2 2M11.6 11.6l2 2"/>',
    puzzle: '<circle cx="5.2" cy="8" r="2.7"/><path d="M7.9 8h6.3M11.6 8v2.6M14.2 8v2"/>',
    clue: '<circle cx="6.8" cy="6.8" r="4.2"/><path d="M10 10l4 4"/>',
    show: '<rect x="2" y="3.5" width="12" height="9" rx="1"/><path d="M2.4 4.6L8 8.8l5.6-4.2"/>',
    fork: '<path d="M8 14V9M8 9L3.8 3.8M8 9l4.2-5.2M3.8 3.8h2.6M3.8 3.8v2.6M12.2 3.8H9.6M12.2 3.8v2.6"/>',
    rest: '<path d="M13 10.2A5.6 5.6 0 0 1 5.8 3 5.6 5.6 0 1 0 13 10.2z"/>',
    tv: '<rect x="1.8" y="3" width="12.4" height="8.4" rx="1"/><path d="M5.5 13.5h5"/>',
    left: '<path d="M10 3L5 8l5 5"/>', right: '<path d="M6 3l5 5-5 5"/>', x: '<path d="M4 4l8 8M12 4l-8 8"/>', list: '<path d="M3 4h10M3 8h10M3 12h10"/>', ok: '<path d="M3 8.5l3.2 3.2L13 4.8"/>',
  };
  const gl = (k) => `<svg class="gl" viewBox="0 0 16 16" aria-hidden="true">${G[k]}</svg>`;
  const TYPES = {
    talk: { label: 'Диалог', ico: 'ico-talk', what: 'говорит персонаж: его слова, чего он хочет, что знает и что скрывает' },
    check: { label: 'Бросок', ico: 'ico-dice', what: 'действие героя: нужен ли бросок, какой навык и сложность, слова для успеха и провала' },
    fight: { label: 'Бой', ico: 'ico-fight', what: 'когда начинается, как его обойти, кто противники; отсюда же бой ведётся' },
    puzzle: { label: 'Загадка', ico: 'ico-puzzle', what: 'вопрос игрокам, разгадка для ведущего и подсказки по одной' },
    clue: { label: 'Находка', ico: 'ico-clue', what: 'что видят герои, что это значит и как это находят; найденное уходит в закладку «Находки»' },
    show: { label: 'Раздатка', ico: 'ico-letter', what: 'письмо, билет или лист, который выдают игрокам в руки или выводят на экран стола' },
    fork: { label: 'Развилка', ico: 'ico-fork', what: 'выбор игроков: книга открывает нужную карточку или страницу' },
    rest: { label: 'Конец главы', ico: 'ico-rest', what: 'последние слова, награды, отдых и что запомнит мир' },
  };
  const TABS = [['story', 'История', 'ui-emblem'], ['heroes', 'Герои', 'ico-fight'], ['npcs', 'Лица', 'ico-talk'], ['places', 'Места', 'ico-fork'], ['threads', 'Находки', 'ico-clue'], ['things', 'Раздатки', 'ico-letter'], ['rules', 'Правила', 'ico-dice'], ['journal', 'Журнал', 'ico-rest']];
  const LH_TAB = { story: 'notebook', places: 'ico-map', journal: 'ico-clock' };
  const SKILL = { athletics: 'str', acrobatics: 'dex', stealth: 'dex', 'sleight-of-hand': 'dex', perception: 'wis', investigation: 'int', insight: 'wis', persuasion: 'cha', deception: 'cha', intimidation: 'cha', survival: 'wis', medicine: 'wis', arcana: 'int', history: 'int', nature: 'int' };
  const SKILL_RU = { athletics: 'Атлетика', acrobatics: 'Акробатика', stealth: 'Скрытность', 'sleight-of-hand': 'Ловкость рук', perception: 'Восприятие', investigation: 'Расследование', insight: 'Проницательность', persuasion: 'Убеждение', deception: 'Обман', intimidation: 'Запугивание', survival: 'Выживание', medicine: 'Медицина', arcana: 'Магия', history: 'История', nature: 'Природа' };
  const WEAPON = { longsword: ['длинный меч', 8, 'str'], handaxe: ['топорик', 6, 'str'], quarterstaff: ['боевой посох', 6, 'str'], shortsword: ['короткий меч', 6, 'fin'], dagger: ['кинжал', 4, 'fin'], mace: ['булава', 6, 'str'], rapier: ['рапира', 8, 'fin'], shortbow: ['короткий лук', 6, 'dex'], 'light-crossbow': ['лёгкий арбалет', 8, 'dex'], scimitar: ['скимитар', 6, 'fin'], warhammer: ['боевой молот', 8, 'str'], spear: ['копьё', 6, 'str'], club: ['дубинка', 4, 'str'] };
  const CLASS_RU = { fighter: 'воин', rogue: 'плут', cleric: 'жрец', wizard: 'волшебник', bard: 'бард', ranger: 'следопыт', druid: 'друид', paladin: 'паладин', monk: 'монах', sorcerer: 'чародей', warlock: 'колдун', barbarian: 'варвар' };
  const FREE = '_free', MEET = '_meet';

  const fresh = (skin) => ({ skin, tab: 'story', page: 0, toc: false, tocSel: 1, open: null, sheet: false, sel: {}, played: {}, found: {}, journal: [], tv: null, rolls: {}, actor: {}, hints: {}, picked: {}, fight: null, fview: false, free: { hero: null, dc: 10, res: null }, name: '', notes: '', seen: false, done: {}, order: 0, deferred: {}, opened: {}, mark: 0, dest: null, slots: {}, mode: 'cover', meet: { n: 1, length: 150, min: 0, paused: false, present: {}, sel: 'today' }, last: null });
  const states = {};
  let st, about = false, toTop = false;
  const B = () => BOOKS[st.skin];
  const C = () => D[st.skin];
  const has = (n) => IMG[st.skin].includes(n);
  const src = (n) => `img/${st.skin}-${n}.webp`;
  const ico = (t) => src(TYPES[t].ico);
  const page = () => { const p = B().pages[st.page]; return p.dyn ? { ...p, ...p.dyn(st) } : p; };
  const link = (id) => B().links[id];
  const placeName = (key) => (C().locations.find((l) => l.key === key) || {}).name || '';
  const hero = (key) => C().heroes.find((h) => h.key === key);
  const first = (name) => name.split(' ')[0];
  const person = (key) => C().npcs.find((n) => n.key === key);
  const chap = (n) => `${B().chapterWord} ${n}`;
  const party = () => B().party.filter((k) => st.meet.present[k] !== false);   // heroes whose players came today
  const hm = (m) => `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}`;

  /* ── words ── */
  const tag = (o) => (o && o.src === 'w' ? '<sup class="w" title="Дописано для книги, ещё не вычитано">✎</sup>' : '');
  const withHero = (t, id) => t.replace(/\{H\}/g, st.actor[id] ? first(hero(st.actor[id]).name) : 'Герой');
  const sayb = (label, o, id, cls = '') => (o && o.t ? `<div class="sayb ${cls}"><span class="who">${esc(label)}</span><p>${esc(fin(cap(withHero(o.t, id))))}${tag(o)}</p></div>` : '');
  const rows = (list) => { const r = list.filter((x) => x && x[1]); return r.length ? `<dl class="rows">${r.map(([k, v]) => `<div class="r"><dt>${esc(k)}</dt><dd>${esc(cap(v))}</dd></div>`).join('')}</dl>` : ''; };
  const noted = (id) => (st.played[id] !== undefined ? `<span class="done-note">${gl('ok')}В журнале: ${esc(st.played[id])}</span>` : '');
  const quiet = (t) => `<span class="done-note mute">${esc(t)}</span>`;

  /* ── state changes ── */
  const jot = (id, type, title, text) => { st.journal = st.journal.filter((j) => j.id !== id || id === FREE); st.journal.push({ id, page: st.page, type, title, text }); };
  const play = (id, text) => { const l = link(id); st.played[id] = text; jot(id, l.t, l.title, text); if (l.clue) st.found[l.clue] = true; };
  const showTv = (pic) => { st.tv = pic; };
  const pagePic = (p) => ({ src: src(p.img), cap: p.imgCap, level: p.imgLevel, kind: p.imgFace ? 'face' : '' });
  const turnTo = (i, move) => { st.page = i; st.open = null; st.sheet = false; st.fview = false; st.toc = false; st.tab = 'story'; if (move) st.mark = i; if (st.page === st.mark) showTv(pagePic(page())); };
  /* ── the route: which chapters the party can reach, from the campaign's own data ── */
  const R = () => B().route;
  const chOf = (n) => C().chapters.find((c) => c.n === n);
  const act = (n) => (C().acts || [])[n - 1];
  const firstPage = (n) => B().pages.findIndex((p) => p.chapter === n);
  const lastPage = (n) => B().pages.reduce((k, p, i) => (p.chapter === n ? i : k), -1);
  const markCh = () => B().pages[st.mark].chapter;
  const beenIn = () => [...new Set([...Object.keys(st.done).map(Number), markCh()])];   // chapters played, and the one the ribbon is in
  const learned = () => { const keys = new Set(Object.keys(st.found)); beenIn().forEach((n) => ((act(n) || {}).clues || []).forEach((k) => keys.add(k))); return C().clues.filter((c) => keys.has(c.key)); };
  const knownOf = (loc) => learned().filter((x) => x.subjects.includes(loc) && x.location !== loc);
  function reach(n) {
    const r = R(), c = chOf(n), last = r && r.start[r.start.length - 1];
    if (!r || st.done[n]) return { ok: true, why: '' };
    if (st.opened[n]) return { ok: true, why: 'Ведущий открыл главу сам.' };
    if (r.start.includes(n)) return { ok: n === r.start[0] || !!st.done[n - 1], why: 'Начало истории: эти главы идут подряд.' };
    if (r.free.includes(n)) {
      if (!beenIn().includes(last)) return { ok: false, why: `Откроется в главе ${last}.` };
      const doneAt = beenIn().map((k) => chOf(k).location);
      const why = [...knownOf(c.location).map((x) => `находка «${x.name}»`), ...C().world.routes.filter(([a, b]) => b === c.location && doneAt.includes(a)).map(([a, , t]) => `${placeName(a)}: ${t.toLowerCase()}`)];
      if (why.length) return { ok: true, why: cap(why.join('; ')) + '.' };
      const hint = [...C().clues.filter((x) => x.subjects.includes(c.location) && x.location !== c.location).map((x) => `находка «${x.name}» (${placeName(x.location)})`), ...C().world.routes.filter(([, b]) => b === c.location).map(([a, , t]) => `${placeName(a)}: ${t.toLowerCase()}`)];
      return { ok: false, why: 'Адрес дадут: ' + hint.join('; ') + '.' };
    }
    const i = r.tail.indexOf(n);
    if (r.gate && r.gate[n]) { const got = knownOf(c.location); return { ok: got.length >= 2, gate: true, why: `${r.gate[n]} В уликах отряда таких источников: ${got.length}${got.length ? ' (' + got.map((x) => `«${x.name}»`).join(', ') + ')' : ''}. Списка источников в кампании нет: решает ведущий.` }; }
    if (i === 0) return { ok: !!st.done[last], why: r.tailWhy };
    return { ok: !!st.done[r.tail[i - 1]], why: `После главы ${r.tail[i - 1]}.` };
  }
  function nextStep() {
    const p = page(), r = R(), nx = B().pages[st.page + 1];
    if (p.kind === 'end' && !st.done[p.chapter]) return { a: 'endcard', label: 'Закончить главу' };
    if (nx && nx.chapter === p.chapter) return { a: 'next', label: 'Дальше: ' + nx.title };
    if (!r) return nx ? { a: 'next', label: `${chap(nx.chapter)}: ${nx.title}` } : { label: 'В демо страниц дальше нет' };
    if (!st.done[p.chapter]) return p.brief.demoPlay ? { a: 'playdemo:' + p.chapter, label: 'Сыграть главу целиком (демо)' } : { label: 'В демо страниц дальше нет' };
    const dd = st.dest && !st.done[st.dest] && firstPage(st.dest) >= 0 ? st.dest : null;
    return dd ? { a: 'goch:' + dd, label: `${chap(dd)}: ${chOf(dd).title}` } : { a: 'toc', label: 'Куда дальше? Выбирают игроки' };
  }
  const restId = () => pageLinks(page()).find((id) => link(id).t === 'rest');

  /* ── picture of the spread ── */
  function picture() {
    if (st.mode === 'gather') return gatherPic();
    if (st.fight && st.fview && st.fight.view === 'map' && st.tab === 'story' && !st.toc) { const bg = 'bm-' + encOf(link(st.fight.id)).location; return { html: battleMap(), map: true, kind: 'battle', src: has(bg) ? src(bg) : '', cap: 'Карта боя', level: 'x', chain: null, note: 'Фигура, потом клетка: фигура встанет туда. Тёмное — трудная местность, пунктир — укрытие.' }; }
    const p = page(), ch = { level: 'chapter', name: chap(p.chapter) }, pl = { level: 'place', name: placeName(p.place) };
    if (st.tab === 'story' && !st.toc) {
      const l = st.open && link(st.open);
      const ev = p.imgLevel === 'event' || p.imgLevel === 'scene' ? { level: 'event', name: p.imgCap } : null;
      if (l && l.img && has(l.img)) return { src: src(l.img), cap: l.imgCap || l.title, level: 'event', kind: l.face ? 'face' : l.object ? 'fit' : '', chain: [ch, pl, { level: 'event', name: l.imgCap || l.title }] };
      const lvl = ev ? 'event' : p.imgLevel, chain = [ch, pl]; if (ev) chain.push(ev);
      const note = l && l.t !== 'fork' && l.t !== 'rest' ? `У этого момента своей картинки нет: осталась картинка ${ev ? 'сцены' : lvl === 'place' ? 'места' : 'главы'}.` : '';
      return { ...pagePic(p), level: lvl, chain, note };
    }
    const s = sectionPic();
    return s || { ...pagePic(p), level: p.imgLevel === 'scene' ? 'event' : p.imgLevel, chain: [ch, pl] };
  }
  const LVL = { chapter: 'картинка главы', place: 'картинка места', event: 'картинка события' };
  function plateHtml() {
    const pic = picture();
    const onTv = st.tv && (pic.map ? st.tv.map : st.tv.src === pic.src && !st.tv.paper && !st.tv.map);
    const inFight = st.fight && st.fview && st.tab === 'story' && !st.toc && st.mode === 'play' && encOf(link(st.fight.id)).battlefield;
    const chain = pic.chain ? pic.chain.map((c) => (c.level === pic.level ? `<b title="${LVL[c.level]}">${esc(c.name)}</b>` : `<span>${esc(c.name)}</span>`)).join('<i aria-hidden="true">›</i>') : `<b>${esc(pic.cap || '')}</b>`;
    return `<figure class="plate ${pic.kind || ''}"><div class="fw"><i class="cn tl"></i><i class="cn tr"></i><i class="cn bl"></i><i class="cn br"></i><i class="clip"></i>
      <div class="frame"${pic.html ? ' tabindex="0" aria-label="Карта боя"' : ''}>${pic.html ? pic.html : pic.pins ? `<div class="mapbox"><img class="pic" src="${pic.src}" alt="${esc(pic.cap || '')}">${pic.pins}</div>` : `<img class="pic" src="${pic.src}" alt="${esc(pic.cap || '')}">`}</div></div>
      <figcaption class="pcap"><div class="crumb">${chain}</div>
        ${inFight ? `<button class="tvbtn" data-a="fmap">${st.fight.view === 'map' ? 'Картинка' : 'Карта боя'}</button>` : ''}${onTv ? `<span class="tvon">${gl('ok')}На экране стола</span>` : `<button class="tvbtn" data-a="tv">${gl('tv')}Показать столу</button>`}
        ${pic.note ? `<span class="capnote">${esc(pic.note)}</span>` : ''}</figcaption></figure>`;
  }

  /* ── left page: the story ── */
  function anchors(text) {
    return esc(text).replace(/\[\[([^|\]]+)\|([^\]]+)\]\]/g, (_, id, words) => {
      const l = link(id); if (!l) return words;
      const done = st.played[id] !== undefined;
      return `<a href="#" role="button" class="lk t-${l.t}${st.open === id ? ' on' : ''}${done ? ' done' : ''}" data-a="open:${id}" title="${TYPES[l.t].label}: ${esc(l.title)}">${gl(l.t)}${words}${done ? '\u2060<span class="ok" aria-label="сыграно">✓</span>' : ''}</a>`;
    });
  }
  function storyLeft() {
    const p = page(), bk = B(), n = bk.pages.length;
    const fork = p.fork ? `<button class="forkline t-fork${st.open === p.fork ? ' on' : ''}" data-a="open:${p.fork}">${gl('fork')}<span>${esc(link(p.fork).title)}</span><span class="arrow">${gl('right')}</span></button>` : '';
    const off = (p.offText || []).length ? `<div class="off"><span>Кроме текста:</span>${p.offText.map((id) => `<button class="chip t-${link(id).t}${st.open === id ? ' on' : ''}" data-a="open:${id}">${gl(link(id).t)}${esc(link(id).title)}${st.played[id] !== undefined ? ' ✓' : ''}</button>`).join('')}</div>` : '';
    const ns = nextStep(), here = st.page === st.mark;
    const nextBtn = `<button class="turn next" ${ns.a ? `data-a="${ns.a}"` : 'disabled'}><span>${esc(ns.label)}</span>${gl('right')}</button>`;
    return `${here ? '<i class="ribbon" title="Ляссе: отряд здесь"></i>' : ''}<div class="eyebrow"><span>${chap(p.chapter)} · ${esc(placeName(p.place))}</span><span class="sp"></span>
        ${here ? '' : `<button class="ghost" data-a="tomark">${gl('left')}К ляссе, стр. ${st.mark + 1}</button>`}<button class="ghost only-narrow" data-a="brief">Ведущему</button><button class="ghost" data-a="toc">${gl('list')}Оглавление</button></div>
      <h2 class="ttl">${esc(p.title)}</h2><img class="orn" src="${src('ui-divider')}" alt="">
      <div class="story ${p.kind}" tabindex="0" aria-label="Текст страницы">${p.paras.map((x) => `<p class="say">${anchors(x.t)}</p>`).join('')}${off}</div>
      ${fork}
      <div class="foot"><button class="turn" data-a="prev" ${st.page ? '' : 'disabled'} aria-label="Предыдущая страница">${gl('left')}</button>
        <span class="pager">стр. ${st.page + 1} из ${n}</span>
        <button class="turn roll${st.open === FREE ? ' on' : ''}" data-a="freeopen" title="Игроки придумали то, чего нет в тексте">${gl('check')}<span>Бросок</span></button>${nextBtn}</div>`;
  }

  /* ── right page: the brief of the page ── */
  function pageLinks(p) {
    const ids = [], add = (id) => { if (!ids.includes(id)) ids.push(id); };
    p.paras.forEach((x) => { for (const m of x.t.matchAll(/\[\[([^|\]]+)\|/g)) add(m[1]); });
    (p.offText || []).forEach(add);
    if (p.fork) add(p.fork);
    return ids;
  }
  const moment = (id) => { const l = link(id), done = st.played[id]; return `<li><button class="mo t-${l.t}" data-a="open:${id}"><img src="${ico(l.t)}" alt=""><span><span class="ty">${TYPES[l.t].label}</span><span class="tt">${esc(l.title)}</span></span><span class="stt${done !== undefined ? ' ok' : ''}">${done !== undefined ? '✓ ' + esc(done) : ''}</span></button></li>`; };
  const fightBanner = () => (st.fight && !st.fview ? `<button class="btn pri wide" data-a="backfight">${gl('fight')}Идёт бой «${esc(link(st.fight.id).title)}», раунд ${st.fight.round}. Вернуться к бою</button>` : '');
  function briefHtml() {
    const p = page(), b = p.brief, ids = pageLinks(p), written = p.paras.some((x) => x.src === 'w');
    const hint = st.seen ? '' : `<div class="hint-first">${gl('talk')}<span>Нажмите на выделенные слова слева: здесь откроется, как сыграть этот момент.</span></div>`;
    const peek = st.page === st.mark ? '' : `<div class="hint-first peek"><span>Вы читаете вперёд: ляссе осталось на стр. ${st.mark + 1}, экран стола не меняется.</span><button class="btn" data-a="markhere">Переложить ляссе сюда</button></div>`;
    const r = R(), free = r && p.kind === 'opening' && r.free.includes(p.chapter);
    const before = free ? Object.keys(st.done).map(Number).filter((k) => r.free.includes(k) && k !== p.chapter).sort((x, y) => st.done[x] - st.done[y]) : [];
    const came = free ? [['Отряд пришёл сюда', before.length ? `После: ${before.map((k) => placeName(chOf(k).location)).join(', ')}.` : 'Первым островом после вылета.'], ['Уже знает об этом месте', knownOf(p.place).map((x) => `«${x.name}»: ${x.statement}`).join(' ')]] : [];
    return [`<div class="card-h"><div><div class="k">Ведущему</div><h2>${p.kind === 'opening' ? 'Перед чтением' : p.kind === 'end' ? 'Чем кончается глава' : 'Как вести сцену'}</h2></div></div>`,
      `${fightBanner()}${peek}${paceHint()}${hint}<p class="lead">${esc(b.lead)}</p>
      <div class="lab">Моменты страницы</div><ul class="moments">${ids.map(moment).join('')}</ul>
      <div class="lab">Памятка</div>${rows([...came, ...b.rows])}
      <p class="gap">${written ? 'Рассказ этой страницы дописан для книги по данным кампании и ещё не вычитан.' : 'Текст страницы взят из кампании дословно.'}${b.demoEnd ? ' Дальше в демо страниц нет: остальные сцены и главы устроены так же.' : ''}</p>`, ''];
  }

  /* ── cards: [body, footer with the actions] ── */
  const head = (t, title, eyebrow) => `<div class="card-h t-${t}"><img src="${ico(t)}" alt=""><div><div class="k">${esc(eyebrow || TYPES[t].label)}</div><h2>${esc(title)}</h2></div><button class="ghost x" data-a="close" aria-label="Закрыть карточку">${gl('x')}<span>К сцене</span></button></div>`;
  const heroChips = (a, picked, withMod) => `<div class="heroes">${party().map((k) => { const h = hero(k); const m = withMod ? bestSkill(h, withMod) : null; return `<button class="hero" data-a="${a}${k}" aria-pressed="${picked === k}">${has(k) ? `<img src="${src(k)}" alt="">` : ''}<span>${esc(first(h.name))}${m ? ` <small>${esc(m.label)} ${sign(m.mod)}</small>` : ''}</span></button>`; }).join('')}</div>`;
  const skillMod = (h, key) => mod(h.sheet.abilities[SKILL[key]]) + (h.sheet.skills.includes(key) ? 2 : 0);
  const bestSkill = (h, skills) => skills.map(([key, label]) => ({ label, mod: skillMod(h, key) })).sort((a, b) => b.mod - a.mod)[0];
  const CARD = {
    talk(l, id) {
      const p = l.who && person(l.who), name = l.name || (p ? first(p.name) : '');
      return [`${l.lines.length ? `<div class="lab">Сказать голосом персонажа</div>${l.lines.map((o) => sayb(name, o, id, 'voice')).join('')}` : ''}
        ${l.rows && l.rows.length ? `<div class="lab">Как играть</div>${rows(l.rows.map((r) => [r.k, r.v]))}` : ''}
        ${l.knows ? `<div class="lab">Что знает</div><ul class="list">${l.knows.map((k) => `<li>${esc(k)}</li>`).join('')}</ul>` : ''}
        ${l.secret ? `<details class="sec"><summary>Тайна и когда её раскрыть</summary><p>${esc(l.secret)}</p><p>${esc(l.reveal || '')}</p></details>` : ''}
        ${l.gap ? `<p class="gap">${esc(l.gap)}</p>` : ''}`,
      `${st.played[id] !== undefined ? noted(id) : `<button class="btn pri" data-a="done:${id},Поговорили">Поговорили</button>`}${p ? `<button class="btn" data-a="goto:npcs,${l.who}">Вся страница: ${esc(first(p.name))}</button>` : ''}`];
    },
    check(l, id) {
      const r = st.rolls[id];
      if (l.nodice) {
        const res = l.funny ? (r ? `<div class="res" role="status"><span class="n">${r.d20}</span><span>на d20: только для смешной детали</span></div>${sayb('Рассказать', r.ok ? l.yes : l.no, id)}` : '') : st.actor[id] ? `<div role="status">${sayb('Рассказать', l.yes, id)}</div>` : '';
        return [`${res}<div class="nodice">${gl('check')}<span><b>Бросок не нужен.</b> ${esc(l.nodice)}</span></div>
          ${l.when ? rows([['В кампании', l.when.t]]) : ''}
          <div class="lab">Кто из героев это делает?</div>${heroChips(`${l.funny ? 'roll' : 'act'}:${id},`, st.actor[id])}`, noted(id)];
      }
      const res = r ? `<div class="res" role="status"><span class="n">${r.total ?? '—'}</span>${r.total != null ? `<span>d20 ${r.d20} ${sign(r.mod)} (${esc(r.label)}) против СЛ ${l.dc}</span>` : '<span>игрок бросил сам</span>'}<span class="v${r.ok ? '' : ' no'}">${r.ok ? 'Успех' : 'Провал'}</span></div>${sayb('Рассказать', r.ok ? l.yes : l.no, id)}` : '';
      return [`${res}${rows([['Навык', l.skills.map((s) => s[1]).join(' или ') + `, СЛ ${l.dc}`], ['Зачем бросок', l.when && l.when.t]])}
        <div class="lab">${r ? 'Перебросить: кто бросает?' : 'Кто бросает? Книга бросит за него'}</div>${heroChips(`roll:${id},`, st.actor[id], l.skills)}`,
      `${quiet('Игрок бросил сам:')}<button class="btn" data-a="self:${id},1">Успех</button><button class="btn" data-a="self:${id},0">Провал</button>`];
    },
    clue(l, id) {
      return [`${sayb('Рассказать', l.say, id)}${rows([['Как выглядит', l.look && l.look.t], ['Что это значит', l.means && l.means.t], ['Как находят', l.how && l.how.t], ['Если пропустили', l.fallback && l.fallback.t]])}`,
        `${st.played[id] !== undefined ? noted(id) : `<button class="btn pri" data-a="done:${id},${l.clue ? 'Отряд нашёл' : l.done || 'Заметили'}">${l.clue ? 'Отряд нашёл: записать в «Находки»' : l.done || 'Заметили'}</button>`}${l.clue ? `<button class="btn" data-a="goto:threads,${l.clue}">Открыть в «Находках»</button>` : ''}`];
    },
    show(l, id) {
      const onTv = st.tv && st.tv.paper === id;
      return [`<div class="lab">Текст для игроков</div><div class="slip" tabindex="0" aria-label="Текст для игроков">${esc(l.paper)}</div>${rows([[l.clue ? 'Что это даёт' : 'Когда и зачем', l.task]])}`,
        `${onTv ? `<span class="tvon">${gl('ok')}На экране стола</span>` : `<button class="btn pri" data-a="paper:${id}">${gl('tv')}Показать на экране стола</button>`}${st.played[id] !== undefined ? noted(id) : `<button class="btn" data-a="done:${id},Выдано игрокам">Выдали в руки</button>`}`];
    },
    puzzle(l, id) {
      const n = st.hints[id] || 0;
      return [`${sayb('Спросить игроков', l.ask, id)}${rows([['Разгадка', l.solution.t]])}
        <div class="lab">Подсказки: по одной, если игроки застряли</div>${n ? `<ul class="list" role="status">${l.hints.slice(0, n).map((h) => `<li>${esc(h)}</li>`).join('')}</ul>` : '<p class="empty">Пока ни одной не дали.</p>'}`,
      `${n < l.hints.length ? `<button class="btn" data-a="hint:${id}">Дать подсказку ${n + 1} из ${l.hints.length}</button>` : ''}${st.played[id] !== undefined ? noted(id) : `<button class="btn pri" data-a="done:${id},Решили${n ? ' с подсказкой' : ''}">Решили</button><button class="btn" data-a="done:${id},Не стали решать">Не стали решать</button>`}`];
    },
    fork(l, id) {
      const k = st.picked[id], o = k != null ? l.options[k] : null;
      const out = o && (o.say || o.gap) ? `<div role="status">${o.hero ? `<div class="lab">Кто это делает?</div>${heroChips(`act:${id},`, st.actor[id])}` : ''}${o.say ? sayb('Рассказать', o.say, id) : ''}${o.gap ? `<p class="gap">${esc(o.gap)}</p>` : ''}</div>` : '';
      const opt = (x, i) => { const to = x.go ? `${TYPES[link(x.go).t].label}: ${link(x.go).title}` : x.page ? 'Следующая страница' : ''; return `<button class="opt${k === i ? ' on' : ''}" data-a="pick:${id},${i}"><span>${esc(x.label)}</span>${to || x.note ? `<small>${esc([to, x.note].filter(Boolean).join(' · '))}</small>` : ''}<span class="arrow">${x.go || x.page ? gl('right') : ''}</span></button>`; };
      return [`${out}<div class="lab">${o ? 'Игроки выбрали. Можно выбрать иначе' : 'Игроки решают сами. Что они выбрали?'}</div><div class="opts">${l.options.map(opt).join('')}
        <button class="opt" data-a="freeopen"><span>Игроки придумали другое</span><small>Бросок: любой герой, любой навык</small><span class="arrow">${gl('right')}</span></button></div>`, noted(id)];
    },
    fight(l, id) {
      const few = l.fewFoes && party().length <= 2;
      const foes = foesOf(l).map((f) => { const a = f.attacks[0]; return `<li>${esc(f.name)}: КД ${f.ac}, хиты ${f.hp}${a ? `, ${esc(a.name.toLowerCase())} ${sign(a.bonus)}, урон ${a.damage.count}к${a.damage.sides}${a.damage.bonus ? sign(a.damage.bonus) : ''}` : ''}</li>`; }).join('');
      return [`${l.lines && l.lines.length ? `<div class="lab">До боя: сказать голосом</div>${l.lines.map((o) => sayb(l.lineName, o, id, 'voice')).join('')}` : ''}
        ${rows([['Когда начинается', l.trigger.t], ['Цель', l.goal && l.goal.t], ['Мирный путь', l.peace && l.peace.t], ['Поле', l.field && l.field.t]])}
        ${l.tactics ? `<details class="sec"><summary>Как ведут себя противники</summary><p>${esc(l.tactics.t)}</p></details>` : ''}
        <div class="lab">Противники</div><ul class="list">${foes}</ul>${few ? sayb('За столом двое: рассказать', { t: l.words.few, src: 'w' }, id) + '<p class="gap first">Правило демо, не кампании: при двух героях противник один.</p>' : ''}`,
      st.played[id] !== undefined ? noted(id) : `<button class="btn pri" data-a="fight:${id}">${gl('fight')}Начать бой</button><button class="btn" data-a="done:${id},Обошлись без боя">Обошлись без боя</button>`];
    },
    rest(l, id) {
      const ns = nextStep();
      return [`${l.ask ? `<label class="flabel" for="exp-name">${esc(l.ask)}</label><input class="field" id="exp-name" data-in="name" value="${esc(st.name)}" placeholder="Как ответили игроки" autocomplete="off">` : ''}
        <div class="lab">Награды</div><ul class="list">${l.rewards.map((r) => `<li>${esc(r)}</li>`).join('')}</ul>
        <div class="lab">Что запомнит мир</div>${rows(l.consequences.map((c) => [c.if, c.then]))}${rows([['Отдых', l.rest]])}`,
      st.done[page().chapter] ? `${noted(id)}${ns.a ? `<button class="btn pri" data-a="${ns.a}">${esc(ns.label)}</button>` : ''}` : `<button class="btn pri" data-a="end:${id}">Закончить главу</button>`];
    },
  };
  function freeCard() {
    const f = st.free, hk = party().includes(f.hero) ? f.hero : party()[0], h = hero(hk), r = f.res;
    const res = r ? `<div class="res" role="status"><span class="n">${r.total}</span><span>${esc(first(hero(r.hero).name))}: d20 ${r.d20}${r.label ? ` ${sign(r.mod)} (${esc(r.label)})` : ''}${r.dc ? ` против СЛ ${r.dc}` : ''}</span>${r.dc ? `<span class="v${r.ok ? '' : ' no'}">${r.ok ? 'Успех' : 'Провал'}</span>` : ''}</div><p class="gap first">Слов для этого в книге нет: исход рассказывает ведущий.</p>` : '';
    return [head('check', 'Свободный бросок', 'Игроки придумали своё'),
      `${res}<div class="lab">Кто действует?</div>${heroChips('fhero:', hk)}
      <div class="lab">Насколько это трудно?</div><div class="acts tight">${[[5, 'Легко'], [10, 'Средне'], [15, 'Трудно'], [0, 'Без сложности']].map(([n, t]) => `<button class="btn" data-a="fdc:${n}" aria-pressed="${f.dc === n}">${t}${n ? ` · СЛ ${n}` : ''}</button>`).join('')}</div>
      <div class="lab">Чем? Нажмите навык, и книга бросит</div><div class="acts tight">${Object.keys(SKILL).map((k) => `<button class="btn" data-a="fskill:${k}">${SKILL_RU[k]} ${sign(skillMod(h, k))}</button>`).join('')}<button class="btn" data-a="fskill:">Просто d20</button></div>`, ''];
  }

  /* ── fight: the hero's turn is one choice of "with what" and one tap on "whom" ── */
  const SPELL = { 'healing-word': { kind: 'heal', quick: true, level: 1, dice: [2, 4] }, 'detect-magic': { kind: 'know', level: 1 }, 'misty-step': { kind: 'move', quick: true, level: 2 } };
  const DOWN = { out: { now: 'без сил, до конца боя не действует.', chip: 'без сил' }, stable: { now: 'без сознания и стабилен.', chip: 'без сознания' }, saves: { now: 'на нуле хитов; в свой ход бросает спасбросок от смерти.', chip: 'на нуле' } };
  const encOf = (l) => C().encounters.find((x) => x.key === l.enc);
  const foesOf = (l) => (l.fewFoes && party().length <= 2 ? encOf(l).foes.slice(0, l.fewFoes) : encOf(l).foes);
  function actionsOf(k) {
    const s = hero(k).sheet, ab = s.abilities;
    const list = s.weapons.map((w, i) => { const W = WEAPON[w] || [w, 6, 'str'], m = W[2] === 'fin' ? Math.max(mod(ab.str), mod(ab.dex)) : mod(ab[W[2]]); return { id: 'w' + i, kind: 'atk', key: w, name: W[0], bonus: m + 2, sides: W[1], plus: m }; });
    (s.spells || []).forEach((id) => { if (SPELL[id] && C().spells[id]) list.push({ id, key: id, name: C().spells[id].name, ...SPELL[id] }); });
    return list;
  }
  const slotsLeft = (k, lvl) => Math.max(0, (hero(k).sheet.slots[lvl - 1] || 0) - ((st.slots[k] || [])[lvl - 1] || 0));
  const spend = (k, lvl) => { st.slots[k] = st.slots[k] || []; st.slots[k][lvl - 1] = (st.slots[k][lvl - 1] || 0) + 1; };
  const slotLine = (k) => { const s = hero(k).sheet; return s.cast ? 'Ячейки: ' + s.slots.map((n, i) => (n ? `${i + 1} круг ${'●'.repeat(slotsLeft(k, i + 1))}${'○'.repeat(n - slotsLeft(k, i + 1))}` : '')).filter(Boolean).join(', ') + '.' : ''; };
  const cur = () => st.fight.list[st.fight.turn];
  const alive = (side) => st.fight.list.filter((x) => x.side === side && x.hp > 0);
  const foeState = (x) => (x.hp <= 0 ? 'выбыл' : x.hp > x.max * 0.66 ? 'цел' : x.hp > x.max * 0.33 ? 'помят' : 'едва держится');
  const fill = (t, o) => { const nm = (((link(st.fight.id).words || {}).names || [])[o.foe ? o.foe.n : -1]) || (o.foe ? { n: o.foe.name.toLowerCase(), f: o.foe.name.toLowerCase() } : {}); return t.replace(/\{H\}/g, o.H || '').replace(/\{T\}/g, o.T || '').replace(/\{n\}/g, nm.n || '').replace(/\{f\}/g, nm.f || ''); };
  function startFight(id) {
    const l = link(id), e = encOf(l);
    const list = [
      ...party().map((k) => { const h = hero(k), s = h.sheet; return { id: k, side: 'party', name: first(h.name), hp: s.hp, max: s.hp, ac: s.ac, init: d(20) + mod(s.abilities.dex), ok: 0, bad: 0 }; }),
      ...foesOf(l).map((f, i) => { const a = f.attacks[0]; return { id: 'foe' + i, n: i, side: 'foe', name: f.name, hp: f.hp, max: f.hp, ac: f.ac, init: d(20) + f.init, atk: { name: a.name.toLowerCase(), bonus: a.bonus, sides: a.damage.sides, plus: a.damage.bonus || 0, count: a.damage.count } }; }),
    ].sort((a, b) => b.init - a.init);
    const pos = {}; (e.pos || []).forEach((p) => { if (list.some((x) => x.id === p.id)) pos[p.id] = [p.x, p.y]; });
    st.fight = { id, page: st.page, list, turn: 0, round: 1, last: null, over: null, acted: false, quick: false, act: 'w0', intro: true, pos, sel: null, view: 'pic', offered: false, offer: false };
    st.open = id; st.fview = true;
    beginTurn();
  }
  function checkOver() {
    const f = st.fight, foes = f.list.filter((x) => x.side === 'foe');
    if (!alive('foe').length) f.over = 'win'; else if (!alive('party').length) f.over = 'lose';
    else if (foes.length > 1 && alive('foe').length === 1 && (link(f.id).words || {}).stand && !f.offered) { f.offered = true; f.offer = true; }
  }
  function attack(a, atk, t) {
    const W = link(st.fight.id).words || {}, r = d(20), total = r + atk.bonus, hit = r === 20 || (r !== 1 && total >= t.ac);
    let dmg = 0, say = '', after = '';
    if (hit) { for (let i = 0; i < (atk.count || 1); i++) dmg += d(atk.sides); dmg = Math.max(1, dmg + atk.plus); t.hp = Math.max(0, t.hp - dmg); }
    if (a.side === 'party') {
      const w = ((W.atk || {})[a.id] || {})[atk.key];
      if (w) say = fill(hit ? w.hit : w.miss, { H: a.name, foe: t });
      if (hit) { after = `${t.name}: ${foeState(t)}.`; if (t.hp <= 0 && W.foe) say += ' ' + W.foe.fall; }
    } else {
      if (W.foe) say = fill(hit ? W.foe.hit : W.foe.miss, { H: t.name });
      if (hit) { after = t.hp > 0 ? `${t.name}: осталось ${t.hp} из ${t.max} хитов.` : `${t.name}: ${DOWN[B().down].now}`; if (t.hp <= 0 && W.drop) say = fill(W.drop, { H: t.name }); }
    }
    st.fight.last = { line: `${a.name}: ${atk.name}, цель — ${t.name}. На d20 ${r} ${sign(atk.bonus)} = ${total} против КД ${t.ac}: ${hit ? `попадание, урон ${dmg}` : 'мимо'}.`, after, say: say ? { t: say.trim(), src: 'w' } : null };
    checkOver();
  }
  function deathSave() {
    const f = st.fight, x = cur(), r = d(20);
    if (r === 20) { x.hp = 1; x.ok = x.bad = 0; }
    else if (r >= 10) x.ok++; else x.bad += r === 1 ? 2 : 1;
    if (x.ok >= 3) x.stable = true; if (x.bad >= 3) x.fate = true;
    f.last = { line: `${x.name}: спасбросок от смерти, на d20 ${r}. ${r === 20 ? 'Двадцать: герой приходит в себя с 1 хитом.' : `Успехов ${x.ok}, провалов ${Math.min(3, x.bad)}.`}`, after: x.stable ? 'Три успеха: стабилен и больше не бросает.' : x.fate ? 'Три провала. Что стало с героем, решает ведущий, не книга.' : '', say: null };
    f.acted = true;
  }
  function beginTurn() {
    const f = st.fight, x = cur();
    if (x.side === 'foe') { attack(x, x.atk, alive('party')[Math.floor(Math.random() * alive('party').length)]); f.acted = true; }
    else if (x.hp <= 0) deathSave();
  }
  function nextTurn() {
    const f = st.fight, skip = (x) => x.hp <= 0 && !(x.side === 'party' && B().down === 'saves' && !x.stable && !x.fate);
    f.last = null; f.acted = false; f.quick = false; f.act = 'w0'; f.intro = false; f.sel = null;
    do { f.turn = (f.turn + 1) % f.list.length; if (f.turn === 0) f.round++; } while (skip(f.list[f.turn]));
    beginTurn();
  }
  function heroAct(tid) {
    const f = st.fight, a = cur(), act = actionsOf(a.id).find((x) => x.id === f.act), t = tid && f.list.find((x) => x.id === tid), W = link(f.id).words || {};
    f.intro = false;
    if (act.kind === 'atk') { attack(a, act, t); f.acted = true; return; }
    if (slotsLeft(a.id, act.level) < 1) return;
    spend(a.id, act.level);
    if (act.kind === 'heal') {
      let n = mod(hero(a.id).sheet.abilities[hero(a.id).sheet.cast]); for (let i = 0; i < act.dice[0]; i++) n += d(act.dice[1]);
      const was = t.hp; t.hp = Math.min(t.max, t.hp + n); t.ok = t.bad = 0; t.stable = t.fate = false;
      f.last = { line: `${a.name}: «${act.name}», цель — ${t.name}. Восстановлено ${t.hp - was}: теперь ${t.hp} из ${t.max} хитов. Потрачена ячейка ${act.level} круга.`, after: was <= 0 ? `${t.name} снова в бою.` : '', say: W.heal && t.id !== a.id ? { t: fill(W.heal, { H: a.name, T: t.name }), src: 'w' } : null };
    } else f.last = { line: `${a.name}: «${act.name}». Потрачена ячейка ${act.level} круга.`, after: act.kind === 'know' && W.know ? '' : C().spells[act.key].description, say: act.kind === 'know' && W.know ? { t: fill(W.know, { H: a.name }), src: 'w' } : null };
    if (act.quick) { f.quick = true; f.act = 'w0'; } else f.acted = true;
  }
  function battleMap() {
    const f = st.fight, e = encOf(link(f.id)), bf = e.battlefield, W = bf.width, H = bf.height, S = 40, bg = 'bm-' + e.location, cells = [];
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) cells.push(`<rect class="cell" x="${x * S}" y="${y * S}" width="${S}" height="${S}" data-a="cell:${x},${y}"/>`);
    const mk = (list, cls) => (list || []).map((c) => `<rect class="${cls}" x="${c.x * S + 3}" y="${c.y * S + 3}" width="${S - 6}" height="${S - 6}" rx="4"/>`).join('');
    const toks = f.list.filter((x) => f.pos[x.id]).map((x) => `<g class="tok ${x.side}${x.hp <= 0 ? ' out' : ''}${f.sel === x.id ? ' sel' : ''}${x === cur() && !f.over ? ' now' : ''}" data-a="tok:${x.id}" transform="translate(${f.pos[x.id][0] * S + S / 2},${f.pos[x.id][1] * S + S / 2})" role="button" aria-label="${esc(x.name)}"><rect class="hit" x="-20" y="-20" width="40" height="40"/><circle r="16"/><text dy="5">${esc(x.side === 'party' ? x.name[0] : String(x.n + 1))}</text></g>`).join('');
    return `<svg class="bmap" style="min-width:${W * 28}px" viewBox="0 0 ${W * S} ${H * S}" role="group" aria-label="Карта боя">${has(bg) ? `<image href="${src(bg)}" width="${W * S}" height="${H * S}" preserveAspectRatio="xMidYMid slice"/>` : `<rect class="ground" width="${W * S}" height="${H * S}"/>`}${mk(bf.difficult, 'rough')}${mk(bf.cover, 'cover')}${cells.join('')}${toks}</svg>`;
  }
  function fightCard() {
    const f = st.fight, l = link(f.id), c = cur(), mode = DOWN[B().down];
    const state = (x) => (x.side === 'foe' ? foeState(x) : x.hp > 0 ? `${x.hp}/${x.max}` : x.fate ? 'решает ведущий' : x.stable ? 'стабилен' : mode.chip);
    const order = `<ol class="order" aria-label="Порядок ходов">${f.list.map((x, i) => `<li class="${i === f.turn && !f.over ? 'now' : ''}${x.hp <= 0 ? ' out' : ''}">${x.side === 'party' && has(x.id) ? `<img src="${src(x.id)}" alt="">` : `<span class="dot">${x.side === 'foe' ? x.n + 1 : esc(x.name[0])}</span>`}<span>${esc(x.name)} <small>${state(x)}</small></span></li>`).join('')}</ol>`;
    const headHtml = `<div class="card-h t-fight"><img src="${ico('fight')}" alt=""><div><div class="k">Бой · раунд ${f.round}</div><h2>${esc(l.title)}</h2></div></div>`;
    const res = f.last ? `<div role="status"><p class="log">${esc(f.last.line)} ${esc(f.last.after || '')}</p>${f.last.say ? sayb('Рассказать', f.last.say, f.id) : ''}</div>` : '';
    const tail = `${l.ends ? rows([['Как это может кончиться', l.ends.t]]) : ''}<p class="gap">Инициативу бросила книга, числа взяты из листов героев и противников. ${(l.words || {}).atk ? '' : 'Слов для ударов в этой книге нет: книга даёт только результат. '}Расстояния, укрытия и скрытую атаку плута книга в демо не считает.</p>`;
    const quit = '<span class="split"></span><button class="btn" data-a="fend:Договорились посреди боя">Договорились</button><button class="btn" data-a="flose">Отступаем</button>';
    if (f.over) return [headHtml, `${res}<div role="status">${sayb('Рассказать', f.over === 'win' ? l.win : l.lose, f.id)}</div>${f.over === 'lose' ? `<p class="gap">${esc(B().defeat)}</p>` : ''}${order}`, `<button class="btn pri" data-a="fend:${f.over === 'win' ? 'Бой выигран' : 'Отряд отступил'}">Вернуться к истории</button>`];
    if (f.offer) return [headHtml, `${res}${sayb('Перелом: противник остался один', { t: l.words.stand, src: 'w' }, f.id)}${order}`, '<button class="btn pri" data-a="fstand:1">Так и есть: бой окончен</button><button class="btn" data-a="fstand:0">Бьёмся дальше</button>'];
    if (c.side === 'foe' || c.hp <= 0 || f.acted) return [headHtml, `${f.intro ? sayb('Рассказать в начале', l.start, f.id) : ''}${res}${order}<div class="lab">Ход: ${esc(c.name)}</div>${tail}`, `<button class="btn pri" data-a="fnext">Следующий ход</button>${quit}`];
    const acts = actionsOf(c.id), can = (a) => a.kind === 'atk' || (slotsLeft(c.id, a.level) > 0 && !(a.quick && f.quick)), sel = acts.find((a) => a.id === f.act && can(a)) || acts[0];
    const chips = acts.map((a) => `<button class="btn" data-a="fact:${a.id}" aria-pressed="${a.id === sel.id}" ${can(a) ? '' : 'disabled'}>${esc(cap(a.name))}${a.kind === 'atk' ? ` ${sign(a.bonus)}` : a.quick ? ' · быстрое' : ''}</button>`).join('');
    const hint = sel.kind === 'atk' ? `Урон 1к${sel.sides}${sel.plus ? sign(sel.plus) : ''}. Цель выбирается внизу.` : `${C().spells[sel.key].description}${sel.kind === 'heal' ? ' Кого лечим, выбирается внизу.' : ''}`;
    const main = sel.kind === 'atk' ? alive('foe').map((x) => `<button class="btn pri" data-a="ftarget:${x.id}">${gl('fight')}${esc(x.name)} · ${foeState(x)}</button>`).join('')
      : sel.kind === 'heal' ? f.list.filter((x) => x.side === 'party').map((x) => `<button class="btn pri" data-a="ftarget:${x.id}">${esc(x.name)} ${x.hp}/${x.max}</button>`).join('')
      : `<button class="btn pri" data-a="fcast">Произнести: ${esc(sel.name)}</button>`;
    return [headHtml, `${f.intro ? sayb('Рассказать в начале', l.start, f.id) : ''}${res}${order}<div class="lab">Ход: ${esc(c.name)}. Игрок говорит, что делает герой. Чем?</div><div class="acts tight">${chips}</div>
      <p class="empty">${esc(hint)}${f.quick ? ' Быстрое заклинание уже сказано: действие ещё осталось.' : ''} ${esc(slotLine(c.id))}</p>${tail}`,
      `${main}<button class="btn" data-a="pass">Другое действие</button>${quit}`];
  }

  /* ── sections behind the bookmarks ── */
  const item = (tab, id, name, sub, img, cls, badge) => `<button class="it" data-a="sel:${tab},${id}" aria-current="${st.sel[tab] === id}">${img ? `<img class="${cls || ''}" src="${img}" alt="">` : '<span></span>'}<span><span class="nm">${esc(name)}</span><span class="sb">${esc(sub || '')}</span></span>${badge || '<span></span>'}</button>`;
  const e1 = () => C().e1;
  const SECTION = {
    heroes: {
      title: 'Герои', lead: 'Отряд этой кампании. Числа берутся из листов героев.',
      items: () => C().heroes.map((h) => ({ id: h.key, html: item('heroes', h.key, h.name, h.role, has(h.key) && src(h.key)) })),
      pic: (id) => { const h = hero(id); return has(id) ? { src: src(id), cap: h.name, kind: 'face' } : null; },
      detail(id) { const h = hero(id), s = h.sheet; return [`<div class="card-h"><div><div class="k">Герой · ${esc(h.species || '')} ${esc(CLASS_RU[s.cls] || '')} ${s.level} уровня</div><h2>${esc(h.name)}</h2></div></div>`,
        `<ul class="stats"><li><b>${s.ac}</b>класс доспеха</li><li><b>${s.hp}</b>хиты</li>${['str', 'dex', 'wis'].map((a) => `<li><b>${sign(mod(s.abilities[a]))}</b>${{ str: 'сила', dex: 'ловкость', wis: 'мудрость' }[a]}</li>`).join('')}</ul>
        ${rows([['Роль', h.role], ['Как выглядит', h.look], ['Мечта', h.want], ['Страх', h.fear], ['Связи', h.bond], ['Крючок истории', h.hook], ['Вопрос игроку', h.personalQuestion], ['В центре внимания', h.spotlight]])}
        ${h.simple ? `<div class="lab">Что можно попробовать</div><ul class="list">${h.simple.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}`,
        `<button class="btn pri" data-a="freehero:${h.key}">${gl('check')}Бросок за героя: ${esc(first(h.name))}</button>`]; },
    },
    npcs: {
      title: 'Лица', lead: 'Все, кого герои могут встретить. Сверху те, кто появляется в этой главе.',
      items() { const now = e1().participants; return [...C().npcs].sort((a, b) => now.includes(b.key) - now.includes(a.key)).map((p) => ({ id: p.key, html: item('npcs', p.key, p.name, p.public, has(p.key) && src(p.key), '', now.includes(p.key) ? '<span class="bd ok">в этой главе</span>' : '') })); },
      pic: (id) => (has(id) ? { src: src(id), cap: person(id).name, kind: 'face' } : null),
      detail(id) { const p = person(id); return [`<div class="card-h t-talk"><img src="${ico('talk')}" alt=""><div><div class="k">Лицо${p.location ? ' · ' + esc(placeName(p.location)) : ''}</div><h2>${esc(p.name)}</h2></div></div>`,
        `<p class="lead">${esc(p.public)}</p>${rows([['Как выглядит', p.look], ['Чего хочет', p.want], ['Как говорит', p.voice], ['Граница', p.boundary], ['Что предлагает', p.offer], ['Как меняется', p.change]])}
        <div class="lab">Что знает</div><ul class="list">${p.knows.map((k) => `<li>${esc(k)}</li>`).join('')}</ul>
        <details class="sec"><summary>Тайна и когда её раскрыть</summary><p>${esc(p.secret)}</p><p>${esc(p.reveal)}</p></details>`, '']; },
    },
    places: {
      title: 'Места', lead: 'Карта истории по местам. Отмечено, где отряд сейчас.',
      items() { const here = page().place; return C().locations.map((l) => ({ id: l.key, html: item('places', l.key, l.name, l.description, has('at-' + l.key) && src('at-' + l.key), 'sq', l.key === here ? '<span class="bd ok">отряд здесь</span>' : '') })); },
      pic: (id) => (has('at-' + id) ? { src: src('at-' + id), cap: placeName(id) } : null),
      detail(id) { const l = C().locations.find((x) => x.key === id), ch = C().chapters.filter((c) => c.location === id), who = C().npcs.filter((n) => n.location === id);
        return [`<div class="card-h t-fork"><img src="${ico('fork')}" alt=""><div><div class="k">Место</div><h2>${esc(l.name)}</h2></div></div>`, `<p class="lead">${esc(l.description)}</p>
        ${rows([['Главы здесь', ch.map((c) => `${chap(c.n)}: ${c.title}`).join('; ')], ['Кто здесь живёт', who.map((n) => n.name).join(', ')]])}`, '']; },
    },
    threads: {
      title: 'Находки', lead: 'Улики этой главы. Найденное отмечается само, когда вы играете ссылку в тексте.',
      items() { const keys = e1().clues; return C().clues.filter((c) => keys.includes(c.key)).map((c) => ({ id: c.key, html: item('threads', c.key, c.name, c.appearance, ico('clue'), 'ic', st.found[c.key] ? '<span class="bd ok">отряд знает</span>' : '<span class="bd">ещё не найдено</span>') })); },
      after: () => `<p class="empty">Ещё ${C().clues.length - e1().clues.length} находок лежат в следующих главах и откроются вместе с ними.</p>`,
      pic(id) { const l = Object.values(B().links).find((x) => x.clue === id && x.img && has(x.img)); return l ? { src: src(l.img), cap: l.imgCap, kind: l.object ? 'fit' : '' } : null; },
      detail(id) { const c = C().clues.find((x) => x.key === id); return [`<div class="card-h t-clue"><img src="${ico('clue')}" alt=""><div><div class="k">Находка · ${esc(placeName(c.location))}</div><h2>${esc(c.name)}</h2></div></div>`,
        rows([['Как выглядит', c.appearance], ['Что это значит', c.statement], ['Как находят', c.discovery || (c.method === 'inspect' ? 'Осмотреть; бросок не нужен.' : c.method)], ['Если пропустили', c.fallback]]),
        st.found[c.key] ? `<span class="done-note">${gl('ok')}Отряд это знает</span>` : quiet('Отряд этого ещё не нашёл')]; },
    },
    things: {
      title: 'Раздатки', lead: 'Письма, билеты и листы этой главы: то, что выдают игрокам в руки.',
      items() { const keys = e1().props || e1().handouts || []; return C().handouts.filter((h) => keys.includes(h.key)).map((h) => { const lid = Object.keys(B().links).find((k) => link(k).t === 'show' && link(k).title === h.title); return { id: h.key, html: item('things', h.key, h.title, h.text, ico('show'), 'ic', lid && st.played[lid] !== undefined ? '<span class="bd ok">у игроков</span>' : '') }; }); },
      pic: () => null,
      detail(id) { const h = C().handouts.find((x) => x.key === id); return [`<div class="card-h t-show"><img src="${ico('show')}" alt=""><div><div class="k">Раздатка</div><h2>${esc(h.title)}</h2></div></div>`, `<div class="slip" tabindex="0" aria-label="Текст раздатки">${esc(h.text)}</div>${rows([['Задание игрокам', h.task], ['Когда выдать', h.unlock]])}`, '']; },
    },
    rules: {
      title: 'Правила', lead: 'Как читать книгу и о чём договорились за столом.',
      items: () => [{ id: 'legend', html: item('rules', 'legend', 'Как читать эту книгу', 'Восемь видов ссылок в тексте', ico('check'), 'ic') }, ...B().rules.map((r, i) => ({ id: 'r' + i, html: item('rules', 'r' + i, r.title, r.text, ico('rest'), 'ic') }))],
      pic: () => null,
      detail(id) {
        if (id === 'legend') return ['<div class="card-h"><div><div class="k">Правила</div><h2>Как читать эту книгу</h2></div></div>', `<p class="lead">Слева рассказ для игроков. Выделенные слова ведут к игровым моментам: по нажатию справа открывается, как это сыграть. Если игроки придумали то, чего в тексте нет, внизу страницы есть «Бросок».</p>
          <ul class="legend">${Object.entries(TYPES).map(([t, v]) => `<li class="t-${t}"><img src="${ico(t)}" alt=""><span><b>${v.label}.</b> ${cap(v.what)}.</span></li>`).join('')}</ul>`, ''];
        const r = B().rules[+id.slice(1)]; return [`<div class="card-h"><div><div class="k">Правила кампании</div><h2>${esc(r.title)}</h2></div></div>`, `<p class="lead">${esc(r.text)}</p>`, ''];
      },
    },
  };
  function sectionPic() {
    if (st.tab === 'story' && st.toc) {
      const c = chOf(st.tocSel), k = 'at-' + c.location;
      if (C().pins && has('world-map')) return { src: src('world-map'), cap: 'Карта пути', kind: 'map', level: 'x', chain: null, pins: mapPins(), note: 'Цифры на карте — номера глав. Светлая метка: отряд здесь. Тусклые: адрес ещё не найден.' };
      return has(k) ? { src: src(k), cap: chap(c.n), level: 'place', chain: [{ level: 'chapter', name: chap(c.n) }, { level: 'place', name: placeName(c.location) }] } : null;
    }
    const S = SECTION[st.tab]; if (!S) return null;
    const p = st.sel[st.tab] && S.pic(st.sel[st.tab]);
    return p ? { ...p, level: 'x', chain: null } : null;
  }
  const backBtn = () => `<button class="ghost" data-a="tab:story">${gl('left')}К чтению, стр. ${st.page + 1}</button>`;
  function sectionLeft() {
    const S = SECTION[st.tab];
    if (!st.sel[st.tab]) { const it = S.items(); if (it.length) st.sel[st.tab] = it[0].id; }
    return `<div class="eyebrow"><span>Закладка</span><span class="sp"></span>${backBtn()}</div>
      <h2 class="ttl">${S.title}</h2><img class="orn" src="${src('ui-divider')}" alt=""><p class="prov">${S.lead}</p>
      <div class="idx">${S.items().map((x) => x.html).join('')}${S.after ? S.after() : ''}</div>`;
  }
  function journalLeft() {
    const list = st.journal.map((j) => `<button class="it" data-a="jump:${j.page},${j.id}"><img class="ic" src="${ico(j.type)}" alt=""><span><span class="nm">${esc(j.title)}</span><span class="sb">${esc(B().pages[j.page].title)} · ${esc(j.text)}</span></span><span></span></button>`).join('');
    return `<div class="eyebrow"><span>Закладка</span><span class="sp"></span><button class="ghost only-narrow" data-a="brief">Пересказ и заметки</button>${backBtn()}</div>
      <h2 class="ttl">Журнал</h2><img class="orn" src="${src('ui-divider')}" alt=""><p class="prov">Книга сама записывает, что сыграно. Нажмите запись, чтобы вернуться к этому месту.</p>
      <div class="idx">${list || '<p class="empty">Пока пусто. Сыграйте любой момент в тексте: он появится здесь.</p>'}</div>`;
  }
  function journalRight() {
    const recap = st.journal.length ? st.journal.map((j) => `${j.title.replace(/[?.!]+$/, '')} — ${j.text}`).join('. ') + '.' : 'Здесь соберётся пересказ для начала следующей встречи.';
    return ['<div class="card-h"><div><div class="k">Журнал</div><h2>В прошлый раз</h2></div></div>', `<p class="lead">${esc(recap)}</p>${st.name ? rows([['Экспедиция', st.name]]) : ''}
      <label class="flabel" for="notes">Заметки ведущего</label><textarea class="field" id="notes" data-in="notes" placeholder="Что запомнить к следующей встрече">${esc(st.notes)}</textarea>`, ''];
  }
  function routeGroups() {
    const r = R(), all = C().chapters;
    if (!r) return [['Главы по порядку', all]];
    const left = all.filter((c) => !st.done[c.n]), ok = (c) => reach(c.n).ok, started = beenIn().includes(r.start[r.start.length - 1]);
    return [['Сыграно', all.filter((c) => st.done[c.n]).sort((x, y) => st.done[x.n] - st.done[y.n])], ['Можно дальше: выбирают игроки', left.filter(ok)],
      ['Адрес ещё не найден', left.filter((c) => !ok(c) && r.free.includes(c.n) && started)], ['Позже по истории', left.filter((c) => !ok(c) && !(r.free.includes(c.n) && started))]].filter((g) => g[1].length);
  }
  const ORD = ['', 'первой', 'второй', 'третьей', 'четвёртой', 'пятой', 'шестой', 'седьмой', 'восьмой', 'девятой', 'десятой', 'одиннадцатой', 'двенадцатой'];
  function chBadge(c) {
    const cur = page().chapter;
    if (!R()) return c.n === cur ? '<span class="bd ok">вы здесь</span>' : '<span></span>';
    if (st.done[c.n]) return `<span class="bd">сыграна ${ORD[st.done[c.n]]}</span>`;
    if (c.n === markCh()) return '<span class="bd ok">ляссе здесь</span>';
    if (st.dest === c.n) return '<span class="bd ok">идём сюда</span>';
    if (st.deferred[c.n]) return '<span class="bd">отложена</span>';
    return '<span></span>';
  }
  function tocLeft() {
    const r = R();
    return `<div class="eyebrow"><span>${esc(B().bookName)}</span><span class="sp"></span><button class="ghost" data-a="toc">${gl('left')}К чтению, стр. ${st.page + 1}</button></div>
      <h2 class="ttl">${r ? 'Путь по главам' : 'Оглавление'}</h2><img class="orn" src="${src('ui-divider')}" alt=""><p class="prov">${r ? esc(r.order) : `${C().chapters.length} глав идут по порядку. Ведущий может читать вперёд.`}</p>
      <div class="idx">${routeGroups().map(([name, list]) => `<div class="grp">${name}</div>${list.map((c) => `<button class="it" data-a="tocsel:${c.n}" aria-current="${st.tocSel === c.n}">${has('at-' + c.location) ? `<img class="sq" src="${src('at-' + c.location)}" alt="">` : '<span></span>'}<span><span class="nm">${chap(c.n)}. ${esc(c.title)}</span><span class="sb">${esc(placeName(c.location))}</span></span>${chBadge(c)}</button>`).join('')}`).join('')}</div>`;
  }
  function tocRight() {
    const n = st.tocSel, c = chOf(n), r = R(), rc = reach(n), pages = B().pages.map((p, i) => [p, i]).filter(([p]) => p.chapter === n), beat = (C().beats || []).find((x) => x.number === n);
    const list = pages.length ? `<div class="lab">Страницы главы</div><ul class="moments">${pages.map(([p, i]) => `<li><button class="mo" data-a="page:${i}"><img src="${src('ui-emblem')}" alt=""><span><span class="tt">${esc(p.title)}</span></span><span class="stt${i === st.mark ? ' ok' : ''}">${i === st.mark ? 'ляссе здесь' : 'стр. ' + (i + 1)}</span></button></li>`).join('')}</ul>` : '<p class="gap">В демо эта глава не свёрстана.</p>';
    const info = !r ? '' : st.done[n] ? rows([['Что записано', beat && `${beat.choice} ${beat.result}`]]) : rows([['Как отряд сюда попадает', rc.why], r.free.includes(n) ? ['Если сюда не пойдут', r.skip] : null]);
    let foot = '';
    if (r && st.done[n]) foot = quiet(`Глава сыграна ${ORD[st.done[n]]}`);
    else if (r && n === markCh()) foot = `${quiet('Отряд сейчас в этой главе')}<button class="btn pri" data-a="tomark">К ляссе, стр. ${st.mark + 1}</button>`;
    else if (r && rc.ok) foot = `${pages.length ? `<button class="btn pri" data-a="fly:${n}">${st.dest === n ? 'Игроки выбрали: продолжить' : 'Игроки выбрали эту главу'}</button>` : quiet('В демо эта глава не свёрстана')}${r.free.includes(n) ? `<button class="btn" data-a="defer:${n}">${st.deferred[n] ? 'Вернуть из отложенных' : 'Отложить'}</button>` : ''}`;
    else if (r) foot = `<button class="btn" data-a="openaddr:${n}">${rc.gate ? 'Отряд собрал координаты' : 'Отряд узнал адрес сам'}</button>`;
    return [`<div class="card-h"><div><div class="k">${chap(n)} · ${esc(placeName(c.location))}</div><h2>${esc(c.title)}</h2></div></div>`, `<p class="lead">${esc(c.goal)}</p>${info}${list}`, foot];
  }
  function mapPins() {
    const here = chOf(markCh()).location;
    return C().pins.map((pin) => {
      const list = C().chapters.filter((c) => c.location === pin.place); if (!list.length) return '';
      const c = list.find((x) => !st.done[x.n]) || list[list.length - 1];
      const state = pin.place === here ? 'here' : list.every((x) => st.done[x.n]) ? 'done' : reach(c.n).ok ? 'open' : 'shut';
      return `<button class="pin s-${state}${st.tocSel === c.n ? ' sel' : ''}" style="left:${(pin.x * 100).toFixed(1)}%;top:${(pin.y * 100).toFixed(1)}%" data-a="tocsel:${c.n}" aria-label="${chap(c.n)}: ${esc(placeName(pin.place))}" title="${esc(placeName(pin.place))}">${c.n}</button>`;
    }).join('');
  }

  /* ── the meeting: closed book, gathering at the table, time, closing ── */
  const mins = (p) => { const r = (p.brief.rows || []).find((x) => x[0] === 'Время'); return r ? parseInt(r[1], 10) : 0; };
  const needMin = () => B().pages.reduce((sum, p, i) => sum + (i >= st.mark && p.chapter === markCh() ? mins(p) : 0), 0);
  const stopWords = () => (B().stops || {})[B().pages[st.mark].id];
  const dur = () => C().brief.duration || C().meet.sessionDuration || '';
  const ritual = () => (C().meet.recurring || []).find((x) => x.includes('В начале встречи'));
  function paceHint() {
    const m = st.meet, left = m.length - m.min, need = needMin();
    if (!m.min || st.page !== st.mark || !(need > left || left <= m.length / 4)) return '';
    return `<div class="hint-first peek"><span>${left > 0 ? `До конца встречи ${hm(left)}` : 'Время встречи вышло'}${need ? `, а до конца главы по книге около ${need} минут` : ''}. Остановиться можно, не дочитав главу.</span><button class="btn" data-a="meet">Как остановиться здесь</button></div>`;
  }
  function meetCard() {
    const m = st.meet, need = needMin(), a = act(markCh()), sw = stopWords(), done = st.done[markCh()], pg = B().pages[st.mark];
    return [head('rest', `Встреча ${m.n}`, 'Время, перерыв, конец встречи'),
      `<div class="res"><span class="n">${hm(m.min)}</span><span>из ${hm(m.length)} на сегодня</span><button class="btn" data-a="tick">+30 минут (демо)</button></div>
      ${rows([['Ляссе', `стр. ${st.mark + 1}, «${pg.title}»`], ['До конца главы', done ? 'Глава уже сыграна.' : need ? `По книге около ${need} минут.` : ''], ['Где можно остановиться', a && a.rest], ['Идёт бой', st.fight ? `«${link(st.fight.id).title}», раунд ${st.fight.round}: книга запомнит ход.` : '']])}
      <div class="lab">Если заканчиваем здесь</div>${sw ? sayb('Сказать на прощание', sw, MEET) : `<p class="gap first">${done || pg.kind === 'end' ? 'Глава кончается своим последним кадром: добавлять нечего.' : 'Слов для остановки на этой странице в книге нет: кампания даёт концовку только для всей главы. Скажите своими.'}</p>`}
      ${rows([['Ритуал встречи', ritual()]])}`,
      `${m.paused ? '<button class="btn" data-a="resume">Продолжить встречу</button>' : '<button class="btn" data-a="pause">Перерыв</button>'}<button class="btn pri" data-a="closebook">Закрыть книгу до следующей встречи</button>`];
  }
  function coverHtml() {
    const bk = B(), c = C(), isFirst = !st.last && !st.order && !st.journal.length, pg = bk.pages[st.mark];
    const others = Object.values(BOOKS).filter((x) => x.key !== st.skin).map((x) => `<button class="spine" data-a="skin:${x.key}"><img src="img/${x.key}-cover.webp" alt=""><span><b>${esc(x.title)}</b><small>${esc(x.bookName)}</small></span></button>`).join('');
    return `<div class="desk"><button class="cbook" data-a="openbook" aria-label="Открыть книгу «${esc(bk.title)}»">
        <span class="ctitle">${esc(bk.title)}</span><span class="cart"><img src="${src('cover')}" alt=""></span><img class="cemb" src="${src('ui-emblem')}" alt=""><span class="csub">${esc(bk.bookName)} · книга ведущего</span>${isFirst ? '' : '<i class="ctail"></i>'}</button>
      <section class="slip-card" aria-label="Что дальше"><div class="k">${isFirst ? 'Новая история' : `Встреча ${st.meet.n}`}</div><h2>${isFirst ? esc(bk.title) : 'Продолжаем с ляссе'}</h2>
        <div class="acts first"><button class="btn pri" data-a="openbook">${isFirst ? 'Открыть книгу' : 'Открыть на ляссе'}</button></div>
        <p class="lead">${isFirst ? esc(c.brief.intent) : `${chap(pg.chapter)}, стр. ${st.mark + 1}: «${esc(pg.title)}».`}</p>
        ${isFirst ? rows([['Сколько длится', dur()], ['Глав в книге', String(c.chapters.length)]]) : rows([['В прошлый раз', st.last && st.last.words], ['Сыграно глав', `${st.order} из ${c.chapters.length}`], ['Не закончено', st.fight ? `Бой «${link(st.fight.id).title}»` : '']])}
        <div class="lab">На полке ещё</div><div class="spines">${others}</div></section></div>`;
  }
  function gatherPic() {
    const sel = st.meet.sel, pg = B().pages[st.mark];
    if (sel !== 'today' && has(sel)) return { src: src(sel), cap: hero(sel).name, kind: 'face', level: 'x', chain: null };
    return st.last ? { ...pagePic(pg.dyn ? { ...pg, ...pg.dyn(st) } : pg), level: 'x', chain: null, cap: `Где остановились: ${pg.title}` } : { src: src('cover'), cap: B().title, level: 'x', chain: null };
  }
  function gatherLeft() {
    const m = st.meet, isFirst = !st.last;
    return `<div class="eyebrow"><span>Встреча ${m.n} · форзац</span><span class="sp"></span><button class="ghost" data-a="tocover">${gl('left')}Закрыть книгу</button></div>
      <h2 class="ttl">Сбор за столом</h2><img class="orn" src="${src('ui-divider')}" alt=""><p class="prov">${isFirst ? 'Раздайте героев и договоритесь о правилах. Потом книга откроется на первой странице.' : 'Отметьте, кто пришёл. Потом книга откроется на ляссе.'}</p>
      <div class="idx"><button class="it" data-a="gsel:today" aria-current="${m.sel === 'today'}"><img class="ic" src="${src('ui-emblem')}" alt=""><span><span class="nm">Сегодняшняя встреча</span><span class="sb">${isFirst ? 'Перед первой игрой' : 'В прошлый раз и что изменилось'}</span></span><span class="bd">встреча ${m.n}</span></button>
        <div class="grp">Кто за столом</div>${C().heroes.map((h) => `<button class="it" data-a="gsel:${h.key}" aria-current="${m.sel === h.key}">${has(h.key) ? `<img src="${src(h.key)}" alt="">` : '<span></span>'}<span><span class="nm">${esc(h.name)}</span><span class="sb">${esc(h.role)}</span></span>${m.present[h.key] === false ? '<span class="bd">сегодня нет</span>' : '<span class="bd ok">за столом</span>'}</button>`).join('')}</div>`;
  }
  function gatherRight() {
    const m = st.meet, c = C(), isFirst = !st.last, sel = m.sel;
    const start = `<button class="btn pri" data-a="start">${isFirst ? 'Начать встречу' : `Продолжить с ляссе, стр. ${st.mark + 1}`}</button>`;
    if (sel !== 'today') {
      const h = hero(sel), away = m.present[sel] === false, aw = (B().away || {})[sel];
      return [`<div class="card-h"><div><div class="k">Герой для игрока</div><h2>${esc(h.name)}</h2></div></div>`,
        `${away ? (aw ? sayb('Если игрока сегодня нет', aw, MEET) : '<p class="gap first">Слов о том, где герой, пока игрока нет, в книге нет: скажите своими.</p>') : ''}${rows([['Роль', h.role], ['Как выглядит', h.look], ['Мечта', h.want], ['Страх', h.fear], ['Связи', h.bond], ['Крючок истории', h.hook], ['Вопрос игроку', h.personalQuestion]])}
        ${h.simple ? `<div class="lab">Что можно попробовать</div><ul class="list">${h.simple.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}`,
        `<button class="btn" data-a="seat:${sel}" ${!away && party().length < 2 ? 'disabled' : ''}>${away ? 'Игрок пришёл' : 'Игрока сегодня нет'}</button>${start}`];
    }
    const len = `<div class="lab">Сколько играем сегодня</div><div class="acts tight">${[90, 120, 150, 180].map((n) => `<button class="btn" data-a="len:${n}" aria-pressed="${m.length === n}">${hm(n)}</button>`).join('')}</div>`;
    const gone = B().party.filter((k) => m.present[k] === false).map((k) => first(hero(k).name)).join(', ');
    if (isFirst) return [`<div class="card-h"><div><div class="k">Встреча ${m.n}</div><h2>Перед первой игрой</h2></div></div>`,
      `${len}<div class="lab">Договориться до первой страницы</div>${rows([['Договор стола', c.world.safety || (c.world.boundaries || [])[0]], ['Ритуал встречи', ritual()], ['В этой истории', (c.brief.include || []).join('; ')], ['Чего в ней нет', (c.brief.exclude || []).join('; ')], ['Сколько длится', dur()], ['Сегодня без', gone]])}`, start];
    const L = st.last, recap = st.journal.filter((j) => !String(j.id).startsWith('meet')).slice(-6).map((j) => `${j.title.replace(/[?.!]+$/, '')} — ${j.text}`).join('. ');
    const lastDone = Object.keys(st.done).map(Number).sort((x, y) => st.done[y] - st.done[x])[0], la = lastDone && act(lastDone);
    return [`<div class="card-h"><div><div class="k">Встреча ${m.n}</div><h2>В прошлый раз</h2></div></div>`,
      `<p class="lead">${esc(recap ? recap + '.' : 'В журнале пока пусто: расскажите своими словами.')}</p>${rows([['Остановились', `Стр. ${L.page + 1}, «${L.title}».`], ['Последние слова', L.words], ['Идёт бой', L.fight], ['Что изменилось', la && L.chapterDone ? `Награды главы ${lastDone}: ${la.reward.join('; ').toLowerCase()}. ${la.rest}` : ''], ['Сегодня без', gone]])}${len.replace('class="lab"', 'class="lab" style="margin-top:16px"')}`,
      `${start}<button class="btn" data-a="recap">${gl('tv')}Показать «В прошлый раз» столу</button>`];
  }

  /* ── render ── */
  function renderBar() {
    const tv = st.tv;
    $('#bar').innerHTML = `<h1>Книга ведущего</h1>
      <div class="skins" role="group" aria-label="Кампания"><span class="cap">Кампания:</span>${Object.values(BOOKS).map((b) => `<button class="skin" data-a="skin:${b.key}" aria-pressed="${b.key === st.skin}" title="${esc(b.title)} · ${esc(b.style)}"><img src="img/${b.key}-cover.webp" alt=""><span>${esc({ lh: 'Маяк', rc: 'Дождь', mc: 'Корона' }[b.key])}</span></button>`).join('')}</div>
      <span class="grow"></span>
      ${st.mode === 'play' ? `<button class="clock" data-a="meet" title="Время встречи, перерыв, конец встречи">Встреча ${st.meet.n} · <b>${hm(st.meet.min)}</b> из ${hm(st.meet.length)}</button>` : ''}
      <div class="tv" title="Что сейчас видят игроки на экране стола"><span class="lbl">Экран стола:</span><b>${esc(tv ? tv.cap : '')}</b><span class="scr" style="${tv && !tv.paper && tv.src ? `background-image:url(${tv.src})` : 'background:var(--paper)'}"></span></div>
      <button class="about-btn" data-a="about">О концепте</button>`;
  }
  function renderTabs() {
    $('#tabs').innerHTML = TABS.map(([k, name, ic]) => { const i = (st.skin === 'lh' && LH_TAB[k]) || ic; return `<button class="tab" role="tab" data-a="tab:${k}" aria-selected="${st.tab === k}"><img src="${src(i)}" alt=""><span>${name}${k === 'story' ? ` <span class="pg">стр. ${st.page + 1}</span>` : ''}${k === 'journal' && st.journal.length ? ` <span class="pg">${st.journal.length}</span>` : ''}</span></button>`; }).join('') + `<span class="tgrow"></span><button class="tool${st.open === MEET ? ' on' : ''}" data-a="meet">Закрыть книгу</button>`;
    $('#tabs').hidden = st.mode !== 'play';
  }
  const viewKey = () => [st.skin, st.mode, st.meet.sel, st.tab, st.toc, st.page, st.open, st.fview, st.sel[st.tab], st.tocSel].join('|');
  let lastKey = '';
  function renderBook() {
    let left, right, compact = false;
    $('#book').className = 'book' + (st.mode === 'cover' ? ' closed' : '');
    if (st.mode === 'cover') { $('#book').innerHTML = coverHtml(); document.body.classList.remove('sheet-open'); lastKey = viewKey(); return; }
    if (st.mode === 'gather') { left = gatherLeft(); right = gatherRight(); }
    else if (st.tab === 'story' && st.toc) { left = tocLeft(); right = tocRight(); }
    else if (st.tab === 'story') {
      left = storyLeft();
      if (st.fight && st.fview) { right = fightCard(); compact = true; }
      else if (st.open === FREE) { right = freeCard(); right[1] = fightBanner() + right[1]; compact = true; }
      else if (st.open === MEET) { right = meetCard(); compact = true; }
      else if (st.open) { const l = link(st.open), c = CARD[l.t](l, st.open); right = [head(l.t, l.title), fightBanner() + c[0], c[1]]; compact = true; }
      else right = briefHtml();
    } else if (st.tab === 'journal') { left = journalLeft(); right = journalRight(); }
    else { left = sectionLeft(); const S = SECTION[st.tab]; right = st.sel[st.tab] ? S.detail(st.sel[st.tab]) : ['', '', '']; }
    if (st.meet.paused && st.mode === 'play') right[1] = `<div class="hint-first peek"><span>Перерыв: на экране стола заставка, часы встречи стоят.</span><button class="btn" data-a="resume">Продолжить встречу</button></div>` + right[1];
    const keep = {}, key = viewKey();
    if (key === lastKey && !toTop) for (const q of ['.story', '.cbody', '.idx']) { const e = $(q); if (e) keep[q] = e.scrollTop; }
    const back = `<button class="ghost only-sheet" data-a="unsheet">${gl('left')}К странице</button>`;
    $('#book').innerHTML = `<section class="page page-l" aria-label="Левая страница">${left}</section><section class="page page-r${compact && !(st.fight && st.fview && st.fight.view === 'map') ? ' compact' : ''}${st.fight && st.fview && st.fight.view === 'map' && st.mode === 'play' ? ' mapview' : ''}" aria-label="Правая страница">${back}${plateHtml()}<div class="card">${right[0]}<div class="cbody" tabindex="0" aria-label="Как это сыграть">${right[1]}</div><div class="cfoot">${right[2] || ''}</div></div></section>`;
    for (const q in keep) { const e = $(q); if (e) e.scrollTop = keep[q]; }
    lastKey = key; toTop = false;
    document.body.classList.toggle('sheet-open', st.sheet);
  }
  function renderAbout() {
    const written = B().pages.some((p) => p.paras.some((x) => x.src === 'w'));
    $('#over').innerHTML = about ? `<div class="veil" data-a="about"><div class="sheetbox" role="dialog" aria-modal="true" aria-label="О концепте"><div class="top"><div><h2>Книга ведущего</h2><p>Концепт: ведущий читает историю из книги, а книга ведёт его через игру.</p></div><button class="ghost x" data-a="about">${gl('x')}Закрыть</button></div>
      <h3>Как устроен разворот</h3><ul><li><b>Левая страница</b> — рассказ, который читают вслух. В нужных местах слова выделены: это ссылки на игровые моменты.</li><li><b>Правая страница</b> — картинка и карточка «как это сыграть». Пока ссылка не открыта, там памятка по сцене и список её моментов.</li><li><b>Картинка</b> привязана к главе, месту и событию. Книга показывает самую точную из тех, что есть; подпись говорит, какую именно. Экран стола получает картинку сцены сам, а событие или раздатку — по кнопке.</li><li><b>Закладки</b> над книгой ведут в остальное: герои, лица, места, находки, раздатки, правила, журнал. Закладка «История» всегда возвращает на ту же страницу.</li></ul>
      <h3>Как книга ведёт и не решает за игроков</h3><ul><li>Страницы идут по порядку истории; кнопка внизу называет следующую.</li><li>Сыгранная ссылка получает галочку, исход записывается в «Журнал», найденное — в «Находки».</li><li>Развилка внизу страницы спрашивает, что выбрали игроки, и открывает нужную карточку.</li><li>Игроки придумали то, чего нет в тексте: кнопка «Бросок» внизу страницы бросает за любого героя любой навык.</li><li>Начатый бой не теряется, если заглянуть в другую карточку или закладку.</li></ul>
      <h3>Свободный маршрут</h3><ul><li>Там, где кампания разрешает любой порядок глав, кнопка внизу последней страницы спрашивает «Куда дальше?» и открывает «Путь по главам».</li><li>«Путь» делит главы на сыгранные, доступные сейчас, те, чей адрес ещё не найден, и те, что ждут позже; причина взята из данных кампании: находки и маршруты между островами.</li><li>Ляссе отмечает, где отряд. Ведущий может читать вперёд: ляссе и экран стола остаются на месте, пока он не переложит ляссе.</li><li>Отложенная глава не пропадает; ведущий может открыть любую главу сам, если игроки нашли дорогу иначе.</li></ul>
      <h3>Бой</h3><ul><li>Бой идёт на правой странице. В ход героя ведущий отмечает, чем тот действует (оружие и заклинания берутся из листа героя), и одним нажатием выбирает цель. Книга бросает, считает урон и ячейки и даёт слова для рассказа.</li><li>Быстрое заклинание оставляет действие. Лечение поднимает героя с нуля.</li><li>Что значит ноль хитов, задаёт кампания: «без сил» в «Маяке», без сознания в «Дожде», спасброски от смерти в «Короне». Книга никогда не убивает героя сама.</li><li>Когда противник остаётся один, книга предлагает перелом; мирные исходы видны весь бой.</li><li>Кнопка «Карта боя» над карточкой меняет картинку на поле с фигурами: его можно показать столу и двигать фигуры.</li></ul>
      <h3>Встреча от и до</h3><ul><li>Закрытая книга лежит обложкой вверх: одна кнопка «Открыть книгу», потом «Открыть на ляссе».</li><li>Форзац — сбор за столом: кто пришёл, карточки героев для игроков, в первый раз договор стола, в следующие «В прошлый раз» и что изменилось.</li><li>Над книгой справа идёт время встречи. Когда его остаётся мало, книга говорит, сколько по её счёту до конца главы, и даёт слова, чтобы остановиться здесь.</li><li>«Закрыть книгу» оставляет ляссе на месте и запоминает незаконченный бой; «Перерыв» ставит заставку на экран стола.</li></ul>
      <h3>Вид книги</h3><p>Переплёт, бумага, шрифт, закладки и значки берутся из стиля иллюстраций кампании. В демо три книги: «${esc(BOOKS.lh.title)}» (${esc(BOOKS.lh.bookName.toLowerCase())}), «${esc(BOOKS.rc.title)}» (${esc(BOOKS.rc.bookName.toLowerCase())}) и «${esc(BOOKS.mc.title)}» (${esc(BOOKS.mc.bookName.toLowerCase())}).</p>
      <h3>Откуда текст в этой книге</h3><p>${written ? 'Вступления глав, памятки, улики, раздатки и карточки персонажей взяты из кампании дословно. Рассказ трёх сцен и реплики написал <span lang="en">Sonnet 5.5</span> по данным кампании; они помечены знаком ✎ и ещё не вычитаны.' : 'Весь текст этой книги взят из кампании дословно: рассказ нарезан из текста сцен, подсказки ведущему вынесены на правую страницу.'}</p>
      <h3>Чего в демо нет</h3><ul><li>В «Маяке» свёрстаны главы 1 и 2 и вступления трёх островов; у островов есть кнопка «Сыграть главу целиком (демо)», чтобы увидеть, как меняется путь. В двух других книгах — первые страницы.</li><li>В бою нет состояний, концентрации, скрытой атаки плута и проверки расстояний; фигуры на карте двигает ведущий.</li><li>Экран стола показан маленьким окном наверху, телефоны игроков не показаны.</li></ul></div></div>` : '';
  }
  function render() {
    const fa = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.a : null;
    document.documentElement.dataset.skin = st.skin;
    renderBar(); renderTabs(); renderBook(); renderAbout();
    if (fa) { const el = document.querySelector(`[data-a="${CSS.escape(fa)}"]`); if (el) el.focus({ preventScroll: true }); }
    fit();
  }
  // the emblem under a chapter opening is decoration: it goes first when the text needs the room
  function fit() {
    const mf = $('.mapview .frame'); if (mf) mf.classList.toggle('more-x', mf.scrollWidth > mf.clientWidth + 1);
    const s = $('.story'); if (!s) return;
    s.classList.remove('tight', 'more');
    if (s.scrollHeight > s.clientHeight + 1) s.classList.add('tight');
    if (s.scrollHeight > s.clientHeight + 1) s.classList.add('more');
  }
  window.addEventListener('resize', fit);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);

  /* ── actions ── */
  const freeRoll = (sk) => { const f = st.free, hk = party().includes(f.hero) ? f.hero : party()[0], h = hero(hk), r = d(20), m = sk ? skillMod(h, sk) : 0, total = r + m; f.hero = hk; f.res = { hero: hk, d20: r, mod: m, label: sk ? SKILL_RU[sk] : '', total, dc: f.dc, ok: total >= f.dc };
    jot(FREE, 'check', 'Свободный бросок', `${first(h.name)}${sk ? ', ' + SKILL_RU[sk] : ''}: ${total}${f.dc ? ` против СЛ ${f.dc}, ${total >= f.dc ? 'успех' : 'провал'}` : ''}`); };
  const ACT = {
    skin(k) { st = states[k] || (states[k] = fresh(k)); if (!st.tv) showTv({ src: src('cover'), cap: B().title }); try { history.replaceState(null, '', '#' + k); } catch (e) { /* the hash is a convenience */ } },
    about() { about = !about; },
    openbook() { st.mode = 'gather'; st.meet.sel = 'today'; st.sheet = false; },
    tocover() { st.mode = 'cover'; st.sheet = false; },
    gsel(k) { st.meet.sel = k; st.sheet = true; },
    seat(k) { st.meet.present[k] = st.meet.present[k] === false; },
    len(n) { st.meet.length = +n; },
    start() { st.mode = 'play'; st.meet.paused = false; turnTo(st.mark, true); if (st.fight) st.fview = false; },
    recap() { showTv({ paper: 'recap', cap: 'В прошлый раз' }); },
    meet() { st.tab = 'story'; st.toc = false; st.open = MEET; st.fview = false; st.sheet = true; toTop = true; },
    tick() { st.meet.min += 30; },
    pause() { st.meet.paused = true; showTv({ src: has('ui-break') ? src('ui-break') : src('cover'), cap: 'Перерыв' }); },
    resume() { st.meet.paused = false; showTv(pagePic(B().pages[st.mark].dyn ? { ...B().pages[st.mark], ...B().pages[st.mark].dyn(st) } : B().pages[st.mark])); },
    closebook() { const pg = B().pages[st.mark], sw = stopWords(), m = st.meet;
      st.last = { page: st.mark, title: pg.title, words: sw ? sw.t : '', chapterDone: !!st.done[pg.chapter], fight: st.fight ? `«${link(st.fight.id).title}», раунд ${st.fight.round}: продолжится с того же хода.` : '' };
      jot('meet' + m.n, 'rest', `Встреча ${m.n}`, `Остановились на стр. ${st.mark + 1}, «${pg.title}»`);
      m.n++; m.min = 0; m.paused = false; st.mode = 'cover'; st.open = null; st.sheet = false; st.fview = false; st.page = st.mark; showTv({ src: src('cover'), cap: B().title }); },
    tab(k) { st.tab = k; st.toc = false; st.sheet = false; },
    toc() { st.tab = 'story'; st.toc = !st.toc; st.open = null; st.fview = false; st.sheet = false; const r = R(), cur = page().chapter;
      st.tocSel = r && st.done[cur] ? (st.dest && !st.done[st.dest] ? st.dest : (C().chapters.find((c) => !st.done[c.n] && reach(c.n).ok && !st.deferred[c.n]) || chOf(cur)).n) : cur; },
    tomark() { turnTo(st.mark); },
    markhere() { st.mark = st.page; showTv(pagePic(page())); },
    fly(n) { n = +n; st.dest = n; delete st.deferred[n]; const cur = markCh(), lp = lastPage(cur);
      // a chapter with a written ending is closed first; an unfinished island can simply be left
      if (!st.done[cur] && cur !== n && B().pages[lp].kind === 'end') turnTo(lp, true); else { turnTo(firstPage(n), true); st.dest = null; } },
    goch(n) { turnTo(firstPage(+n), true); st.dest = null; },
    defer(n) { n = +n; if (st.deferred[n]) delete st.deferred[n]; else { st.deferred[n] = true; if (st.dest === n) st.dest = null; } },
    openaddr(n) { st.opened[+n] = true; },
    playdemo(n) { n = +n; const beat = (C().beats || []).find((x) => x.number === n), c = chOf(n); st.done[n] = ++st.order; if (st.dest === n) st.dest = null;
      jot('ch' + n, 'rest', `${chap(n)}. ${c.title}`, beat ? `${beat.choice} ${beat.result}` : 'Глава сыграна'); ACT.toc(); },
    tocsel(n) { st.tocSel = +n; st.sheet = true; },
    page(i) { turnTo(+i); },
    prev() { if (st.page) turnTo(st.page - 1); },
    next() { if (B().pages[st.page + 1]) turnTo(st.page + 1, st.page === st.mark); },
    open(id) {
      st.seen = true;
      if (link(id).route) { ACT.toc(); if (!st.toc) ACT.toc(); return; }
      if (st.fight && st.fight.id === id) { st.open = id; st.fview = true; st.sheet = true; return; }
      st.open = st.open === id ? null : id; st.fview = false; st.sheet = !!st.open;
    },
    close() { st.open = null; st.sheet = false; st.fview = false; },
    brief() { st.open = null; st.fview = false; st.sheet = true; },
    unsheet() { st.sheet = false; },
    endcard() { st.open = restId(); st.sheet = true; },
    freeopen() { st.tab = 'story'; st.toc = false; st.open = FREE; st.fview = false; st.sheet = true; toTop = true; },
    freehero(k) { st.free.hero = k; st.free.res = null; ACT.freeopen(); },
    fhero(k) { st.free.hero = k; },
    fdc(n) { st.free.dc = +n; },
    fskill(sk) { freeRoll(sk); toTop = true; },
    tv() { const p = picture(); showTv(p.map ? { map: true, src: p.src, cap: p.cap } : { src: p.src, cap: p.cap }); },
    paper(id) { showTv({ paper: id, cap: link(id).title }); },
    done(arg) { const [id, ...t] = arg.split(','); play(id, t.join(',')); st.open = null; st.sheet = false; },
    act(arg) { const [id, k] = arg.split(','); st.actor[id] = k; const l = link(id); if (l.t === 'check') play(id, `${first(hero(k).name)}: получилось без броска`); toTop = true; },
    roll(arg) { const [id, k] = arg.split(','), l = link(id), h = hero(k); st.actor[id] = k; toTop = true;
      if (l.funny) { const r = d(20); st.rolls[id] = { d20: r, ok: r >= 11 }; play(id, `${first(h.name)}: ${r} на d20, смешная деталь`); return; }
      const s = bestSkill(h, l.skills), r = d(20), total = r + s.mod, ok = total >= l.dc; st.rolls[id] = { d20: r, mod: s.mod, label: s.label, total, ok }; play(id, `${first(h.name)}: ${total} против СЛ ${l.dc}, ${ok ? 'успех' : 'провал'}`); },
    self(arg) { const [id, ok] = arg.split(','); st.rolls[id] = { ok: ok === '1', total: null }; play(id, ok === '1' ? 'Успех' : 'Провал'); toTop = true; },
    hint(id) { st.hints[id] = (st.hints[id] || 0) + 1; },
    pick(arg) { const [id, i] = arg.split(','), l = link(id), o = l.options[+i]; st.picked[id] = +i; toTop = true;
      if (!o.quiet) play(id, o.result || o.label);
      if (o.settles && st.played[o.settles] === undefined) play(o.settles, 'Обошлись без боя');
      if (o.go) ACT.open(o.go); else if (o.page) turnTo(B().pages.findIndex((p) => p.id === o.page), st.page === st.mark); },
    goto(arg) { const [tab, id] = arg.split(','); st.tab = tab; st.sel[tab] = id; st.sheet = true; },
    sel(arg) { const [tab, id] = arg.split(','); st.sel[tab] = id; st.sheet = true; },
    jump(arg) { const [p, id] = arg.split(','); turnTo(+p); if (id === FREE || link(id)) { st.open = id; st.sheet = true; } },
    fight(id) { startFight(id); toTop = true; },
    backfight() { const f = st.fight; st.tab = 'story'; st.toc = false; st.page = f.page; st.open = f.id; st.fview = true; st.sheet = true; },
    fact(id) { st.fight.act = id; },
    ftarget(tid) { heroAct(tid); toTop = true; },
    fcast() { heroAct(null); toTop = true; },
    fstand(yes) { if (yes === '1') ACT.fend('Последний противник уступил'); else st.fight.offer = false; },
    fmap() { const f = st.fight; f.view = f.view === 'map' ? 'pic' : 'map'; f.sel = null; },
    tok(id) { const f = st.fight; f.sel = f.sel === id ? null : id; },
    cell(xy) { const f = st.fight; if (f.sel) { f.pos[f.sel] = xy.split(',').map(Number); f.sel = null; } },
    pass() { nextTurn(); toTop = true; },
    fnext() { nextTurn(); toTop = true; },
    fend(t) { play(st.fight.id, t); st.fight = null; st.fview = false; st.open = null; st.sheet = false; },
    flose() { st.fight.over = 'lose'; },
    end(id) { const n = page().chapter, r = R(); st.done[n] = ++st.order; st.slots = {}; play(id, st.name && n === 1 ? `Экспедиция «${st.name}»` : 'Глава сыграна');
      if (r && r.start.includes(n) && r.start.includes(n + 1)) st.dest = n + 1; },
  };
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-a]'); if (!el) return;
    if (el.classList.contains('veil') && e.target !== el) return;
    if (el.tagName === 'A') e.preventDefault();
    const [name, ...rest] = el.dataset.a.split(':');
    ACT[name](rest.join(':')); render();
  });
  document.addEventListener('input', (e) => { const k = e.target.dataset && e.target.dataset.in; if (k) st[k] = e.target.value; });
  document.addEventListener('keydown', (e) => {
    const t = e.target;
    if (t.matches && t.matches('a.lk') && e.key === ' ') { e.preventDefault(); t.click(); return; }
    if (t.matches && t.matches('input,textarea')) return;
    if (e.key === 'Escape') { if (about) about = false; else if (st.open || st.sheet) ACT.close(); else return; render(); }
    else if (st.tab === 'story' && !st.toc && !about && e.key === 'ArrowRight') { ACT.next(); render(); }
    else if (st.tab === 'story' && !st.toc && !about && e.key === 'ArrowLeft') { ACT.prev(); render(); }
  });
  const hash = (location.hash || '').slice(1);
  ACT.skin(BOOKS[hash] ? hash : 'lh');
  render();
  window.__book = { get st() { return st; }, ACT, render };
})();
