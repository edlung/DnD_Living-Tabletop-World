// The three books of the demo. Campaign text is taken verbatim from data.js (src 'c');
// text written for the book by Sonnet 5.5 comes from lh-text.js (src 'w'); the few lines that are the book's own are src 'b'.
(function () {
  const D = window.DATA, T = window.LHTEXT;
  const by = (arr, key) => arr.find((x) => x.key === key);
  const miss = (window.BOOK_MISS = []);
  // a verbatim slice of campaign text: from the first `a` up to (not including) the next `b`
  const seg = (t, a, b) => {
    const i = a ? t.indexOf(a) : 0;
    const j = b ? t.indexOf(b, i + 1) : t.length;
    if (i < 0 || j < 0) { miss.push(['seg', a, b]); return ''; }
    return t.slice(i, j).trim();
  };
  // the words between « and » that start with `a`
  const quote = (t, a) => {
    const i = t.indexOf('«' + a);
    if (i < 0) { miss.push(['quote', a]); return ''; }
    return t.slice(i + 1, t.indexOf('»', i));
  };
  const mark = (t, pairs) => {
    for (const [ph, id] of pairs) {
      if (!t.includes(ph)) miss.push(['mark', ph]);
      t = t.replace(ph, `[[${id}|${ph}]]`);
    }
    return t;
  };
  const c = (t) => ({ t, src: 'c' });
  const b = (t) => ({ t, src: 'b' });
  const w = (id) => ({ t: T.words[id], src: 'w' });
  const pre = (paras, p) => paras.map((t) => ({ t: t.replace(/\[\[/g, '[[' + p + '-'), src: 'w' }));
  const personRows = (p) => [
    ['Как выглядит', p.look], ['Чего хочет', p.want], ['Как говорит', p.voice], ['Граница', p.boundary],
  ].filter((r) => r[1]).map(([k, v]) => ({ k, v, src: 'c' }));

  /* ───────────── Маяк Между Ветрами ───────────── */
  const lh = D.lh, e1 = lh.e1, e2 = lh.e2, S = e1.scenes;
  const runa = by(lh.npcs, 'runa'), spool = by(lh.npcs, 'spool');
  const kEnc = by(lh.encounters, 'dock-keepers');
  const cLoop = by(lh.clues, 'festival-loop'), cLog = by(lh.clues, 'harbor-log');
  const hInv = by(lh.handouts, 'handout-invitation'), hTic = by(lh.handouts, 'handout-ticket');
  const bakerGap = 'В данных кампании у пекаря нет имени и карточки: всё, что о нём известно, стоит в тексте сцен.';
  const lhBook = {
    key: 'lh', title: lh.world.title, style: 'Гуашь и акварель, латунь, индиго', bookName: 'Судовой журнал',
    party: lh.heroes.map((h) => h.key), defeat: 'В этой кампании герой на нуле хитов остаётся «без сил»: поражение означает отступление.',
    chapterWord: 'Глава',
    pages: [
      {
        id: 'lh-open', chapter: 1, kind: 'opening', title: e1.title, place: 'harbor', img: 'harbor', imgLevel: 'chapter', imgCap: 'Глава 1',
        paras: [c(mark(e1.readAloud, [['Один и тот же фонарик трижды пролетает мимо трубы', 'o-loop'], ['Под вашим столом звякает лис', 'o-spool']]))],
        brief: { lead: e1.goal, rows: [['Сколько играть', e1.duration], ['Не раскрывать', e1.dmNote], ['Отдых', e1.rest]] },
      },
      {
        id: 'lh-s1', chapter: 1, kind: 'scene', title: S[0].title, place: 'harbor', img: 'ev-table', imgLevel: 'scene', imgCap: S[0].title,
        paras: pre(T.scenes.scene1, 's1'), fork: 's1-fork',
        brief: { lead: seg(S[0].play, 'Попросите каждого', 'Предложите три'), rows: [['Броски', S[0].check], ['Если игрок стесняется', S[0].failForward], ['Время', `${S[0].minutes} минут`]] },
      },
      {
        id: 'lh-s2', chapter: 1, kind: 'scene', title: S[1].title, place: 'harbor', img: 'ev-lantern', imgLevel: 'scene', imgCap: S[1].title,
        paras: pre(T.scenes.scene2, 's2'), fork: 's2-fork',
        brief: { lead: seg(S[1].play, 'Дайте увидеть все три наблюдения.', 'Шпуль пытается'), rows: [['Броски', S[1].check], ['Если не вышло', S[1].failForward], ['Время', `${S[1].minutes} минут`]] },
      },
      {
        id: 'lh-s3', chapter: 1, kind: 'scene', title: S[2].title, place: 'harbor', img: 'ev-keepers', imgLevel: 'scene', imgCap: S[2].title,
        paras: pre(T.scenes.scene3, 's3'), fork: 's3-ways',
        brief: { lead: seg(S[2].play, 'Они не злые', 'Герои могут'), rows: [['Броски', S[2].check], ['Если не вышло', S[2].failForward], ['Время', `${S[2].minutes} минут`]] },
      },
      {
        id: 'lh-end', chapter: 1, kind: 'end', title: 'Лампа в каюте', place: 'ship', img: 'ev-lamp', imgLevel: 'scene', imgCap: 'Лампа в каюте',
        paras: [c(mark(e1.end, [['как назовём вашу первую экспедицию?', 'e-end']]))],
        brief: { lead: 'Последние слова главы. Вопрос Руны задаётся игрокам: ответ остаётся в книге.', rows: [['Отдых', e1.rest]] },
      },
      {
        id: 'lh-2-open', chapter: 2, kind: 'opening', title: e2.title, place: 'ship', img: 'ship', imgLevel: 'chapter', imgCap: 'Глава 2',
        paras: [c(mark(e2.readAloud, [['Шпуль торжественно кладёт на стол три гайки', 'n-spool']]))],
        brief: { lead: e2.goal, rows: [['Сколько играть', e2.duration], ['Ведущему', e2.dmNote]], demoEnd: true },
      },
    ],
    links: {
      'o-loop': { t: 'clue', title: 'Фонарик летит по кругу', img: 'ev-lantern', imgCap: 'Фонарь над трубой',
        means: c(seg(e1.dmNote, 'Повторяется только', 'Не заставляйте')), how: c(seg(e1.dmNote, 'Не заставляйте')), done: 'Заметили' },
      'o-spool': { t: 'talk', who: 'spool', title: 'Шпуль с булочкой', img: 'spool', imgCap: spool.name, face: true, lines: [w('spool-bun-1'), w('spool-bun-2')], rows: personRows(spool), knows: spool.knows, secret: spool.secret, reveal: spool.reveal },
      's1-invite': { t: 'show', title: hInv.title, paper: hInv.text, task: hInv.task },
      's1-stars': { t: 'check', title: 'Созвездие из фонарей', nodice: seg(S[0].play, 'Любая разумная попытка'), yes: w('stars-done') },
      's1-napkin': { t: 'check', title: 'Улетевшая салфетка', nodice: seg(S[0].play, 'Любая разумная попытка'), funny: true, when: c(S[0].check), yes: w('napkin-high'), no: w('napkin-low') },
      's1-baker': { t: 'talk', title: 'Пекарь у лотка', name: 'Пекарь', img: 'ev-baker', imgCap: 'Пекарь у лотка', lines: [w('baker-hello'), w('baker-story')], rows: [{ k: 'Получится ли', v: seg(S[0].play, 'Любая разумная попытка'), src: 'c' }, { k: 'Если игрок стесняется', v: S[0].failForward, src: 'c' }], gap: bakerGap },
      's1-fork': { t: 'fork', title: 'Что делают герои?', options: [{ label: S[0].choices[0], go: 's1-baker' }, { label: S[0].choices[1], go: 's1-napkin' }, { label: S[0].choices[2], page: 'lh-s2', note: 'Те, кто смотрит по сторонам, первыми заметят повтор.' }] },
      's2-lantern': { t: 'check', title: 'Поймать фонарь', img: 'ev-lantern', imgCap: 'Фонарь над трубой', skills: [['perception', 'Восприятие'], ['investigation', 'Расследование']], dc: 10, when: c(seg(S[1].check, 'заметить удобный момент', '; основная')), yes: w('lantern-yes'), no: w('lantern-no') },
      's2-receipt': { t: 'clue', clue: 'festival-loop', title: cLoop.name, img: 'ev-receipt', imgCap: cLoop.name, say: w('receipt-look'), look: c(cLoop.appearance), means: c(cLoop.statement), how: c('Основная улика выдаётся автоматически при осмотре.') },
      's2-bakerloop': { t: 'talk', title: 'Пекарь помнит повтор', name: 'Пекарь', img: 'ev-baker', imgCap: 'Пекарь у лотка', lines: [w('baker-loop-1'), w('baker-loop-2')], rows: [{ k: 'Что он знает', v: seg(S[1].play, 'Пекарь помнит повтор', ', а часы'), src: 'c' }], gap: bakerGap },
      's2-clock': { t: 'clue', title: 'Часы у причала', img: 'ev-lantern', imgCap: 'Часы у причала', say: w('clock-look'), means: c(seg(e1.puzzle.prompt, 'Фонарь идёт', ' Что стоит')), how: b('Игроки видят кольцо без броска. Что оно значит, первая глава не объясняет.'), done: 'Осмотрели' },
      's2-spool': { t: 'talk', who: 'spool', title: 'Шпуль считает булочки', img: 'spool', imgCap: spool.name, face: true, lines: [w('spool-count-1'), w('spool-count-2')], rows: personRows(spool), knows: spool.knows, secret: spool.secret, reveal: spool.reveal },
      's2-runa': { t: 'talk', who: 'runa', title: 'Руна тоже заметила', img: 'runa', imgCap: runa.name, face: true, lines: [w('runa-loop-1'), w('runa-loop-2')], rows: personRows(runa), knows: runa.knows, secret: runa.secret, reveal: runa.reveal },
      's2-puzzle': { t: 'puzzle', title: 'Что сравнить?', img: 'ev-lantern', imgCap: 'Загадка вечера', ask: c(e1.puzzle.prompt), solution: c(e1.puzzle.solution), hints: e1.puzzle.hints },
      's2-fork': { t: 'fork', title: 'Что делают герои?', options: [{ label: S[1].choices[0], go: 's2-lantern' }, { label: S[1].choices[1], go: 's2-puzzle' }, { label: S[1].choices[2], go: 's2-bakerloop' }] },
      's3-keepers': { t: 'fight', enc: 'dock-keepers', title: kEnc.title, img: 'ev-keepers', imgCap: kEnc.title, lines: [w('keeper-warn-1'), w('keeper-warn-2')], lineName: 'Смотритель', trigger: c(kEnc.trigger), start: w('fight-start'), win: { t: T.words['fight-win'].split(' Все целы')[0], src: 'w' }, lose: w('keepers-push'), field: b('Причал 10 × 8 клеток, два укрытия и трудный участок посередине: так поле задано в данных встречи.') },
      's3-ticket': { t: 'show', title: hTic.title, paper: hTic.text, task: hTic.task },
      's3-plate': { t: 'clue', title: 'Табличка и рычаг', say: w('plate-look'), means: c(seg(S[2].check, 'Осмотр таблички', ' В бою')), done: 'Осмотрели' },
      's3-ways': { t: 'fork', title: 'Как пройти мимо смотрителей?', options: [
        { label: S[2].choices[0], say: w('ticket-yes'), settles: 's3-keepers', result: 'Смотрители пропустили груз по билету «сегодня»' },
        { label: 'Перевести смотрителей на ручной режим', labelSrc: 'c', say: w('lever-yes'), hero: true, settles: 's3-keepers', result: 'Смотрители переведены на ручной режим' },
        { label: S[2].choices[1], gap: 'Слов для этого пути в книге нет: кампания называет его одной строкой. Расскажите исход сами.', settles: 's3-keepers', result: 'Ярлыки переставлены вместе с грузчиками' },
        { label: S[2].choices[2], go: 's3-keepers' },
        { label: 'Не получилось', labelSrc: 'b', say: w('keepers-push'), quiet: true },
      ] },
      's3-log': { t: 'clue', clue: 'harbor-log', title: cLog.name, img: 'ev-log', imgCap: cLog.name, say: w('log-look'), look: c(cLog.appearance), means: c(cLog.statement) },
      's3-runa': { t: 'talk', who: 'runa', title: 'Руна предлагает «Чайник»', img: 'runa', imgCap: runa.name, face: true, lines: [w('runa-ship-1'), w('runa-ship-2')], rows: [{ k: 'Что предлагает', v: runa.offer, src: 'c' }, ...personRows(runa)], knows: runa.knows, secret: runa.secret, reveal: runa.reveal },
      'e-end': { t: 'rest', title: 'Итоги и имя экспедиции', ask: 'Как назовём вашу первую экспедицию?', rewards: e1.reward, rest: e1.rest, consequences: e1.consequences, next: 'lh-2-open' },
      'n-spool': { t: 'talk', who: 'spool', title: 'Шпуль и три гайки', img: 'spool', imgCap: spool.name, face: true, lines: [], rows: personRows(spool), knows: spool.knows, secret: spool.secret, reveal: spool.reveal },
    },
    extraClues: [],
    rules: [
      { title: 'Договор стола', text: lh.world.safety, src: 'c' },
      { title: 'Тон истории', text: lh.world.tone, src: 'c' },
      { title: 'Рост героев', text: lh.world.progression, src: 'c' },
      { title: 'Отдых', text: e1.rest, src: 'c' },
    ],
  };

  /* ───────────── Дождь по страховому случаю ───────────── */
  const rc = D.rc, r1 = rc.e1, R = r1.scenes;
  const klara = by(rc.npcs, 'nina-run'), sav = by(rc.npcs, 'saveliy-run'), helga = by(rc.npcs, 'vera-meller'), matvey = by(rc.npcs, 'matvey-kord');
  const cPort = by(rc.clues, 'funeral-portrait'), cNote = by(rc.clues, 'hire-note');
  const hTrack = by(rc.handouts, 'distance-track'), hCard = by(rc.handouts, 'funeral-card'), hNote = by(rc.handouts, 'client-note');
  const rcBook = {
    key: 'rc', title: rc.world.title, style: 'Гуашь и тушь, мокрый асфальт, неон', bookName: 'Папка дела',
    party: rc.heroes.map((h) => h.key), defeat: 'Сбитый герой лежит без сознания и стабилен.', chapterWord: 'Глава',
    pages: [
      {
        id: 'rc-open', chapter: 1, kind: 'opening', title: r1.title, place: 'rain-cemetery', img: 'cover', imgLevel: 'chapter', imgCap: 'Глава 1',
        paras: [c(mark(r1.readAloud, [['портрет', 'r-portrait'], ['Конрад поднимает фотоаппарат', 'r-photo'], ['Это Савелий Рун', 'r-sav']]))],
        offText: ['r-track', 'r-card'],
        brief: { lead: r1.goal, rows: [['Перед чтением', R[0].play.split('\n\n')[0]], ['Сколько играть', rc.world.sessionDuration || 'Около трёх часов: три сцены по 45 минут']] },
      },
      {
        id: 'rc-s1', chapter: 1, kind: 'scene', title: R[0].title, place: 'rain-cemetery', img: 'rain-cemetery', imgLevel: 'place', imgCap: 'Северное кладбище',
        paras: [
          c(mark(seg(R[0].play, 'Священник частит', ' Кто рассмотрел') + ' ' + seg(R[0].play, 'Конрад в видоискателе', '\n\nК яме'), [['портрет', 'r-portrait'], ['высокого человека без зонта', 'r-sav']])),
          c(mark(seg(R[0].play, 'К яме рвётся', '\n\nСтарый'), [['Матвей Корд', 'r-matvey']])),
          c(mark(seg(R[0].play, 'Старый могильщик', ' Спросите его'), [['Старый могильщик', 'r-digger']])),
          c(mark(seg(R[0].play, 'Высокий уходит', ' Если герой'), [['Высокий уходит к воротам', 'r-chase']])),
        ],
        fork: 'r-fork1',
        brief: { lead: seg(hTrack.text, 'Фишки:', '\nВас двигают'), rows: [['В конце сцены', seg(R[0].play, 'Конец сцены:').replace('Конец сцены: ', '')], ['Броски и числа', R[0].check], ['Если не вышло', R[0].failForward], ['Время', `${R[0].minutes} минут`]] },
      },
      {
        id: 'rc-s2', chapter: 1, kind: 'scene', title: R[1].title, place: 'rain-cemetery', img: 'nina-run', imgLevel: 'scene', imgCap: R[1].title, imgFace: true,
        paras: [
          c(mark(R[1].play.split('\n\n')[0], [['Клара Рун', 'r-klara']])),
          c(mark(seg(R[1].play, 'Она пишет записку', ' (раздатка') + ' ' + seg(R[1].play, 'вместе с конвертом', ' Верный вопрос'), [['пишет записку', 'r-note']])),
          c(mark(R[1].play.split('\n\n')[2], [['Хельга Меллер', 'r-helga']])),
          c(mark(seg(R[1].play, 'За колумбарием', ' (Атлетика') + '. ' + seg(R[1].play, 'Неон трамвайного', ' Конец сцены'), [['срезать к задней ограде', 'r-cut']])),
        ],
        fork: 'r-fork2', offText: ['r-insight'],
        brief: { lead: R[1].play.split('\n\n')[3], rows: [['Броски и числа', R[1].check], ['Если не вышло', R[1].failForward], ['Время', `${R[1].minutes} минут`]], demoEnd: true },
      },
    ],
    links: {
      'r-track': { t: 'show', title: hTrack.title, paper: hTrack.text, task: hTrack.unlock },
      'r-card': { t: 'show', title: hCard.title, paper: hCard.text, task: hCard.unlock },
      'r-portrait': { t: 'clue', clue: 'funeral-portrait', title: cPort.name, img: 'duck-umbrella', imgCap: 'Зонт с утиной головой', look: c(cPort.appearance), means: c(cPort.statement), how: c(cPort.discovery), fallback: c(cPort.fallback) },
      'r-photo': { t: 'show', title: 'Снимок с похорон', img: 'crowd-photo', imgCap: 'Снимок Конрада', paper: seg(r1.ending, 'Ночью Конрад', ' В 23:00'), task: seg(R[0].check, 'Без броска:', ' Числа сцены') },
      'r-sav': { t: 'talk', who: 'saveliy-run', title: 'Человек без зонта', img: 'saveliy-run', imgCap: sav.name, face: true, lines: [c(quote(R[0].play, 'Раз. Два. Три.')), c(quote(R[0].play, 'Не сегодня'))], rows: personRows(sav), knows: sav.knows, secret: sav.secret, reveal: sav.reveal },
      'r-matvey': { t: 'talk', who: 'matvey-kord', title: 'Матвей Корд у ямы', img: 'matvey-kord', imgCap: matvey.name, face: true, lines: [c(quote(R[0].play, 'Кто тут Рун?')), c(quote(R[0].play, 'Ещё раз!'))], rows: personRows(matvey), knows: matvey.knows, secret: matvey.secret, reveal: matvey.reveal },
      'r-digger': { t: 'talk', title: 'Старый могильщик', name: 'Могильщик', lines: [c(quote(R[0].play, 'Венки в часовню')), c(quote(R[0].play, 'Вдова. Лица не смотрела'))], rows: [{ k: 'Верный вопрос', v: seg(R[0].play, 'Спросите его', '\n\nВысокий'), src: 'c' }, { k: 'Что даёт', v: seg(R[0].check, 'Числа сцены:', ' В конце сцены'), src: 'c' }], gap: 'У могильщика в кампании нет карточки и портрета: его слова стоят только в тексте сцены.' },
      'r-chase': { t: 'check', title: 'Догнать его у ворот', skills: [['athletics', 'Атлетика'], ['acrobatics', 'Акробатика']], dc: 12, when: c(seg(R[0].check, 'Атлетика или Акробатика', ' Успех:')), yes: c(seg(R[0].check, 'герой у ворот', ' Провал:') + ' ' + seg(R[0].play, 'Савелий с задней площадки', '\n\nКонец')), no: c(seg(R[0].check, 'Савелий потерян', ' Без броска')) },
      'r-fork1': { t: 'fork', title: 'Что делают герои?', options: [{ label: R[0].choices[0], go: 'r-chase' }, { label: R[0].choices[1], go: 'r-photo' }, { label: R[0].choices[2], go: 'r-digger' }, { label: R[0].choices[3], go: 'r-portrait' }] },
      'r-klara': { t: 'talk', who: 'nina-run', title: 'Клара Рун нанимает бюро', img: 'nina-run', imgCap: klara.name, face: true, lines: [c(quote(R[1].play, 'Вы смотрели туда')), c(quote(R[1].play, 'Я не прошу вернуть его')), c(quote(R[1].play, 'Савелий всегда возвращался'))], rows: [{ k: 'Верный вопрос', v: seg(R[1].play, '«Куда он уходил', ' И, помолчав'), src: 'c' }, { k: 'Если её обвиняют', v: seg(R[1].play, 'Если кто-то прямо обвиняет', '\n\nЗа колумбарием'), src: 'c' }, ...personRows(klara)], knows: klara.knows, secret: klara.secret, reveal: klara.reveal },
      'r-note': { t: 'show', clue: 'hire-note', title: hNote.title, img: 'hire-envelope', imgCap: 'Конверт заказчицы', paper: hNote.text, task: cNote.statement },
      'r-helga': { t: 'talk', who: 'vera-meller', title: 'Хельга Меллер у ворот', img: 'vera-meller', imgCap: helga.name, face: true, lines: [c(quote(R[1].play, 'Сорок крон за звонок')), c(quote(R[1].play, 'Мы не ломаем двери'))], rows: personRows(helga), knows: helga.knows, secret: helga.secret, reveal: helga.reveal },
      'r-cut': { t: 'check', title: 'Срезать за колумбарием', skills: [['athletics', 'Атлетика']], dc: 12, when: c(seg(R[1].check, 'Срезанный путь:', ' Числа сцены')), yes: b('Мокрая стена колумбария позади: отряд у задней ограды, у сторожки. ○ +2.'), no: b('Сорвался: ○ +1 и △ +1.') },
      'r-insight': { t: 'check', title: 'Клара не плакала', skills: [['insight', 'Проницательность']], dc: 13, when: c(seg(R[1].check, 'Проницательность СЛ 13', ' Срезанный путь')), yes: c('Перчатки сухие, она не плакала.'), no: c('Без броска любой герой видит бирку магазина на её новом зонте.') },
      'r-fork2': { t: 'fork', title: 'Что делают герои?', options: [{ label: R[1].choices[0], say: b('Записка и конверт на пятьдесят крон у Ванды. Звонок в одиннадцать, каждый вечер.'), result: 'Заказ принят' }, { label: R[1].choices[1], result: 'Заказ взят на день' }, { label: R[1].choices[2], result: 'От денег отказались' }, { label: R[1].choices[3], go: 'r-cut' }, { label: R[1].choices[4], say: c(R[1].failForward), result: 'Спор с Хельгой при Кларе' }] },
    },
    rules: rc.world.tableGuidance.slice(0, 4).map((t, i) => ({ title: ['Шкала дистанции', 'Один район за вечер', 'Правило стола 3', 'Правило стола 4'][i], text: t, src: 'c' })).concat(rc.world.boundaries.slice(0, 1).map((t) => ({ title: 'Границы', text: t, src: 'c' }))),
  };

  /* ───────────── Корона из чужих костей ───────────── */
  const mc = D.mc, m1 = mc.e1, M = m1.scenes;
  const dara = by(mc.npcs, 'dara-vey'), osvin = by(mc.npcs, 'osvin-glod');
  const cSeam = by(mc.clues, 'seam-count'), cLamp = by(mc.clues, 'lamp-turn');
  const hDepth = by(mc.handouts, 'depth-sheet'), hDawn = by(mc.handouts, 'dawn-count'), hWays = by(mc.handouts, 'first-ways');
  const tEnc = by(mc.encounters, 'teeth-hollowed');
  const mcBook = {
    key: 'mc', title: mc.world.title, style: 'Гуашь и уголь, кость, соль, огонь', bookName: 'Костяной кодекс',
    party: mc.heroes.map((h) => h.key), defeat: 'На нуле хитов герой падает; правила смерти кампании решает ведущий.', chapterWord: 'Глава',
    pages: [
      {
        id: 'mc-open', chapter: 1, kind: 'opening', title: m1.title, place: 'salt-mouth', img: 'cover', imgLevel: 'chapter', imgCap: 'Глава 1',
        paras: [c(mark(m1.readAloud, [['двенадцать связок', 'm-depth'], ['Дара Вей', 'm-dara'], ['Освин Глод', 'm-osvin']]))],
        brief: { lead: m1.goal, rows: [['После чтения', seg(M[0].play, 'Сразу после вступления', ' Губы шва')]] },
      },
      {
        id: 'mc-s1', chapter: 1, kind: 'scene', title: M[0].title, place: 'salt-mouth', img: 'salt-mouth', imgLevel: 'place', imgCap: 'Соляной рот',
        paras: [
          c(mark(seg(M[0].play, 'Губы шва расходятся', ' Ведите счёт'), [['Освин считает по кольцам соли', 'm-seam']])),
          c(mark(seg(M[0].play, 'Дара отвечает коротко', ' На шестом счёте'), [['Дара отвечает коротко', 'm-dara2']])),
          c(mark(seg(M[0].play, 'На шестом счёте'), [['На шестом счёте из шва идёт тёплый выдох', 'm-exhale']])),
        ],
        fork: 'm-fork1', offText: ['m-dawn'],
        brief: { lead: seg(M[0].play, 'Ведите счёт по-настоящему', ' Дела:'), rows: [['Дела за счёт', seg(M[0].play, 'Дела:', ' Дара отвечает')], ['Если не вышло', M[0].failForward], ['Время', `${M[0].minutes} минут`]] },
      },
      {
        id: 'mc-s2', chapter: 1, kind: 'scene', title: M[1].title, place: 'hanging-teeth', img: 'hanging-teeth', imgLevel: 'place', imgCap: 'Висячие зубья',
        paras: [
          c(seg(M[1].play, 'Шов закрывается', ' Метка') + ' ' + mark(seg(M[1].play, 'Висячие зубья белеют', ' Освин ведёт'), [['Спуск с внутренней губы', 'm-descent']])),
          c(mark(seg(M[1].play, 'Освин ведёт по карнизу', ' Если его не'), [['Освин ведёт по карнизу', 'm-ways']])),
          c(mark(seg(M[1].play, 'Карниз обрывается', ' Впервые спросите'), [['сидят мёртвые в экспедиционных куртках', 'm-sitters'], ['головы медленно поворачиваются вслед пламени', 'm-lamp']])),
          c(seg(M[1].play, 'Освин, глухо:')),
        ],
        fork: 'm-fork2',
        brief: { lead: seg(M[1].play, 'Впервые спросите', ' Освин, глухо'), rows: [['Броски', M[1].check], ['Если не вышло', M[1].failForward], ['Время', `${M[1].minutes} минут`]], demoEnd: true },
      },
    ],
    links: {
      'm-depth': { t: 'show', title: hDepth.title, paper: hDepth.text, task: hDepth.unlock },
      'm-dawn': { t: 'show', title: hDawn.title, paper: hDawn.text, task: hDawn.unlock },
      'm-dara': { t: 'talk', who: 'dara-vey', title: 'Дара Вей у повозки', img: 'dara-vey', imgCap: dara.name, face: true, lines: [c(quote(m1.readAloud, 'Сначала — люди.'))], rows: personRows(dara), knows: dara.knows, secret: dara.secret, reveal: dara.reveal },
      'm-dara2': { t: 'talk', who: 'dara-vey', title: 'Спросить Дару о бабушке', img: 'dara-vey', imgCap: dara.name, face: true, lines: [c(quote(M[0].play, 'Я не пошла её провожать')), c(quote(M[0].play, 'Не спрашивайте, что я хочу'))], rows: [{ k: 'Цена', v: M[0].choices[2], src: 'c' }, ...personRows(dara)], knows: dara.knows, secret: dara.secret, reveal: dara.reveal },
      'm-osvin': { t: 'talk', who: 'osvin-glod', title: 'Освин Глод считает', img: 'osvin-glod', imgCap: osvin.name, face: true, lines: [c(quote(M[0].play, 'Раз — свет.')), c(quote(M[0].play, 'Пух. Каждый год больше'))], rows: [{ k: 'Если расспросить', v: M[0].choices[1], src: 'c' }, ...personRows(osvin)], knows: osvin.knows, secret: osvin.secret, reveal: osvin.reveal },
      'm-seam': { t: 'clue', clue: 'seam-count', title: cSeam.name, look: c(cSeam.appearance), means: c(cSeam.statement), how: c(cSeam.discovery) },
      'm-exhale': { t: 'check', title: 'Выдох на шестом счёте', skills: [['athletics', 'Сила (Атлетика)']], dc: 10, when: c(seg(M[0].check, 'На шестом счёте', ' Раздатки:')), yes: b('Герой держится за стену и входит в шов на своём счёте.'), no: c(seg(M[0].check, 'выдох выносит его на губу', ' Кто снаружи')) },
      'm-fork1': { t: 'fork', title: 'На что стол тратит счёты?', options: M[0].choices.map((label, i) => ({ label, go: [null, 'm-osvin', 'm-dara2', null, 'm-exhale'][i] || undefined, result: label.split(' (')[0] })) },
      'm-descent': { t: 'check', title: 'Спуск с губы', skills: [['athletics', 'Сила (Атлетика)']], dc: 10, when: c(seg(M[1].check, 'Спуск с губы:', ' Улика')), yes: b('Три человеческих роста позади: герой стоит на карнизе под зубьями.'), no: c(seg(M[1].failForward, 'Если спуск сорвался', ' Улика не теряется')) },
      'm-ways': { t: 'show', title: hWays.title, paper: hWays.text, task: hWays.unlock },
      'm-lamp': { t: 'clue', clue: 'lamp-turn', title: cLamp.name, img: 'token-hollowed', imgCap: 'Выеденный', object: true, look: c(cLamp.appearance), means: c(cLamp.statement), how: c(cLamp.discovery) },
      'm-sitters': { t: 'fight', enc: 'teeth-hollowed', title: tEnc.title, img: 'token-hollowed', imgCap: 'Выеденный', object: true, lines: [c(quote(M[1].play, 'Это Гн… Гнат.')), c(quote(M[1].play, 'Я их знал.'))], lineName: 'Освин', trigger: c(seg(tEnc.trigger, 'Сцена 3 вечера 1:', ' Цель:')), goal: c(seg(tEnc.trigger, 'Срезать подвесной тайник', ' Мирный путь:')), peace: c(seg(tEnc.trigger, 'Можно отойти', ' Тактика:')), tactics: c(seg(tEnc.trigger, 'Выеденные идут', ' Бой кончается')), start: c('Головы повернулись к вашему огню. Они встают.'), win: b('Мёртвые лежат и больше не встают. Тайник срезан: запас +3.'), lose: c(seg(tEnc.trigger, 'Если кто-то дошёл', ' Бой кончается')) },
      'm-fork2': { t: 'fork', title: 'Огонь или тьма?', options: M[1].choices.map((label, i) => ({ label, go: ['m-sitters', 'm-sitters', 'm-lamp', null][i] || undefined, result: label.split(':')[0] })) },
    },
    rules: mc.world.tableGuidance.slice(0, 3).map((t, i) => ({ title: ['Лист глубины и запаса', 'Огонь или тьма', 'Правило стола 3'][i], text: t, src: 'c' })).concat(mc.world.boundaries.slice(0, 1).map((t) => ({ title: 'Границы', text: t, src: 'c' }))),
  };

  window.BOOKS = { lh: lhBook, rc: rcBook, mc: mcBook };
})();
