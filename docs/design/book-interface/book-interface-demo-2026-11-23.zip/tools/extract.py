#!/usr/bin/env python3
"""Data of the book-interface demo (Stage 1010), read from the repository as it is: the library's
55 campaigns for the shelf, and two campaigns in full (package + book document) for the books.
Writes js/data.js and img/jobs.json (pictures to convert). Text is copied verbatim; nothing is written."""
import json, re, sys
from pathlib import Path

REPO = Path(sys.argv[1])
OUT = Path(__file__).resolve().parent.parent
LIB = REPO / "fixtures/campaign-library"
jobs = []  # [src, dst, width]


def pic(src, dst, width):
    if (REPO / src).exists():
        jobs.append([str(REPO / src), dst, width])
        return dst
    return None


themes = json.loads((REPO / "apps/web/src/visual/campaign-themes/catalog.json").read_text())
theme_by_name = {n: t for t in themes for n in [t["id"], *t["names"]]}

shelf = []
for cid in json.loads((LIB / "index.json").read_text())["campaigns"]:
    lib = json.loads((LIB / cid / "library.json").read_text())
    th = theme_by_name.get(cid) or theme_by_name.get(lib["title"]) or {}
    tid = th.get("id", cid)
    shelf.append({
        "id": cid, "title": lib["title"], "genre": lib["genre"], "audience": lib["audience"],
        "pitch": lib["pitch"], "duration": lib["duration"],
        "variants": [v["label"] for v in lib["variants"]],
        "accent": th.get("accent", "#c9a45c"), "lettering": th.get("lettering", "story"),
        "cover": pic(lib["cover"], f"img/cover/{cid}.webp", 360),
        "material": pic(f"apps/web/public/table-materials/{tid}.webp", f"img/mat/{tid}.webp", 240),
    })
for t in themes:
    if t["id"] in ("ravenford", "hollowmere"):
        shelf.append({
            "id": t["id"], "title": t["names"][0], "genre": "Встроенное приключение", "audience": "",
            "pitch": "", "duration": "", "variants": [], "builtin": True,
            "accent": t["accent"], "lettering": t["lettering"], "cover": None,
            "material": pic(f"apps/web/public/table-materials/{t['id']}.webp", f"img/mat/{t['id']}.webp", 240),
        })


def campaign(cid, root, skin):
    lib = json.loads((LIB / cid / "library.json").read_text())
    pkg = json.loads((LIB / cid / "packages" / f"{lib['defaultVariant']}.json").read_text())
    book = json.loads((LIB / cid / "book.json").read_text())
    rt = f"{root}/assets/runtime"
    ents = {e["key"]: e for e in pkg["entities"]}
    for e in pkg["entities"]:
        p = pic(f"{rt}/{e['key']}.webp", f"img/{skin}/{e['key']}.webp", 900 if e["kind"] == "location" else 480)
        if p:
            e["picture"] = p
    for ch in book["chapters"][4:]:
        ch["pages"] = ch["pages"][:1]
        for p in ch["pages"]:
            p["text"] = p["text"][:400]
    maps = {}
    man = REPO / root / "assets/battle-maps/manifest.json"
    if man.exists():
        for m in json.loads(man.read_text())["maps"]:
            maps[m["encounter"]] = pic(f"{root}/assets/battle-maps/{m['file']}", f"img/{skin}/bm-{m['encounter']}.webp", 1200)
    return {
        "id": cid, "skin": skin, "title": lib["title"], "genre": lib["genre"], "pitch": lib["pitch"],
        "cover": pic(lib["cover"], f"img/{skin}/cover.webp", 720),
        "worldMap": pic(f"{root}/assets/world-map/world-map.webp", f"img/{skin}/world-map.webp", 1400),
        "world": pkg["world"], "entities": pkg["entities"], "party": pkg["party"],
        "clues": pkg["clues"], "encounters": pkg["encounters"], "maps": pkg["maps"],
        "situations": pkg["situations"], "possessions": pkg["possessions"],
        "knowledge": [k for k in pkg["knowledge"] if k["scope"]["kind"] == "PUBLIC"],
        "battleMaps": maps, "book": book,
    }


books = {
    "lh": campaign("lighthouse", "campaigns/lighthouse", "lh"),
    "rc": campaign("rain-check", "campaigns/noir-2026/rain-check", "rc"),
    "mc": campaign("marrow-crown", "campaigns/dark-fantasy-2026/marrow-crown", "mc"),
}
data = {"shelf": shelf, "books": books}
(OUT / "js/data.js").write_text("window.DATA=" + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n")
(OUT / "img/jobs.json").write_text(json.dumps(jobs))
print(len(shelf), "on the shelf;", len(jobs), "pictures;", (OUT / "js/data.js").stat().st_size // 1024, "KB of data")
