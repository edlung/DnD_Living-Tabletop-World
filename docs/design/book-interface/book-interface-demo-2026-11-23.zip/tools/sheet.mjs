// Contact sheet: node sheet.mjs out.png cols width file1 file2 ...
import { createRequire } from 'node:module'; import { join } from 'node:path';
const require = createRequire(join(process.cwd(), 'package.json')); const sharp = require('sharp');
const [out, cols, w, ...files] = process.argv.slice(2); const C = +cols, W = +w;
const tiles = await Promise.all(files.map(async (f) => { const b = await sharp(f).resize({ width: W }).png().toBuffer(); const m = await sharp(b).metadata(); return { b, h: m.height }; }));
const rows = []; for (let i = 0; i < tiles.length; i += C) rows.push(tiles.slice(i, i + C));
const H = rows.map((r) => Math.max(...r.map((t) => t.h)));
const comp = []; let y = 0; rows.forEach((r, ri) => { r.forEach((t, ci) => comp.push({ input: t.b, left: ci * (W + 6), top: y })); y += H[ri] + 6; });
await sharp({ create: { width: C * (W + 6), height: y, channels: 3, background: '#555' } }).composite(comp).png().toFile(out);
