// Screenshots of the demo's frames at several widths, with headless Chromium (the repository's
// Playwright). Run from the repo root: node <this> <out dir> [filter]
// Each scenario: a hash to open, a script run in the page (the demo's own actions), a size.
import { createRequire } from 'node:module';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';

const require = createRequire(join(process.cwd(), 'package.json'));
const { chromium } = require('@playwright/test');
const OUT = process.argv[2];
const only = process.argv[3];
mkdirSync(OUT, { recursive: true });
const SIZES = { w: [1440, 900], l: [1024, 768], t: [768, 1024], p: [390, 844] };
const S = [
  ['plate', 'shelf', '', 'wp'],
  ['shelf', 'shelf', "store.set(S=>{S.signedIn=true})", 'wltp'],
  ['peek', 'shelf', "store.set(S=>{S.signedIn=true}); ACT.peek('moon-pearl')", 'wp'],
  ['lh-story', 'lh', '', 'wltp'],
  ['rc-scene', 'rc', "ACT.turn('1'); ACT.turn('1')", 'w'],
  ['mc-story', 'mc', "ACT.turn('1')", 'wl'],
  ['lh-path', 'lh', "ACT.go('story:path')", 'w'],
  ['lh-scene', 'lh', "ACT.go('scene'); ACT.card('person:runa')", 'wp'],
  ['rc-heroes', 'rc', "ACT.go('heroes')", 'w'],
  ['mc-world', 'mc', "ACT.go('world:places')", 'w'],
  ['lh-journal', 'lh', "ACT.findClue('festival-loop'); ACT.go('journal:known')", 'w'],
  ['rc-table', 'rc', "ACT.go('table:screen')", 'w'],
  ['mc-rules', 'mc', "ACT.go('rules:toolbox')", 'w'],
  ['lh-fight', 'lh', "ACT.startFight('dock-keepers')", 'wlp'],
  ['mc-fight', 'mc', "ACT.startFight(store.data().encounters[0].key)", 'w'],
  ['lh-map', 'lh', "ACT.map()", 'w'],
  ['hero', 'rc', "ACT.turn('1');ACT.turn('1');document.querySelector('[data-act=ask]').click();ACT.view('hero')", 'wp'],
  ['hero-sheet', 'mc', "ACT.view('hero'); ACT.heroPart('hero')", 'wp'],
  ['table-cover', 'lh', "ACT.view('table')", 'wp'],
  ['table-story', 'mc', "ACT.cast('story:'); ACT.view('table')", 'w'],
  ['table-fight', 'rc', "ACT.startFight(store.data().encounters[0].key); ACT.view('table')", 'w'],
  ['desk', 'manuscript', '', 'wp'],
  ['ms-chapter', 'manuscript', "ACT.msOpen(); ACT.msPage('chapter'); ACT.msEdit()", 'wlp'],
  ['ms-proof', 'manuscript', "ACT.msOpen(); ACT.msPage('proof')", 'w'],
  ['ms-proposal', 'manuscript', "ACT.msOpen(); ACT.msPage('proposal')", 'w'],
  ['ms-binding', 'manuscript', "ACT.msOpen(); ACT.msPage('binding')", 'w'],
  ['az', 'az', '', 'wp'],
];
const browser = await chromium.launch();
const problems = [];
for (const [name, hash, script, sizes] of S) {
  if (only && !name.includes(only)) continue;
  for (const k of sizes) {
    const [width, height] = SIZES[k];
    const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 });
    page.on('pageerror', (e) => problems.push(`${name}/${k}: ${e.message}`));
    await page.goto(`http://localhost:4377/preview.html#${hash}`, { waitUntil: 'networkidle' });
    if (script) await page.evaluate(script);
    await page.waitForTimeout(500);
    const wide = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    if (wide > 1) problems.push(`${name}/${k}: page is ${wide}px wider than the screen`);
    await page.screenshot({ path: join(OUT, `${name}-${width}.png`) });
    await page.close();
  }
}
await browser.close();
console.log(problems.length ? problems.join('\n') : 'no page errors, no horizontal scroll');
