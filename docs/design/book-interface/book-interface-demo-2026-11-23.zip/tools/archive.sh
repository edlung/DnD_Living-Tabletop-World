#!/bin/sh
# The demo's sources for the repository: the page, its styles and scripts, the tools; not the
# generated data (js/data.js, js/az.js) nor the pictures (img/). Usage: archive.sh <out.zip>
D=$(cd "$(dirname "$0")/.." && pwd)
cd "$D" && rm -f "$1" && zip -q -r "$1" index.html css js tools -x 'js/data.js' 'js/az.js' 'tools/extra/*' && unzip -l "$1" | tail -1
