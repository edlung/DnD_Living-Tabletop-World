#!/bin/sh
# Local preview of the demo: the publish skeleton around index.html, with cache-busting.
D=$(cd "$(dirname "$0")/.." && pwd); V=$(date +%s)
python3 - "$D" "$V" <<'PY'
import sys,re
d,v=sys.argv[1],sys.argv[2]
head='<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;padding:env(safe-area-inset-top,0px) 0 env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style></head><body>'
s=open(d+'/index.html').read()
s=re.sub(r'((?:css|js)/[\w.-]+\.(?:css|js))"', r'\1?v='+v+'"', s)
open(d+'/preview.html','w').write(head+s+'</body></html>')
PY
