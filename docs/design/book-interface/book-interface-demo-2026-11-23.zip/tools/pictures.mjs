// Converts the demo's pictures: campaign pictures listed by extract.py (img/jobs.json) and the
// book materials generated with Codex CLI (argv[2] = their out folder). Run from the repo root so
// that the repository's sharp is found: node <this> <art out folder>
import { createRequire } from 'node:module';
import { mkdirSync, readFileSync, readdirSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(join(process.cwd(), 'package.json'));
const sharp = require('sharp');
const OUT = join(dirname(fileURLToPath(import.meta.url)), '..');
const jobs = JSON.parse(readFileSync(join(OUT, 'img/jobs.json'), 'utf8'));
const art = process.argv[2];
if (art && existsSync(art)) {
  for (const f of readdirSync(art).filter((n) => n.endsWith('.png'))) {
    const icon = f.includes('-part-') || /-(tab|proof|seal|quill)\.png$/.test(f);
    const wide = /-(shelf|desk|tray)\.png$/.test(f);
    jobs.push([join(art, f), `img/ui/${f.replace('.png', '.webp')}`, icon ? 160 : wide ? 1600 : 900]);
  }
}
let done = 0;
for (const [src, dst, width] of jobs) {
  const to = join(OUT, dst);
  mkdirSync(dirname(to), { recursive: true });
  await sharp(src).resize({ width, withoutEnlargement: true }).webp({ quality: 80, alphaQuality: 90 }).toFile(to);
  done += 1;
}
console.log(`${done} pictures written`);
