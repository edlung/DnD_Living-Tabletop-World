#!/usr/bin/env python3
"""The acceptance map of Stage 1000 (docs/BOOK_INTERFACE_MAP.md and docs/book-interface-map/):
every control of today, read from the code into three inventories, with the book, part and page it
goes to. A row's destination is its section's, unless a rule on the row's words names another.
Also writes the demo's A–Z data (js/az.js) with whether that page is in the demo."""
import json, re, sys
from pathlib import Path

SCR = Path(sys.argv[1])          # the scratchpad with the three inventories
REPO = Path(sys.argv[2])
DEMO = Path(__file__).resolve().parent.parent
FILES = [("dm-tools", "The DM's tool sheets"), ("play", "The play screen and the table's screen"), ("entry-workshop", "The way in and the workshop")]

# Section defaults: (book, part › page). Book names: Shelf, DM, Hero, Table (the open book on the
# table), Manuscript, Kit (a piece of every book).
SECTION = {
    "Party": ("DM", "Heroes › the party / a hero's spread"),
    "Encounter": ("DM", "Scene › a prepared fight (card)"),
    "Session": ("DM", "Table › the meeting"),
    "Table screen": ("DM", "Table › the table's screen"),
    "Notes": ("DM", "Journal › notes (and the margin of each page)"),
    "Time and weather": ("DM", "Running head; World › time and weather"),
    "Add to the world": ("DM", "World › blank pages"),
    "Images": ("DM", "The plate of its page; World › pictures"),
    "History": ("DM", "Journal › what changed (colophon)"),
    "Players": ("DM", "Table › who sits here"),
    "Journal": ("DM+Hero", "Journal"),
    "Places": ("DM+Hero", "World › places; the map fold-out"),
    "Chat": ("DM+Hero", "Table › talk"),
    "Dice": ("Kit", "The foot of every page (dice tray)"),
    "Rules": ("DM+Hero", "Rules (appendix)"),
    "Top bar": ("Kit", "Running head"),
    "Dock and More": ("Kit", "Bookmarks (the parts)"),
    "Sheets and screen-wide behaviour": ("Kit", "Pages: Escape, focus, the open page remembered"),
    "Scene / stage": ("DM+Hero", "Scene"),
    "Detail panel": ("DM+Hero", "Scene › the card on the right page"),
    "Exploration and conversation": ("DM+Hero", "Scene › talk and act"),
    "Acting bar": ("DM", "Heroes › act as a hero"),
    "Table asks over the stage": ("Kit", "Slips at the foot of the page"),
    "Combat": ("DM+Hero", "Fight fold-out"),
    "Combat — \"What can I do?\" hint": ("Hero", "Slip «What can I do?»"),
    "Dice — the rolling dice": ("Kit", "The foot of every page (the roll's result)"),
    "Dice — the Dice sheet": ("Kit", "The foot of every page (dice tray)"),
    "Dice — elsewhere": ("Kit", "The foot of every page"),
    "Character dialog": ("Hero", "Hero (for the DM: Heroes › a hero's spread)"),
    "Builder and level-up": ("Hero", "Hero › the first pages (making a hero, a new level)"),
    "Chronicle and keepsakes": ("DM+Hero", "Journal › Chronicle, keepsakes"),
    "Campaign rituals in play": ("DM+Hero", "Table › the meeting (agreement, stars, the next game)"),
    "Journal (as a player sees it)": ("Hero", "Journal"),
    "Places (as a player sees it)": ("Hero", "World"),
    "Chat and voice": ("DM+Hero", "Table › talk, voice"),
    "Comforts": ("DM+Hero", "Table › cheers; running head › size of text; slip › a break"),
    "Rules (everyone's sheet, brief)": ("DM+Hero", "Rules (appendix)"),
    "DM's book (brief)": ("DM", "Story"),
    "Native-only": ("Kit", "Native shells (unchanged); the TV panel → Table › the table's screen"),
    "Table screen app and casts": ("Table", "The open book on the table"),
    "Way in › Sign-in": ("Shelf", "The bookplate (sign in)"),
    "Way in › Checking": ("Shelf", "The bookplate (sign in)"),
    "Way in › Development personas": ("Shelf", "The bookplate (development personas)"),
    "Way in › Invitation": ("Shelf", "An invitation as a page of the shelf"),
    "Way in › Replace sign-in": ("Shelf", "An invitation as a page of the shelf"),
    "Way in › Signed out": ("Shelf", "The bookplate (sign in)"),
    "Way in › Table join": ("Shelf", "Sit down by the table's code"),
    "Way in › Password reset": ("Shelf", "The bookplate (a new password)"),
    "Way in › Hub": ("Shelf", "The shelf (my books, the library, finished)"),
    "Way in › Account": ("Shelf", "The account (bookplate of the shelf)"),
    "Way in › Sign-out dialog": ("Shelf", "The account › sign out"),
    "Way in › Session opening": ("Kit", "Opening a book; a page that broke"),
    "Way in › Lobby banner": ("DM+Hero", "Table › the meeting; slips"),
    "Way in › Privacy notice": ("Shelf", "Colophon › privacy"),
    "Way in › Broken page": ("Kit", "A page that broke"),
    "Workshop › Frame and access": ("Manuscript", "The desk (access)"),
    "Workshop › Home": ("Manuscript", "The desk (manuscripts, bound books)"),
    "Workshop › Draft editor frame": ("Manuscript", "The manuscript book (running head, bookmarks)"),
    "Workshop › Scenario tab": ("Manuscript", "Contents; reading the manuscript"),
    "Workshop › Empty draft": ("Manuscript", "The desk › a new manuscript (library, file)"),
    "Workshop › Scenario browser": ("Manuscript", "Pages of the manuscript (read)"),
    "Workshop › Structured editing": ("Manuscript", "A page edited in place; fields in the margin"),
    "Workshop › Targeted AI edit": ("Manuscript", "Proof › a proofreader's marks"),
    "Workshop › Protections": ("Manuscript", "The margin › a page kept from changes"),
    "Workshop › Comparison and review": ("Manuscript", "Proofs side by side (compare, restore)"),
    "Workshop › Generation tab": ("Manuscript", "Title page (the commission) › proposed pages"),
    "Workshop › World preview tab": ("Manuscript", "Proof copy › the DM's book"),
    "Workshop › Character preview": ("Manuscript", "Proof copy › a hero's book"),
    "Workshop › Pictures": ("Manuscript", "Plates (illustrations)"),
    "Workshop › Activation tab": ("Manuscript", "Binding"),
}
# Rules on a row's words: (regex, book, page) — first match wins over the section's default.
RULES = [
    (r"\(during fight\)|turn order|initiative|reaction window|End encounter", "DM", "Fight fold-out"),
    (r"handout|envelope|kept for later|Раздат", "DM", "Journal › handouts"),
    (r"trap|stress|contagion|ruling", "DM", "Rules › toolbox"),
    (r"random table", "DM", "Rules › tables of chance"),
    (r"music|ambience|soundscape|Sound on|place sound|place's sound", "DM", "Table › sound and music"),
    (r"cheer", "DM+Hero", "Table › cheers"),
    (r"[Tt]ext size|motion", "Kit", "Running head › reading settings"),
    (r"[Pp]ause", "DM+Hero", "Table › the meeting (pause); slip"),
    (r"How to play|About this game|DM's guide|guide", "DM+Hero", "Rules › how to play"),
    (r"Sign out|Leave session", "Shelf", "The account › sign out"),
    (r"Replace|Line up the grid|Request a picture|Upload a battle map|Images \(DM\)", "DM", "The plate of its page"),
    (r"[Pp]erform|NPC shop|shop|Change by hand|NPC edit|profile edit", "DM", "Scene › a person's card"),
    (r"Ask for a check|check request", "DM", "Story card › ask a roll; Heroes › a hero's spread"),
    (r"Print|save as PDF", "Hero", "Hero › the sheet to print"),
    (r"calendar", "DM", "Table › the meeting › the next game"),
]
DEMO_PAGES = {  # pages the demo shows (the A–Z view marks the others)
    "Shelf": True, "Table": True, "Manuscript": True, "Kit": True,
}
NOT_IN_DEMO = [r"development personas", r"[Pp]assword", r"privacy", r"Native shells", r"Proofs side", r"a page that broke", r"voice", r"Print"]


def rows_of(path):
    section, out = None, []
    for line in path.read_text().splitlines():
        m = re.match(r"^## (.+)", line)
        if m:
            section = m.group(1).strip()
            continue
        if not line.startswith("|") or line.startswith("|---") or line.startswith("| Control or view"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) >= 4 and section not in ("Counts", "Notes"):
            out.append((section, cells[0], cells[1], cells[2], cells[3]))
    return out


def dest(section, text):
    for rx, book, page in RULES:
        if re.search(rx, text):
            return book, page
    for key in sorted(SECTION, key=len, reverse=True):
        if section.startswith(key):
            return SECTION[key]
    if section.startswith("Combat"):
        return SECTION["Combat"]
    return ("?", "?")


all_rows, docs = [], {}
for name, title in FILES:
    rows = rows_of(SCR / f"controls-{name}.md")
    md = [f"# {title}: where each control goes", "",
          "Part of the acceptance map of the book interface (`docs/BOOK_INTERFACE_MAP.md`). Columns: what there is today, who has it, the file, and the book › page it goes to.", ""]
    section = None
    for sec, ctrl, what, who, file in rows:
        book, page = dest(sec, f"{ctrl} {what}")
        if sec != section:
            md += ["", f"## {sec}", "", "| Control or view | What it does | Who | File | Goes to |", "|---|---|---|---|---|"]
            section = sec
        md.append(f"| {ctrl} | {what} | {who} | {file} | **{book}** › {page} |")
        shown = DEMO_PAGES.get(book, True) and not any(re.search(rx, page + ctrl) for rx in NOT_IN_DEMO)
        all_rows.append({"area": title, "section": sec, "control": re.sub(r"[`*]", "", ctrl), "who": who, "book": book, "page": page, "demo": shown})
    docs[name] = "\n".join(md) + "\n"

out = REPO / "docs/book-interface-map"
out.mkdir(exist_ok=True)
for name, text in docs.items():
    (out / f"{name}.md").write_text(text)
(DEMO / "js/az.js").write_text("window.AZ=" + json.dumps(all_rows, ensure_ascii=False, separators=(",", ":")) + ";\n")
unknown = [r for r in all_rows if r["book"] == "?"]
from collections import Counter
print(len(all_rows), "rows;", len(unknown), "without a destination;", Counter(r["book"] for r in all_rows))
print(sum(r["demo"] for r in all_rows), "with their page in the demo")
for r in unknown[:10]:
    print("  ?", r["section"], "|", r["control"][:60])
