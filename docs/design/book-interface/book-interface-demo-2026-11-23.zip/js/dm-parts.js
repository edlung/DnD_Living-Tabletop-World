// The DM's book, parts Heroes, World, Journal, Table and Rules. Each part: a contents strip of its
// pages at the top of the left page, the page itself, and the right page for what is chosen.
(function () {
  const st = window.store, { esc, by } = st;
  const ACT = (window.ACT = window.ACT || {}), PARTS = (window.DM_PARTS = window.DM_PARTS || {});
  const tabs = (part, list) => {
    const cur = st.book().partPage[part] || list[0][0];
    return `<nav class="pagetabs" aria-label="Страницы части">${list.map(([id, word]) => `<button data-act="go" data-arg="${part}:${id}" ${cur === id ? 'aria-current="page"' : ''}>${word}</button>`).join('')}</nav>`;
  };
  const cur = (part, def) => st.book().partPage[part] || def;
  const L = (kicker, title, body, extra = '') => `<section class="page page-l scroll"><p class="kicker">${kicker}</p>${extra}<h2>${title}</h2>${body}</section>`;
  const R = (body) => `<section class="page page-r scroll">${body}</section>`;
  const hint = (t) => `<div class="card"><p class="muted" style="margin:0">${t}</p></div>`;

  // ── Heroes ───────────────────────────────────────────────────────────────────────────
  function heroLine(k) {
    const e = st.ent(k), h = st.book().heroes[k], sh = e.sheet, pct = Math.round((100 * h.hp) / sh.hitPoints.max);
    return `<li class="hero-line"><button class="moment link" style="width:100%;border-bottom:0;text-align:left;grid-template-columns:48px 1fr auto" data-act="card2" data-arg="hero:${k}">
      ${st.img(e.picture, '', 'avatar')}<span><b>${esc(e.name)}</b><small>${st.classWords(sh)} · КД ${sh.armorClass}</small>
      <span class="hp" style="--p:${pct}%"><span></span></span></span><span class="tabnum">${h.hp}/${sh.hitPoints.max}</span></button></li>`;
  }
  function heroSheet(k) {
    const e = st.ent(k), sh = e.sheet, h = st.book().heroes[k];
    const ab = Object.entries(sh.abilities).map(([a, v]) => `<div class="ab"><small>${st.abilities[a].slice(0, 3)}</small><b>${st.sign(st.mod(v))}</b><span>${v}</span></div>`).join('');
    const items = st.data().possessions.filter((p) => p.holder === k).map((p) => st.ent(p.item)?.name || p.catalog);
    return `<div class="card"><div class="row" style="flex-wrap:nowrap;align-items:flex-start">${st.img(e.picture, '', 'portrait')}<div><h4>${esc(e.name)}</h4><p class="muted" style="margin:0;font-size:14px">${esc(e.description)}</p></div></div>
      <div class="abilities">${ab}</div>
      <dl><dt>Хиты</dt><dd><span class="row"><button class="btn" data-act="hp" data-arg="${k}:-1" aria-label="Минус хит">−</button><b class="tabnum">${h.hp} / ${sh.hitPoints.max}</b><button class="btn" data-act="hp" data-arg="${k}:1" aria-label="Плюс хит">+</button></span></dd>
      <dt>Навыки</dt><dd>${sh.skills.proficient.map((s) => `<button class="link" data-act="askSkill" data-arg="${k}:${s}">${st.skills[s]?.[0] || s} ${st.sign(st.bonus(k, { kind: 'skill', skill: s }))}</button>`).join(', ')}</dd>
      <dt>Оружие</dt><dd>${st.weaponWords(sh) || '—'}</dd><dt>С собой</dt><dd>${items.map(esc).join(', ') || '—'}</dd>
      <dt>Состояния</dt><dd>${h.conditions.join(', ') || 'нет'} <button class="btn quiet" data-act="cond" data-arg="${k}">+ состояние</button></dd></dl>
      <div class="row"><button class="btn" data-act="say" data-arg="Мастер действует за героя игрока, с причиной — как сегодня в продукте.">Действовать за героя</button><button class="btn" data-act="say" data-arg="Дать вещь, деньги или раздатку — форма на этой же странице.">Дать вещь</button><button class="btn quiet" data-act="say" data-arg="Печать листа героя — из его книги.">Лист для печати</button></div></div>`;
  }
  ACT.card2 = (arg) => st.set(() => { st.book().card2 = arg; });
  ACT.hp = (arg) => st.set(() => { const [k, d] = arg.split(':'); const h = st.book().heroes[k], max = st.ent(k).sheet.hitPoints.max; h.hp = Math.max(0, Math.min(max, h.hp + +d)); }, 'Хиты изменены');
  ACT.cond = (k) => st.set(() => { const c = st.book().heroes[k].conditions; c.includes('отравлен') ? c.splice(c.indexOf('отравлен'), 1) : c.push('отравлен'); }, 'Состояние изменено');
  ACT.askSkill = (arg) => {
    const [k, s] = arg.split(':');
    st.set((S) => { S.asks.push({ id: `a${S.asks.length + 1}`, hero: k, check: { kind: 'skill', skill: s }, dc: 12, status: 'open', skin: S.skin }); }, `Бросок попрошен: ${st.skills[s]?.[0]}`);
    st.say('Записка с броском ушла в книгу героя.');
  };
  PARTS.heroes = () => {
    const page = cur('heroes', 'party'), D = st.data(), sel = (st.book().card2 || '').startsWith('hero:') ? st.book().card2.slice(5) : D.party[0];
    const left = L('Герои', page === 'party' ? 'Отряд' : 'Страница отряда', page === 'party'
      ? `<ul class="moments">${D.party.map(heroLine).join('')}</ul><p class="muted">Нажмите на героя — его лист откроется справа.</p>`
      : `<div class="card"><h4>Отдых</h4><div class="row"><button class="btn" data-act="rest" data-arg="short">Короткий отдых</button><button class="btn" data-act="rest" data-arg="long">Долгий отдых</button></div></div>
         <div class="card"><h4>Опыт и уровень</h4><div class="row"><button class="btn" data-act="say" data-arg="Повышение уровня отряда: каждый игрок выбирает своё в книге героя.">Поднять уровень отряду</button></div></div>
         <div class="card"><h4>Деньги и вещи</h4><div class="row"><button class="btn" data-act="say" data-arg="Выдать монеты или вещь из каталога — одной формой.">Выдать отряду</button></div></div>`, tabs('heroes', [['party', 'Отряд'], ['page', 'Страница отряда']]));
    return left + R(heroSheet(sel));
  };
  ACT.rest = (k) => st.set(() => { const b = st.book(); if (k === 'long') Object.keys(b.heroes).forEach((h) => { b.heroes[h].hp = st.ent(h).sheet.hitPoints.max; }); b.time += k === 'long' ? 8 * 3600 : 3600; }, k === 'long' ? 'Долгий отдых' : 'Короткий отдых');

  // ── World ────────────────────────────────────────────────────────────────────────────
  PARTS.world = () => {
    const page = cur('world', 'places'), D = st.data(), b = st.book();
    const T = tabs('world', [['places', 'Места'], ['people', 'Люди'], ['time', 'Время и погода'], ['blank', 'Чистые страницы'], ['pictures', 'Картинки']]);
    if (page === 'places' || page === 'people') {
      const list = D.entities.filter((e) => e.kind === (page === 'places' ? 'location' : 'npc'));
      const sel = (b.card2 || '').split(':')[1] && st.ent(b.card2.split(':')[1])?.kind === (page === 'places' ? 'location' : 'npc') ? st.ent(b.card2.split(':')[1]) : list[0];
      return L('Мир', page === 'places' ? 'Места' : 'Люди', `<ul class="grid-list">${list.map((e) => `<li><button class="thumb" data-act="card2" data-arg="w:${e.key}" ${sel.key === e.key ? 'aria-current="true"' : ''}>${st.img(e.picture)}<span>${esc(e.name)}</span></button></li>`).join('')}</ul>
        ${page === 'places' ? '<button class="btn" data-act="map">Развернуть карту мира</button>' : ''}`, T)
        + R(`${window.plate(sel.picture, sel.name, sel.key)}<div class="card"><h4>${esc(sel.name)}</h4><p class="read" style="font-size:16px;margin:0">${esc(sel.description)}</p>
        ${page === 'places' ? `<div class="row"><button class="btn primary" data-act="moveTo" data-arg="${sel.key}">Сделать сценой</button><button class="btn" data-act="say" data-arg="Звук места и его картинку для экрана выбирают здесь же.">Звук места</button></div>` : `<button class="btn" data-act="card" data-arg="person:${sel.key}">Карточка для игры</button>`}</div>`);
    }
    if (page === 'time') {
      return L('Мир', 'Время и погода', `<p class="read" style="font-size:40px;margin:0;font-family:var(--f-display)">${st.hhmm(b.time)}</p>
        <div class="row">${[['+10 мин', 600], ['+1 час', 3600], ['До утра', 'dawn']].map(([w, s]) => `<button class="btn" data-act="time" data-arg="${s}">${w}</button>`).join('')}</div>
        <label class="field"><span>Погода</span><select id="weather" data-weather>${['clear', 'cloudy', 'rain', 'storm', 'fog', 'wind', 'snow'].map((w) => `<option value="${w}" ${b.weather === w ? 'selected' : ''}>${st.weatherWord(w)}</option>`).join('')}</select></label>`, T)
        + R(hint('Время и погода видны в колонтитуле каждой страницы; нажатие на колонтитул открывает эту страницу.'));
    }
    if (page === 'blank') {
      return L('Мир', 'Чистые страницы', `<p class="muted">Человек, место или вещь, которых не было в истории. Предложение проверяет мир, прежде чем оно войдёт в него.</p>
        <form class="card" data-form="add"><label class="field"><span>Что добавить</span><select id="add-kind" name="kind"><option value="npc">Человека</option><option value="location">Место</option><option value="item">Вещь</option></select></label>
        <label class="field"><span>Имя</span><input id="add-name" name="name" required placeholder="Например: Смотритель буя"></label>
        <label class="field"><span>Какой он</span><textarea id="add-desc" name="desc"></textarea></label><button class="btn primary">Предложить миру</button></form>`, T)
        + R(`<h3>Добавлено в этой встрече</h3>${b.added.length ? `<ul>${b.added.map((a) => `<li>${esc(a)}</li>`).join('')}</ul>` : hint('Пока ничего.')}`);
    }
    return L('Мир', 'Картинки', `<p class="muted">Картинка живёт на странице того, кого она изображает. Здесь — очередь: что ждёт одобрения.</p>
      <div class="card"><h4>Портрет: ${esc(st.ent(D.party[0]).name)}</h4><p style="margin:0">Игрок попросил новый портрет.</p><div class="row"><button class="btn primary" data-act="say" data-arg="Одобрено: портрет заменён.">Одобрить</button><button class="btn" data-act="say" data-arg="Отклонено.">Отклонить</button></div></div>`, T)
      + R(hint('«Заменить», «Попросить картинку», «Выровнять сетку» и «Загрузить карту боя» — на табличке каждой страницы, там, где картинка видна.'));
  };
  ACT.time = (s) => st.set(() => { const b = st.book(); b.time = s === 'dawn' ? Math.ceil(b.time / 86400) * 86400 + 6 * 3600 : b.time + +s; }, 'Время сдвинуто');

  // ── Journal ──────────────────────────────────────────────────────────────────────────
  PARTS.journal = () => {
    const page = cur('journal', 'known'), D = st.data(), b = st.book(), S = st.S;
    const T = tabs('journal', [['known', 'Что знает отряд'], ['handouts', 'Раздатки'], ['chronicle', 'Хроника'], ['notes', 'Заметки'], ['colophon', 'Что менялось']]);
    if (page === 'known') {
      const clues = b.found.map((k) => by(D.book.clues, k)).filter(Boolean);
      return L('Журнал', 'Что знает отряд', `${clues.map((c) => `<div class="card"><h4>${esc(c.name)}</h4><p style="margin:0">${esc(c.statement)}</p></div>`).join('') || hint('Отряд ещё ничего не нашёл в этой встрече. Находки отмечаются из карточек истории и сцены.')}
        <h3>Известно всем</h3><ul>${D.knowledge.slice(0, 6).map((k) => `<li>${esc(k.statement)}</li>`).join('')}</ul>`, T) + R(hint('Игроки видят эту же страницу в своих книгах — только то, что отряд знает.'));
    }
    if (page === 'handouts') {
      return L('Журнал', 'Раздатки', `<ul class="moments">${D.book.handouts.slice(0, 10).map((h) => `<li><button class="moment link" style="width:100%;border-bottom:0;text-align:left" data-act="card2" data-arg="h:${h.key}"><img src="${window.icoSrc('letter')}" alt=""><span><b>${esc(h.title)}</b><small>${b.handouts.includes(h.key) ? 'отдано' : 'у мастера'}</small></span>›</button></li>`).join('')}</ul>
        <div class="row"><button class="btn" data-act="say" data-arg="Своя раздатка: текст и картинка, отложить или отдать сразу.">Написать свою</button><button class="btn" data-act="say" data-arg="Конверт: откроется сам, когда отряд дойдёт до места или времени.">Конверт на потом</button></div>`, T)
        + R(window.cardOf(`handout:${(b.card2 || '').startsWith('h:') ? b.card2.slice(2) : D.book.handouts[0].key}`));
    }
    if (page === 'chronicle') {
      return L('Журнал', 'Хроника', `${S.meeting.state === 'ended' ? '<div class="card"><h4>Глава 1</h4><p class="muted" style="margin:0">Главу хроники мастер пишет после встречи — по тому, что случилось в мире.</p><button class="btn primary" data-act="say" data-arg="В продукте главу пишет мастер или черновик из истории мира; без чтения мастером она не выходит.">Написать главу</button></div>' : hint('Хроника пишется после встречи: закройте встречу в части «Стол».')}
        <div class="row"><button class="btn" data-act="say" data-arg="«В прошлый раз…» — короткий пересказ для начала встречи.">В прошлый раз…</button><button class="btn" data-act="say" data-arg="Вся книга отряда одной страницей.">Вся книга</button><button class="btn" data-act="say" data-arg="Памятные вещи отряда: что взяли с собой из приключения.">Памятные вещи</button></div>`, T) + R(hint('Хроника — часть этой же книги, а не отдельное окно.'));
    }
    if (page === 'notes') {
      const notes = Object.entries(b.notes).filter(([, v]) => v);
      return L('Журнал', 'Заметки мастера', notes.length ? notes.map(([k, v]) => `<div class="card"><small class="muted">${esc(k)}</small><p style="margin:0">${esc(v)}</p></div>`).join('') : hint('Заметки пишутся на полях страниц истории и собираются здесь.'), T) + R(hint('Заметки видит только мастер.'));
    }
    return L('Журнал', 'Что менялось', `<p class="muted">Колофон: каждое изменение мира в этой встрече, с отменой последнего шага мастера.</p>
      <ol class="colophon">${S.colophon.filter((c) => c.skin === S.skin).map((c, i) => `<li><span class="tabnum">${c.at}</span> ${esc(c.what)} ${i === 0 ? '<button class="btn quiet" data-act="undo">Отменить</button>' : ''}</li>`).join('') || '<li class="muted">Пока ничего.</li>'}</ol>`, T) + R(hint('Отмена — только последнего шага мастера и только пока на него ничего не опирается.'));
  };
  ACT.undo = () => st.set((S) => { S.colophon.shift(); });

  // ── Table ────────────────────────────────────────────────────────────────────────────
  PARTS.table = () => {
    const page = cur('table', 'meeting'), S = st.S, b = st.book(), m = S.meeting, D = st.data();
    const T = tabs('table', [['meeting', 'Встреча'], ['seats', 'Кто за столом'], ['screen', 'Экран стола'], ['sound', 'Звук'], ['chat', 'Разговор']]);
    if (page === 'meeting') {
      const body = m.state === 'closed' ? `<div class="card"><h4>В прошлый раз…</h4><p class="read" style="font-size:16px;margin:0">${esc(D.world.opening)}</p><p class="muted" style="margin:0">Для первой встречи — вступление кампании.</p></div>
          <button class="btn primary" data-act="meet" data-arg="open">Открыть встречу</button>`
        : m.state === 'open' ? `<div class="card"><h4>Встреча идёт</h4><p style="margin:0">Перерыв — через ${Math.max(0, m.breakAt - Math.round((Date.now() - m.startedAt) / 60000))} мин.</p>
          <div class="row"><button class="btn" data-act="meet" data-arg="${m.paused ? 'resume' : 'pause'}">${m.paused ? 'Продолжить' : 'Пауза'}</button><button class="btn" data-act="meet" data-arg="end">Закрыть встречу</button></div></div>`
        : `<div class="card"><h4>Встреча закрыта</h4><label class="field"><span>Следующая игра</span><input id="next-game" type="date"></label><div class="row"><button class="btn" data-act="say" data-arg="Звёзды и пожелания: каждый игрок отмечает лучший момент.">Звёзды и пожелания</button><button class="btn" data-act="meet" data-arg="reopen">Открыть снова</button></div></div>`;
      return L('Стол', 'Встреча', body + `<div class="card"><h4>Договор стола</h4><p style="margin:0" class="muted">Границы игры, о которых договорились: о чём не играем, что пропускаем; любой может попросить паузу.</p><button class="btn" data-act="cast" data-arg="agreement:">Договор — на экран</button></div>`, T) + R(`<h3>Ход встречи</h3><ol class="colophon">${S.colophon.filter((c) => c.skin === S.skin).slice(0, 10).map((c) => `<li><span class="tabnum">${c.at}</span> ${esc(c.what)}</li>`).join('') || '<li class="muted">Встреча ещё не начата.</li>'}</ol>`);
    }
    if (page === 'seats') {
      return L('Стол', 'Кто за столом', `<ul class="moments">${D.party.map((k, i) => `<li class="moment"><img src="${st.ent(k).picture}" alt="" style="border-radius:50%;object-fit:cover"><span><b>${esc(st.ent(k).name)}</b><small>${i < 2 ? 'игрок вошёл · телефон' : 'место свободно'}</small></span>${i < 2 ? '<span class="tag ok">за столом</span>' : '<button class="btn" data-act="say" data-arg="Приглашение на это место: ссылка или код.">Пригласить</button>'}</li>`).join('')}</ul>`, T)
        + R(`<div class="card"><h4>Код стола</h4><p style="font-family:var(--f-display);font-size:34px;margin:0;letter-spacing:.12em">ЛАМПА-42</p><p class="muted" style="margin:0">Игроки садятся по коду или QR на экране стола.</p><div class="row"><button class="btn" data-act="cast" data-arg="join:">Показать код на экране</button><button class="btn quiet" data-act="say" data-arg="Отозвать приглашение — с подтверждением.">Отозвать</button></div></div>`);
    }
    if (page === 'screen') {
      const kinds = [['cover', 'Обложка'], ['picture', 'Картинка места'], ['story', 'Слова вслух'], ['map', 'Карта мира'], ['blank', 'Ничего']];
      return L('Стол', 'Экран стола', `<p>Сейчас на экране: <b>${esc((kinds.find((k) => k[0] === b.cast.kind) || [0, b.cast.kind])[1])}</b>.</p>
        <div class="row">${kinds.map(([k, w]) => `<button class="btn" data-act="cast" data-arg="${k}:${k === 'picture' ? b.place : ''}" ${b.cast.kind === k ? 'aria-pressed="true"' : ''}>${w}</button>`).join('')}</div>
        <div class="card"><h4>Телевизор</h4><p style="margin:0"><span class="tag ok">подключён</span> Гостиная</p><button class="btn quiet" data-act="say" data-arg="Отключить все экраны — с подтверждением.">Отключить все экраны</button></div>`, T)
        + R(`<p class="kicker">Как это видит стол</p><div class="tv-mini">${window.renderTableScreen(true)}</div><button class="btn" data-act="view" data-arg="table">Открыть экран стола</button>`);
    }
    if (page === 'sound') {
      return L('Стол', 'Звук и музыка', `${['Гавань вечером', 'Дождь по крышам', 'Таверна', 'Ветер над облаками'].map((w, i) => `<label class="row"><input type="radio" name="amb" id="amb-${i}" ${i === 0 ? 'checked' : ''}> ${w}</label>`).join('')}
        <label class="field"><span>Громкость</span><input id="vol" type="range" min="0" max="10" value="6"></label><div class="row"><button class="btn" data-act="say" data-arg="Музыка стола: плейлист для всех.">Музыка</button><button class="btn" data-act="say" data-arg="Голосовой канал стола для игры онлайн.">Голос</button></div>`, T) + R(hint('Звук места можно задать и со страницы места в «Мире».'));
    }
    S.unreadDm = 0;
    return L('Стол', 'Разговор', `<ol class="chat">${S.chat.map((c) => `<li><b>${esc(c.who)}:</b> ${esc(c.text)}</li>`).join('')}</ol>
      <form class="row" data-form="chat"><label class="vh" for="chat-in">Сообщение</label><input id="chat-in" name="t" class="btn" style="flex:1;min-width:0" placeholder="Сообщение столу"><button class="btn primary">Отправить</button></form>`, T) + R(`<h3>За столом сейчас</h3><ul class="moments">${D.party.map((k, i) => `<li class="moment">${st.img(st.ent(k).picture, '', 'avatar')}<span><b>${esc(st.ent(k).name)}</b><small>${i < 2 ? 'в разговоре' : 'место свободно'}</small></span></li>`).join('')}</ul><p class="muted">Новое сообщение отмечает закладку «За столом» и кладёт записку у подножия страницы.</p>`);
  };
  ACT.meet = (k) => st.set((S) => {
    const m = S.meeting;
    if (k === 'open' || k === 'reopen') { m.state = 'open'; m.startedAt = Date.now(); m.paused = false; }
    if (k === 'pause') m.paused = true;
    if (k === 'resume') m.paused = false;
    if (k === 'end') m.state = 'ended';
  }, { open: 'Встреча открыта', reopen: 'Встреча открыта', pause: 'Пауза', resume: 'Встреча продолжается', end: 'Встреча закрыта' }[k]);

  // ── Rules: the appendix ──────────────────────────────────────────────────────────────
  const CONDITIONS = ['Ослеплённый', 'Очарованный', 'Оглохший', 'Испуганный', 'Схваченный', 'Недееспособный', 'Невидимый', 'Парализованный', 'Окаменевший', 'Отравленный', 'Лежащий', 'Опутанный', 'Ошеломлённый', 'Без сознания', 'Истощение'];
  PARTS.rules = () => {
    const page = cur('rules', 'conditions');
    const T = tabs('rules', [['conditions', 'Состояния'], ['actions', 'Действия'], ['toolbox', 'Инструменты'], ['tables', 'Таблицы случая'], ['guide', 'Как вести']]);
    const body = {
      conditions: `<ul class="grid-list words">${CONDITIONS.map((c) => `<li><button class="btn" data-act="say" data-arg="Справка SRD по состоянию «${c}».">${c}</button></li>`).join('')}</ul>`,
      actions: `<ul class="grid-list words">${['Атака', 'Заклинание', 'Рывок', 'Отход', 'Уклонение', 'Помощь', 'Засада', 'Подготовка', 'Поиск', 'Использование предмета'].map((c) => `<li><button class="btn" data-act="say" data-arg="Справка SRD: ${c}.">${c}</button></li>`).join('')}</ul>`,
      toolbox: `<div class="card"><h4>Ловушка</h4><button class="btn" data-act="say" data-arg="Ловушка: спасбросок, урон, кого задело — в мир одной командой.">Поставить ловушку</button></div><div class="card"><h4>Стресс</h4><button class="btn" data-act="say" data-arg="Ментальный стресс герою.">Отметить стресс</button></div><div class="card"><h4>Зараза</h4><button class="btn" data-act="say" data-arg="Болезнь и её течение.">Заразить</button></div><div class="card"><h4>Решение мастера</h4><button class="btn" data-act="say" data-arg="Правило, решённое за столом, записывается в историю.">Записать решение</button></div>`,
      tables: `<div class="card"><h4>Случайная встреча в пути</h4><button class="btn" data-act="say" data-arg="Бросок по таблице: выпало «Почтовый кит».">Бросить по таблице</button></div><button class="btn quiet" data-act="say" data-arg="Своя таблица случая — строками.">Новая таблица</button>`,
      guide: `<div class="card"><h4>Как вести эту игру</h4><p style="margin:0">Справочник мастера: подготовка, первая встреча, как отвечать на заявку игрока.</p></div>`,
    }[page];
    return L('Приложение', 'Правила', body, T) + R(`<label class="field"><span>Найти правило</span><input id="rule-q" data-rule-q placeholder="Например: схвачен, укрытие, помощь"></label>
      <h3>Указатель</h3><ul class="grid-list words" data-rule-index>${[...CONDITIONS, 'Атака', 'Заклинание', 'Рывок', 'Отход', 'Уклонение', 'Помощь', 'Засада', 'Укрытие', 'Трудная местность', 'Преимущество', 'Помеха', 'Концентрация', 'Отдых'].sort().map((c) => `<li><button class="btn" data-act="say" data-arg="Справка SRD: ${c}.">${c}</button></li>`).join('')}</ul>
      <p class="muted">Слово правила в любом месте книги — ссылка на эту страницу.</p>`);
  };

  // Forms
  window.FORMS = window.FORMS || {};
  window.FORMS.add = (f) => st.set(() => { st.book().added.push(`${f.name.value} — ${f.kind.selectedOptions[0].text.toLowerCase()}`); }, `Добавлено в мир: ${f.name.value}`);
  window.FORMS.chat = (f) => { if (f.t.value.trim()) st.set((S) => { S.chat.push({ who: 'Мастер', text: f.t.value.trim() }); }); };
  window.CHANGE = window.CHANGE || {};
  window.CHANGE.weather = (el) => st.set(() => { st.book().weather = el.value; }, `Погода: ${st.weatherWord(el.value)}`);
  window.CHANGE.note = (el) => { st.book().notes[el.dataset.note] = el.value; };
})();
