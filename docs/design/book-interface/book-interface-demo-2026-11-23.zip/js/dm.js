// The DM's book: the shell (running head, spread, bookmarks, foot) and its parts Story and Scene.
// Heroes, World, Journal, Table and Rules are in dm-parts.js; the fight fold-out in fight.js.
(function () {
  const st = window.store, { esc, paras, by } = st;
  const ACT = (window.ACT = window.ACT || {});
  const PARTS = (window.DM_PARTS = window.DM_PARTS || {});
  const MARKS = [
    ['story', 'История'], ['scene', 'Сцена'], ['heroes', 'Герои'], ['world', 'Мир'],
    ['journal', 'Журнал'], ['table', 'За столом'], ['rules', 'Правила'],
  ];

  const leavesOf = (ch) => 1 + ch.pages.length;
  const chapterAt = (i) => st.data().book.chapters[i];
  const placeName = (key) => st.ent(key)?.name || key;

  // ── Running head: where, when, the meeting ───────────────────────────────────────────
  function head() {
    const b = st.book(), S = st.S, m = S.meeting;
    const state = m.state === 'open' ? (m.paused ? 'пауза' : `идёт · ${minutes()} мин`) : m.state === 'ended' ? 'закрыта' : 'не начата';
    return `<header class="head">
      <button class="where" data-act="go" data-arg="scene" title="Открыть сцену">${esc(placeName(b.place))}</button>
      <button data-act="go" data-arg="world:time">${st.hhmm(b.time)} · ${esc(st.weatherWord(b.weather))}</button>
      <span class="meet"><span class="dot ${m.state === 'open' && !m.paused ? '' : 'off'}"></span>
        ${m.state === 'closed' ? '<button class="btn primary" data-act="meet" data-arg="open">Начать встречу</button>' : `<button data-act="go" data-arg="table:meeting">Встреча: ${state}</button>`}</span>
    </header>`;
  }
  const minutes = () => (st.S.meeting.startedAt ? Math.max(1, Math.round((Date.now() - st.S.meeting.startedAt) / 60000)) : 0);

  // ── The foot of every page: dice, then slips of what waits ───────────────────────────
  function foot() {
    const S = st.S, b = st.book();
    const last = b.rolls[0];
    const slips = [];
    S.asks.filter((a) => a.status === 'answered' && !a.seen).forEach((a) => slips.push(
      `<button class="slip" data-act="seeAnswer" data-arg="${a.id}"><img src="${st.icon('hero')}" alt="">${esc(st.ent(a.hero)?.name.split(' ')[0])}: ${a.total} — ${a.total >= a.dc ? 'успех' : 'неудача'}</button>`));
    if (S.unreadDm) slips.push(`<button class="slip" data-act="go" data-arg="table:chat"><img src="${st.icon('table')}" alt="">Новое в разговоре: ${S.unreadDm}</button>`);
    S.asks.filter((a) => a.status === 'open').forEach((a) => slips.push(`<span class="slip" role="status"><img src="${st.icon('hero')}" alt="">Ждём бросок: ${esc(st.ent(a.hero)?.name.split(' ')[0])}</span>`));
    return `<footer class="foot">
      <div class="tray" role="group" aria-label="Кубики">
        <span>Кубики</span>
        ${[4, 6, 8, 10, 12, 20, 100].map((n) => `<button class="die" data-act="roll" data-arg="${n}" aria-label="Бросить d${n}">d${n}</button>`).join('')}
        <span class="rolled" aria-live="polite">${last ? esc(last.total) : '—'}</span>
        ${last ? `<span>${esc(last.what)}</span>` : ''}
      </div>
      <div class="slips">${slips.join('')}</div>
    </footer>`;
  }
  ACT.roll = (n) => st.set((S) => { st.book().rolls.unshift({ total: st.d(+n), what: `d${n}` }); });
  ACT.seeAnswer = (id) => st.set((S) => { const a = S.asks.find((x) => x.id === id); if (a) a.seen = true; S.books[S.skin].part = 'story'; });

  // ── Bookmarks ────────────────────────────────────────────────────────────────────────
  function marks() {
    const b = st.book(), S = st.S;
    const waits = { table: S.unreadDm > 0, journal: false, heroes: S.asks.some((a) => a.status === 'answered' && !a.seen) };
    return `<nav class="marks" aria-label="Части книги">${MARKS.map(([id, word]) =>
      `<button class="mark" data-act="go" data-arg="${id}" ${b.part === id ? 'aria-current="true"' : ''}>
        <img src="${st.icon(id)}" alt="">${word}${waits[id] ? '<span class="wait" aria-label="что-то ждёт"></span>' : ''}</button>`).join('')}</nav>`;
  }
  ACT.go = (arg) => st.set(() => {
    const [part, sub] = arg.split(':');
    const b = st.book();
    b.part = part;
    if (sub) b.partPage[part] = sub;
    b.card = null;
  });

  // ── Story ────────────────────────────────────────────────────────────────────────────
  function linkPeople(text, links) {
    let html = esc(text);
    for (const l of links || []) for (const w of l.words) {
      html = html.split(esc(w)).join(`<button class="link" data-act="card" data-arg="person:${l.person}">${esc(w)}</button>`);
    }
    return html;
  }
  function storyLeft() {
    const b = st.book(), { chapter, leaf } = b.page, ch = chapterAt(chapter);
    const total = leavesOf(ch), opening = leaf === 0, page = opening ? null : ch.pages[leaf - 1];
    const text = opening ? ch.readAloud : page.text;
    const aloud = opening || page.voice === 'players';
    const here = b.ribbon.chapter === chapter && b.ribbon.leaf === leaf;
    return `<section class="page page-l" aria-label="Левая страница">
      <p class="kicker">Глава ${ch.number} · ${esc(placeName(page?.place || ch.place))}${opening ? ' · начало главы' : ` · сцена ${leaf} из ${total - 1}`}</p>
      <h2>${esc(opening ? ch.title : page.title)}</h2>
      <p class="voice">${aloud ? '<b>Читать игрокам вслух</b>' : '<b>Для мастера</b> — перескажите своими словами'}${page?.minutes ? ` · около ${page.minutes} мин` : ''}</p>
      <div class="flow" data-flow><div class="read${aloud ? ' aloud' : ''}">${paras(text).map((p) => `<p>${linkPeople(p, page?.people)}</p>`).join('')}</div></div>
      <nav class="turn" aria-label="Листать">
        <button class="btn" data-act="turn" data-arg="-1" ${chapter === 0 && leaf === 0 ? 'disabled' : ''}>← Назад</button>
        <p class="folio" data-folio>стр. ${leaf + 1} из ${total}</p>
        ${here ? '<span class="tag ok">Закладка здесь</span>' : `<button class="btn quiet" data-act="ribbonHere">Положить закладку сюда</button>`}
        <button class="btn primary" data-act="turn" data-arg="1">Читать дальше →</button>
      </nav>
    </section>`;
  }
  ACT.turn = (dir, el) => {
    const flow = document.querySelector('[data-flow]');
    const sub = +(flow?.dataset.sub || 0), subs = +(flow?.dataset.subs || 1);
    if (+dir > 0 && sub + 1 < subs) { st.set(() => { st.book().page.sub = sub + 1; }); return; }
    if (+dir < 0 && sub > 0) { st.set(() => { st.book().page.sub = sub - 1; }); return; }
    st.set(() => {
      const b = st.book(), chs = st.data().book.chapters;
      let { chapter, leaf } = b.page;
      const onRibbon = b.ribbon.chapter === chapter && b.ribbon.leaf === leaf;
      leaf += +dir;
      if (leaf >= leavesOf(chs[chapter])) { if (!b.played.includes(chapter)) b.played.push(chapter); chapter = Math.min(chapter + 1, chs.length - 1); leaf = 0; }
      if (leaf < 0) { chapter = Math.max(0, chapter - 1); leaf = leavesOf(chs[chapter]) - 1; }
      b.page = { chapter, leaf, sub: 0 };
      if (onRibbon && +dir > 0) b.ribbon = { chapter, leaf };
      b.card = null;
    });
  };
  ACT.ribbonHere = () => st.set(() => { const b = st.book(); b.ribbon = { chapter: b.page.chapter, leaf: b.page.leaf }; }, 'Закладка переложена');

  function plateFor() {
    const b = st.book(), ch = chapterAt(b.page.chapter), page = b.page.leaf ? ch.pages[b.page.leaf - 1] : null;
    if (b.card?.startsWith('person:')) { const e = st.ent(b.card.slice(7)); if (e?.picture) return [e.picture, `Портрет: ${e.name}`, e.key]; }
    const placeKey = page?.place || ch.place, e = st.ent(placeKey);
    return e?.picture ? [e.picture, `${page?.place ? 'Место сцены' : 'Место главы'}: ${e.name}`, e.key] : [null, 'У этого места нет картинки', null];
  }
  function plate(src, caption, key) {
    return `<figure class="plate"><div class="plate-frame">${src ? `<img src="${esc(src)}" alt="${esc(caption)}">` : '<p class="muted" style="padding:12px">Картинки нет.</p>'}
      ${src ? `<button class="btn zoom" data-act="zoom" data-arg="${esc(src)}">Увеличить</button>` : ''}</div>
      <figcaption><span>${esc(caption)}</span>${key ? `<button class="btn quiet" data-act="cast" data-arg="picture:${key}">Показать на экране стола</button>` : ''}</figcaption></figure>`;
  }
  ACT.zoom = (src) => st.set((S) => { S.dialog = { kind: 'zoom', src }; });
  ACT.closeDialog = () => st.set((S) => { S.dialog = null; });
  ACT.cast = (arg) => {
    const [kind, key] = arg.split(':');
    st.set(() => { st.book().cast = { kind, key }; }, `На экране стола: ${({ picture: 'картинка', story: 'страница вслух', cover: 'обложка', map: 'карта', fight: 'бой', blank: 'пусто', roll: 'бросок' })[kind]}`);
    st.say('Экран стола показывает это. Вкладка «Стол» вверху — как это видят игроки.');
  };

  function checkBlock(check, failForward) {
    if (!check) return '';
    const heroes = st.data().party;
    const opts = check.roll === 'asked' ? check.options.map((o, i) => `
      <li class="row"><span><b>${esc(st.checkWord(o.check))}</b> · Сл ${o.dc}${o.group ? ' · всей группой' : ''}</span>
        ${st.S.asks.filter((a) => a.skin === st.S.skin && a.dc === o.dc && st.checkWord(a.check) === st.checkWord(o.check)).map((a) => `<span class="tag ${a.status === 'open' ? 'warn' : a.total >= a.dc ? 'ok' : 'bad'}">${esc(st.ent(a.hero).name.split(' ')[0])}: ${a.status === 'open' ? 'ждём' : `${a.total} — ${a.total >= a.dc ? 'успех' : 'неудача'}`}</span>`).join('')}
        <label class="vh" for="ask-${i}">Кого спросить</label>
        <select id="ask-${i}" class="btn" data-ask-who>${o.group ? '<option value="*">Весь отряд</option>' : ''}${heroes.map((h) => `<option value="${h}">${esc(st.ent(h).name.split(' ')[0])}</option>`).join('')}<option value="*">Весь отряд</option></select>
        <button class="btn" data-act="ask" data-arg="${i}">Попросить бросок</button></li>`).join('') : '';
    return `<div class="card"><h4>Проверка</h4><p class="read" style="font-size:15.5px;margin:0">${esc(check.line)}</p>
      ${opts ? `<ul class="moments" style="gap:8px">${opts}</ul>` : `<p class="muted" style="margin:0">${check.roll === 'none' ? 'Без броска.' : 'Не прочитано как поля: бросок — с кубиков внизу страницы.'}</p>`}
      ${failForward ? `<p style="margin:0"><b>Если не вышло:</b> ${esc(failForward)}</p>` : ''}</div>`;
  }
  ACT.ask = (i, el) => {
    const b = st.book(), ch = chapterAt(b.page.chapter), page = ch.pages[b.page.leaf - 1];
    const o = page.check.options[+i], who = el.parentElement.querySelector('[data-ask-who]').value;
    const heroes = who === '*' ? st.data().party : [who];
    st.set((S) => { heroes.forEach((h) => S.asks.push({ id: `a${S.asks.length + 1}`, hero: h, check: o.check, dc: o.dc, status: 'open', skin: S.skin })); },
      `Бросок попрошен: ${st.checkWord(o.check)}, Сл ${o.dc}`);
    st.say('Игрок получил записку с броском. Вкладка «Книга героя» — как это выглядит у него.');
  };

  function storyRight() {
    const b = st.book(), ch = chapterAt(b.page.chapter), page = b.page.leaf ? ch.pages[b.page.leaf - 1] : null;
    const [src, cap, key] = plateFor();
    if (b.card) return `<section class="page page-r scroll" aria-label="Правая страница">${plate(src, cap, key)}${window.cardOf(b.card)}</section>`;
    const book = st.data().book;
    const moments = [];
    for (const k of (page ? page.people.map((l) => l.person) : ch.people).slice(0, 6)) { const p = by(book.people, k); if (p) moments.push(['talk', p.name, p.public || p.look, `person:${k}`]); }
    for (const k of ch.clues) { const c = by(book.clues, k); if (c) moments.push(['clue', c.name, b.found.includes(k) ? 'Отряд это знает' : c.appearance, `clue:${k}`]); }
    for (const k of ch.handouts) { const h = by(book.handouts, k); if (h) moments.push(['letter', h.title, b.handouts.includes(k) ? 'Отдано отряду' : 'Раздатка', `handout:${k}`]); }
    for (const k of ch.encounters) { const e = by(st.data().encounters, k); if (e) moments.push(['fight', e.title, e.trigger, `fight:${k}`]); }
    if (ch.puzzle) moments.push(['puzzle', 'Загадка главы', ch.puzzle.prompt, 'puzzle:']);
    const brief = page ? `${checkBlock(page.check, page.failForward)}
      ${page.choices.length ? `<div class="card"><h4>Что могут выбрать игроки</h4><ul style="margin:0;padding-left:18px">${page.choices.map((c) => `<li>${esc(c)}</li>`).join('')}</ul><p class="muted" style="margin:0">Выбирают игроки; книга ничего не решает за них.</p></div>` : ''}`
      : `<div class="card"><h4>Зачем эта глава</h4><p style="margin:0" class="read">${esc(ch.goal)}</p>
        <dl>${ch.duration ? `<dt>Длится</dt><dd>${esc(ch.duration)}</dd>` : ''}${ch.level ? `<dt>Уровень</dt><dd>${ch.level}</dd>` : ''}<dt>Заметка</dt><dd>${esc(ch.dmNote)}</dd></dl>
        <div class="row"><button class="btn" data-act="cast" data-arg="story:">На экран стола со словами вслух</button><button class="btn quiet" data-act="go" data-arg="story:path">Путь по главам</button></div></div>`;
    return `<section class="page page-r scroll" aria-label="Правая страница">
      ${plate(src, cap, key)}${brief}
      <h3>Моменты</h3>
      <ul class="moments">${moments.map(([ic, t, s, arg]) => `<li><button class="moment link" style="width:100%;border-bottom:0;text-align:left" data-act="card" data-arg="${esc(arg)}">
        <img src="${icoSrc(ic)}" alt=""><span><b>${esc(t)}</b><small>${esc(String(s || '').slice(0, 110))}</small></span><span aria-hidden="true">›</span></button></li>`).join('')}</ul>
      <label class="field"><span>Заметка на полях</span><textarea id="note-${ch.key}-${b.page.leaf}" data-note="${ch.key}:${b.page.leaf}" placeholder="Что выбрал стол, что запомнить">${esc(b.notes[`${ch.key}:${b.page.leaf}`] || '')}</textarea></label>
    </section>`;
  }
  const icoSrc = (kind) => `img/ui/${st.S.skin}-ico-${{ talk: 'talk', clue: 'clue', letter: 'letter', fight: 'fight', puzzle: 'puzzle' }[kind]}.webp`;
  window.icoSrc = icoSrc;
  ACT.card = (arg) => st.set(() => { st.book().card = arg; });
  ACT.uncard = () => st.set(() => { st.book().card = null; });

  function pathLeft() {
    const b = st.book(), book = st.data().book;
    const next = book.chapters.findIndex((c, i) => i > b.ribbon.chapter && !b.played.includes(i));
    return `<section class="page page-l scroll" aria-label="Путь по главам"><p class="kicker">Оглавление</p><h2>Путь по главам</h2>
      ${book.order ? `<p class="read muted" style="font-size:15px">${esc(book.order)}</p>` : ''}
      <ol class="moments">${book.chapters.map((c, i) => {
        const s = i === b.ribbon.chapter ? ['ok', 'отряд здесь'] : b.played.includes(i) ? ['', 'сыграно'] : i === next ? ['warn', 'следующая по книге'] : ['', 'позже'];
        return `<li><button class="moment link" style="width:100%;border-bottom:0;text-align:left;grid-template-columns:34px 1fr auto" data-act="openChapter" data-arg="${i}">
          <b style="font-family:var(--f-display);font-size:20px">${c.number}</b><span><b>${esc(c.title)}</b><small>${esc(placeName(c.place))}</small></span><span class="tag ${s[0]}">${s[1]}</span></button></li>`;
      }).join('')}</ol><p class="muted">Подсказка — не замок: открывается любая глава.</p></section>`;
  }
  ACT.openChapter = (i) => st.set(() => { const b = st.book(); b.page = { chapter: +i, leaf: 0, sub: 0 }; b.partPage.story = null; });
  function pathRight() {
    const D = st.data();
    const pins = (D.maps[0]?.pins || []).map((p) => `<span class="pin" style="left:${p.x * 100}%;top:${p.y * 100}%">${esc(placeName(p.place))}</span>`).join('');
    return `<section class="page page-r scroll"><p class="kicker">Карта мира</p>
      <div class="plate-frame" style="height:auto;aspect-ratio:3/2;position:relative">${st.img(D.worldMap, 'Карта мира')}${pins}</div>
      <div class="row"><button class="btn" data-act="map">Развернуть карту</button><button class="btn" data-act="cast" data-arg="map:">Карту — на экран стола</button></div></section>`;
  }

  PARTS.story = () => (st.book().partPage.story === 'path' ? pathLeft() + pathRight() : storyLeft() + storyRight());

  // ── Scene: the place as it is now ────────────────────────────────────────────────────
  PARTS.scene = () => {
    const b = st.book(), D = st.data(), place = st.ent(b.place);
    const here = D.entities.filter((e) => e.placement?.location === b.place);
    const people = here.filter((e) => e.kind === 'npc'), heroes = here.filter((e) => e.kind === 'character'), things = here.filter((e) => e.kind === 'item' || e.kind === 'feature');
    const ways = D.entities.filter((e) => e.kind === 'location' && e.key !== b.place && e.location?.type !== 'region').slice(0, 8);
    const encs = D.encounters.filter((e) => e.location === b.place);
    const row = (e, act) => `<li><button class="moment link" style="width:100%;border-bottom:0;text-align:left" data-act="${act}" data-arg="${act === 'card' ? (e.kind === 'npc' ? 'person:' : 'thing:') + e.key : e.key}">
      ${e.picture ? `<img src="${e.picture}" alt="" style="border-radius:50%;object-fit:cover">` : `<img src="${st.icon('scene')}" alt="">`}<span><b>${esc(e.name)}</b><small>${esc((e.description || '').slice(0, 90))}</small></span><span aria-hidden="true">›</span></button></li>`;
    const left = `<section class="page page-l scroll"><p class="kicker">Сцена · ${st.hhmm(b.time)}</p><h2>${esc(place?.name)}</h2>
      <div class="read" style="font-size:16px"><p>${esc(place?.description)}</p></div>
      <h3>Кто здесь</h3><ul class="moments">${people.map((e) => row(e, 'card')).join('') || '<li class="muted">Никого из действующих лиц.</li>'}</ul>
      ${heroes.length ? `<p class="muted" style="margin:0">Герои здесь: ${heroes.map((h) => esc(h.name)).join(', ')}</p>` : ''}
      <h3>Что здесь</h3><ul class="moments">${things.slice(0, 6).map((e) => row(e, 'card')).join('') || '<li class="muted">Ничего заметного.</li>'}</ul>
      <button class="btn quiet" data-act="go" data-arg="world:blank">Этого здесь нет — добавить в мир</button>
      <h3>Куда можно пойти</h3><div class="row">${ways.map((w) => `<button class="btn" data-act="moveTo" data-arg="${w.key}">${esc(w.name)}</button>`).join('')}</div></section>`;
    const right = `<section class="page page-r scroll">${plate(place?.picture, `Место: ${place?.name}`, place?.key)}
      ${b.card ? window.cardOf(b.card) : `<div class="card"><h4>Что сейчас на сцене</h4><p class="muted" style="margin:0">Нажмите на человека или вещь слева — здесь откроется их карточка: как выглядит, чего хочет, что знает, что с этим можно сделать.</p></div>`}
      ${encs.length ? `<h3>Бой, подготовленный здесь</h3><ul class="moments">${encs.map((e) => `<li><button class="moment link" style="width:100%;border-bottom:0;text-align:left" data-act="card" data-arg="fight:${e.key}"><img src="${icoSrc('fight')}" alt=""><span><b>${esc(e.title)}</b><small>${esc(e.trigger.slice(0, 100))}</small></span>›</button></li>`).join('')}</ul>` : ''}</section>`;
    return left + right;
  };
  ACT.moveTo = (key) => st.set(() => { const b = st.book(); b.place = key; b.card = null; b.time += 20 * 60; }, `Отряд перешёл: ${placeName(key)}`);

  // ── The whole book ───────────────────────────────────────────────────────────────────
  window.renderDm = () => {
    const b = st.book();
    const body = (PARTS[b.part] || PARTS.story)();
    const ribbon = b.part === 'story' && !b.partPage.story && b.ribbon.chapter === b.page.chapter && b.ribbon.leaf === b.page.leaf;
    const covered = b.fight || b.mapOpen;
    return `<div class="book"${covered ? ' inert aria-hidden="true"' : ''}>
      <div class="binding">${head()}<div class="spread">${body}${ribbon ? '<span class="ribbon" aria-hidden="true"></span>' : ''}</div>${foot()}</div>
      ${marks()}</div>${b.fight ? window.renderFight() : ''}${b.mapOpen ? window.renderMapFold() : ''}`;
  };
  window.placeName = placeName;
  window.plate = plate;
})();
