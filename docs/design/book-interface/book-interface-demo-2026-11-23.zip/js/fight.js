// The fight as a fold-out of the book (ADR 0075 plan, Stage 1060): the battlefield takes the whole
// spread, the order of turns is its head, the turn tray its foot, the chosen figure its margin.
// Demo arithmetic only: the product's fight is the World Engine's, unchanged.
(function () {
  const st = window.store, { esc, by } = st;
  const ACT = (window.ACT = window.ACT || {});

  ACT.startFight = (key) => {
    const D = st.data(), e = by(D.encounters, key);
    const fig = e.combatants.map((c, i) => {
      const ent = st.ent(c.entity);
      const max = ent?.sheet?.hitPoints?.max || ent?.statBlock?.hitPoints?.max || 11;
      const hero = st.book().heroes[c.entity];
      return { id: c.entity, name: ent?.name || c.entity, side: c.side, x: c.position.x, y: c.position.y, hp: hero ? hero.hp : max, max, init: st.d(20) + (i % 3), pic: ent?.picture };
    });
    const seen = {};
    fig.forEach((z) => { const base = z.name.split(' ')[0]; seen[base] = (seen[base] || 0) + 1; z.n = seen[base]; });
    fig.forEach((z) => { const base = z.name.split(' ')[0]; z.label = `${base.slice(0, 1)}${seen[base] > 1 ? z.n : ''}`; if (seen[base] > 1) z.name = `${z.name} ${z.n}`; });
    fig.sort((a, b) => b.init - a.init);
    st.set(() => { const b = st.book(); b.fight = { key, fig, turn: 0, round: 1, sel: fig[0].id, log: [] }; b.cast = { kind: 'fight', key }; }, `Бой начат: ${e.title}`);
  };
  ACT.fightSel = (id) => st.set(() => { st.book().fight.sel = id; });
  ACT.fightNext = () => st.set(() => { const f = st.book().fight; f.turn = (f.turn + 1) % f.fig.length; if (f.turn === 0) f.round += 1; f.sel = f.fig[f.turn].id; });
  ACT.fightHit = () => st.set(() => {
    const f = st.book().fight, me = f.fig[f.turn], foe = f.fig.find((x) => x.id === f.sel && x.side !== me.side) || f.fig.find((x) => x.side !== me.side && x.hp > 0);
    if (!foe) return;
    const roll = st.d(20), dmg = roll >= 10 ? st.d(8) + 2 : 0;
    foe.hp = Math.max(0, foe.hp - dmg);
    f.log.unshift(`${me.name.split(' ')[0]} → ${foe.name.split(' ')[0]}: ${roll}${dmg ? `, попадание, ${dmg} урона` : ', промах'}`);
    st.book().rolls.unshift({ total: roll, what: 'атака' });
  });
  ACT.fightMove = (xy) => st.set(() => { const f = st.book().fight, [x, y] = xy.split(',').map(Number), me = f.fig.find((z) => z.id === f.sel); if (me) { me.x = x; me.y = y; } });
  ACT.fightEnd = () => st.set(() => {
    const b = st.book();
    b.fight.fig.forEach((z) => { if (b.heroes[z.id]) b.heroes[z.id].hp = z.hp; });
    b.fight = null; b.cast = { kind: 'picture', key: b.place };
  }, 'Бой окончен');

  window.renderFight = () => {
    const D = st.data(), b = st.book(), f = b.fight, e = by(D.encounters, f.key), bf = e.battlefield;
    const me = f.fig[f.turn], sel = f.fig.find((z) => z.id === f.sel) || me;
    const cells = [];
    for (let y = 0; y < bf.height; y += 1) for (let x = 0; x < bf.width; x += 1) {
      const z = f.fig.find((q) => q.x === x && q.y === y);
      const cover = bf.cover?.find((c) => c.x === x && c.y === y), diff = bf.difficult?.find((c) => c.x === x && c.y === y);
      cells.push(z ? `<button class="cell tok ${z.side}${z.id === f.sel ? ' sel' : ''}${z.hp === 0 ? ' down' : ''}" data-act="fightSel" data-arg="${z.id}" aria-label="${esc(z.name)}, хиты ${z.hp} из ${z.max}">${z.pic ? `<img src="${z.pic}" alt="">` : esc(z.label)}</button>`
        : `<button class="cell${cover ? ' cover' : ''}${diff ? ' diff' : ''}" data-act="fightMove" data-arg="${x},${y}" aria-label="Клетка ${x + 1}, ${y + 1}${cover ? ', укрытие' : ''}${diff ? ', трудная местность' : ''}"></button>`);
    }
    return `<div class="foldout" role="dialog" aria-label="Бой: ${esc(e.title)}">
      <div class="foldout-head"><h2>${esc(e.title)}</h2><span>Раунд ${f.round}</span>
        <ol class="order" aria-label="Порядок ходов">${f.fig.map((z, i) => `<li class="${z.side}${i === f.turn ? ' now' : ''}${z.hp === 0 ? ' down' : ''}"><span class="tabnum">${z.init}</span> ${esc(z.name.split(' ')[0])}</li>`).join('')}</ol>
        <button class="btn" data-act="fightEnd">Закончить бой и вернуться к странице</button></div>
      <div class="foldout-sheet">
        <div class="field-wrap"><div class="board" style="--w:${bf.width};--h:${bf.height};${D.battleMaps[f.key] ? `background-image:url(${D.battleMaps[f.key]})` : ''}">${cells.join('')}</div></div>
        <aside class="margin"><p class="kicker">На полях</p><h3 style="margin:0">${esc(sel.name)}</h3>
          ${sel.pic ? `<img src="${sel.pic}" alt="" style="border-radius:6px;max-height:140px;object-fit:cover">` : ''}
          <p class="tabnum">Хиты ${sel.hp} / ${sel.max}</p><span class="hp" style="--p:${Math.round((100 * sel.hp) / sel.max)}%"><span></span></span>
          <div class="row"><button class="btn" data-act="say" data-arg="Состояние — той же формой, что и на листе героя.">Состояние</button><button class="btn" data-act="say" data-arg="Реакция: окно открывается, когда её можно применить.">Реакция</button></div>
          <h3 style="margin:8px 0 0">Ходы</h3><ol class="log">${f.log.slice(0, 6).map((l) => `<li>${esc(l)}</li>`).join('') || '<li class="muted">Пока ничего.</li>'}</ol></aside>
      </div>
      <div class="foot"><div class="tray turn-tray" role="group" aria-label="Ход: ${esc(me.name)}"><span>Ход: <b>${esc(me.name)}</b></span>
        <button class="die" data-act="fightHit">Атаковать выбранного</button><button class="die" data-act="say" data-arg="Перемещение: выберите фигуру и нажмите клетку.">Переместиться</button>
        <button class="die" data-act="say" data-arg="Заклинания героя — из его листа.">Заклинание</button><button class="die" data-act="fightNext">Конец хода</button>
        <span class="rolled">${b.rolls[0]?.total ?? '—'}</span></div>
        <div class="slips"><button class="slip" data-act="cast" data-arg="fight:${f.key}">Бой — на экран стола</button></div></div>
    </div>`;
  };

  ACT.map = () => st.set(() => { st.book().mapOpen = true; });
  ACT.unmap = () => st.set(() => { st.book().mapOpen = false; });
  window.renderMapFold = () => {
    const D = st.data(), b = st.book();
    return `<div class="foldout" role="dialog" aria-label="Карта мира">
      <div class="foldout-head"><h2>Карта мира</h2><button class="btn" data-act="cast" data-arg="map:">На экран стола</button><button class="btn" data-act="unmap">Сложить карту</button></div>
      <div class="foldout-sheet" style="grid-template-columns:1fr"><div class="map-wrap"><div class="map" >${st.img(D.worldMap, 'Карта мира')}
        ${(D.maps[0]?.pins || []).map((p) => `<button class="pin${p.place === b.place ? ' here' : ''}" style="left:${p.x * 100}%;top:${p.y * 100}%" data-act="moveTo" data-arg="${p.place}">${esc(window.placeName(p.place))}</button>`).join('')}</div></div></div>
      <div class="foot"><p style="margin:0">Нажмите на место, чтобы сделать его сценой.</p></div></div>`;
  };
})();
