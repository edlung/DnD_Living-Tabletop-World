// The open book on the table: the table's screen shows the page the DM turned to the table, read
// from three metres. Nothing cast is the closed cover with the code to sit down.
(function () {
  const st = window.store, { esc, by } = st;
  const ACT = (window.ACT = window.ACT || {});
  window.renderTableScreen = (mini) => {
    const D = st.data(), b = st.book(), c = b.cast;
    const ch = D.book.chapters[b.ribbon.chapter];
    let inner;
    if (c.kind === 'picture' || c.kind === 'map') {
      const e = c.kind === 'map' ? { picture: D.worldMap, name: 'Карта мира' } : st.ent(c.key);
      inner = `<div class="tv-plate">${st.img(e?.picture, e?.name)}<p class="tv-cap">${esc(e?.name)}</p></div>`;
    } else if (c.kind === 'story') {
      inner = `<div class="tv-page"><p class="tv-kicker">Глава ${ch.number}</p><h2>${esc(ch.title)}</h2><p>${esc(ch.readAloud)}</p></div>`;
    } else if (c.kind === 'fight' && b.fight) {
      const e = by(D.encounters, b.fight.key);
      const bf = e.battlefield, f = b.fight;
      const toks = f.fig.map((z) => `<span class="tv-tok ${z.side}" style="grid-column:${z.x + 1};grid-row:${z.y + 1}${z.hp === 0 ? ';filter:grayscale(1)' : ''}">${st.img(z.pic, z.name)}</span>`).join('');
      inner = `<div class="tv-plate tv-fight"><div class="tv-board" style="aspect-ratio:${bf.width}/${bf.height};grid-template-columns:repeat(${bf.width},1fr);grid-template-rows:repeat(${bf.height},1fr);background-image:url(${D.battleMaps[b.fight.key]})">${toks}</div><p class="tv-cap">${esc(e.title)} · раунд ${b.fight.round} · ход: ${esc(b.fight.fig[b.fight.turn].name)}</p></div>`;
    } else if (c.kind === 'blank') {
      inner = '<div class="tv-blank"></div>';
    } else if (c.kind === 'agreement') {
      inner = `<div class="tv-page"><h2>Договор стола</h2><p>Здесь — строки договора, о которых стол условился перед игрой: о чём не играем, что пропускаем, как попросить паузу.</p></div>`;
    } else {
      inner = `<div class="tv-cover" style="background-image:url(${D.cover})"><div class="tv-bookplate"><p>${esc(D.title)}</p><b>ЛАМПА-42</b><small>Код стола — сядьте со своего телефона</small></div></div>`;
    }
    const roll = '';
    return `<div class="tv${mini ? ' mini' : ''}" data-skin-tv="${st.S.skin}">${inner}${roll}
      ${st.S.asks.some((a) => a.status === 'open' && a.skin === st.S.skin) ? `<p class="tv-wait">Ждём бросок: ${st.S.asks.filter((a) => a.status === 'open' && a.skin === st.S.skin).map((a) => esc(st.ent(a.hero)?.name.split(' ')[0])).join(', ')}</p>` : ''}</div>`;
  };
  window.renderTableView = () => {
    const b = st.book();
    const kinds = [['cover', 'Обложка и код'], ['picture', 'Картинка места'], ['story', 'Слова вслух'], ['map', 'Карта'], ['blank', 'Ничего']];
    return `<div class="stage-tv">${window.renderTableScreen(false)}
      <div class="tv-remote"><p>Что на экране, решает мастер — из своей книги (табличка «Показать на экране стола», часть «Стол»). Для демо — то же самое здесь:</p>
      <div class="row">${kinds.map(([k, w]) => `<button class="btn" data-act="cast" data-arg="${k}:${k === 'picture' ? b.place : ''}" ${b.cast.kind === k ? 'aria-pressed="true"' : ''}>${w}</button>`).join('')}</div></div></div>`;
  };
})();
