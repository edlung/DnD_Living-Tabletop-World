// The shelf: the way in. The bookplate signs in; your books stand face out with their ribbons;
// the library stands spine out; a book taken down opens as "look inside". The account is the
// bookplate of your shelf. Product binding (ltw).
(function () {
  const st = window.store, { esc } = st;
  const ACT = (window.ACT = window.ACT || {});
  const D = st.D;
  const BUILTIN = { hollowmere: 'Колокола Холлоумира', ravenford: 'Пропавший караван' };
  const MINE = {
    lighthouse: { role: 'Вы мастер', where: 'Глава 2 · «Чайник» отходит', skin: 'lh' },
    'rain-check': { role: 'Вы мастер', where: 'Глава 1 · похороны под дождём', skin: 'rc' },
    hollowmere: { role: 'Вы играете', where: 'Книга ждёт вашего чтения' },
  };

  function bookplate() {
    return `<div class="shelf-room"><div class="plate-in">
      <img src="img/ui/ltw-bookplate.webp" alt="" class="plate-bg">
      <form class="plate-form" data-form="signin"><p class="kicker" style="color:var(--ink-2)">Ex libris</p><h1>Живой стол</h1>
        <label class="field"><span>Логин</span><input id="login" name="login" autocomplete="username" value="" placeholder="Ваш логин"></label>
        <label class="field"><span>Пароль</span><input id="password" name="password" type="password" autocomplete="current-password" value="" placeholder="Пароль"></label>
        <button class="btn primary">Открыть полку</button>
        <div class="row" style="justify-content:center"><button type="button" class="btn quiet" data-act="say" data-arg="Сесть за стол по коду или QR с экрана стола — без учётной записи.">Сесть за стол по коду</button></div></form></div></div>`;
  }

  // A spine is cut from the campaign's own cover and bound in its own material and accent.
  const spine = (c) => `<button class="spine" style="--acc:${c.accent};background-image:linear-gradient(90deg, rgba(0,0,0,.45), rgba(0,0,0,.05) 40%, rgba(0,0,0,.45)),url(${c.cover || c.material})" data-act="peek" data-arg="${c.id}" aria-label="${esc(c.title)}"><span class="spine-label" style="${c.material ? `background-image:url(${c.material})` : ''}">${esc(c.title)}</span></button>`;
  function shelf() {
    const lib = D.shelf.filter((c) => !c.builtin);
    const rows = [];
    const per = Math.max(5, Math.floor((Math.min(window.innerWidth, 1280) - 70) / 57));
    for (let i = 0; i < lib.length; i += per) rows.push(lib.slice(i, i + per));
    const mine = st.S.shelf.mine.map((id) => D.shelf.find((c) => c.id === id) || { id, title: BUILTIN[id] });
    return `<div class="shelf-room scroll-y"><div class="shelf-wrap">
      <header class="shelf-head"><h1>Ваша полка</h1><div class="row"><button class="btn" data-act="peekAccount">Учётная запись</button><button class="btn" data-act="view" data-arg="manuscript">Мастерская</button></div></header>
      <section aria-labelledby="mine-h"><h2 id="mine-h" class="shelf-label">Мои книги</h2>
        <div class="shelf-row face">${mine.map((c) => {
          const m = MINE[c.id] || {};
          return `<button class="face-book" data-act="openMine" data-arg="${c.id}" style="--acc:${c.accent || '#c9a45c'}">
            <span class="face-cover">${c.cover ? `<img src="${c.cover}" alt="">` : `<span class="face-blank" style="${c.material ? `background-image:url(${c.material})` : ''}"><b>${esc(c.title)}</b></span>`}<span class="face-ribbon" aria-hidden="true"></span></span>
            <span class="face-text"><b>${esc(c.title)}</b><small>${esc(m.role || '')}</small><small>${esc(m.where || '')}</small></span></button>`;
        }).join('')}
        ${st.S.ms.bound ? `<button class="face-book" data-act="view" data-arg="manuscript"><span class="face-cover"><img src="img/ui/ltw-cover.webp" alt=""></span><span class="face-text"><b>Ваша книга</b><small>Переплетена в мастерской</small><small>Готова к первой встрече</small></span></button>` : ''}</div></section>
      <section aria-labelledby="lib-h"><h2 id="lib-h" class="shelf-label">Библиотека · ${lib.length} кампаний</h2>
        ${rows.map((r) => `<div class="shelf-row">${r.map(spine).join('')}</div>`).join('')}</section>
      <section aria-labelledby="done-h"><h2 id="done-h" class="shelf-label">Сыгранные</h2><div class="shelf-row face"><p class="muted-light">Здесь встанут книги законченных приключений — с хроникой и памятными вещами.</p></div></section>
    </div>${st.S.shelf.open ? peek() : ''}</div>`;
  }

  function peek() {
    const id = st.S.shelf.open;
    if (id === 'account') {
      return `<div class="dlg" role="dialog" aria-label="Учётная запись"><div class="dlg-box spread-box"><div class="page"><p class="kicker">Экслибрис</p><h2>Учётная запись</h2>
        <label class="field"><span>Имя за столом</span><input id="acc-name" value="Мастер"></label><button class="btn">Сохранить имя</button>
        <label class="field"><span>Текущий пароль</span><input id="acc-old" type="password"></label><label class="field"><span>Новый пароль</span><input id="acc-new" type="password"></label><button class="btn">Сменить пароль</button></div>
        <div class="page"><h3>Ваши данные</h3><p class="muted">Что хранится и как это удалить — страница конфиденциальности.</p><div class="row"><button class="btn quiet" data-act="say" data-arg="Страница конфиденциальности — тоже лист этой книги.">Конфиденциальность</button></div>
        <div class="row" style="margin-top:auto"><button class="btn" data-act="signOut">Выйти</button><button class="btn primary" data-act="unpeek">Закрыть</button></div></div></div></div>`;
    }
    const c = D.shelf.find((x) => x.id === id);
    return `<div class="dlg" role="dialog" aria-label="${esc(c.title)}"><div class="dlg-box spread-box" style="--acc:${c.accent}">
      <div class="page"><p class="kicker">${esc(c.genre)} · ${esc(c.audience)}</p><h2>${esc(c.title)}</h2><p class="read" style="font-size:17px">${esc(c.pitch)}</p><p class="muted">${esc(c.duration)}</p></div>
      <div class="page">${c.cover ? `<img src="${c.cover}" alt="Обложка" style="max-height:38vh;border-radius:4px;object-fit:cover">` : ''}
        <label class="field"><span>Сколько игроков</span><select id="variant">${c.variants.map((v) => `<option>${esc(v)}</option>`).join('')}</select></label>
        <div class="row"><button class="btn primary" data-act="startLib" data-arg="${c.id}">Начать как мастер</button><button class="btn" data-act="unpeek">Закрыть</button></div>
        <p class="muted" style="font-size:13px">Книга встанет в «Мои книги» с лентой на первой главе.</p></div></div></div>`;
  }
  ACT.peek = (id) => st.set((S) => { S.shelf.open = id; });
  ACT.peekAccount = () => st.set((S) => { S.shelf.open = 'account'; });
  ACT.unpeek = () => st.set((S) => { S.shelf.open = null; });
  ACT.signOut = () => st.set((S) => { S.signedIn = false; S.shelf.open = null; });
  ACT.startLib = (id) => st.set((S) => { if (!S.shelf.mine.includes(id)) S.shelf.mine.unshift(id); S.shelf.open = null; });
  ACT.openMine = (id) => {
    const m = MINE[id];
    if (m?.skin) st.set((S) => { S.skin = m.skin; S.view = 'dm'; });
    else if (id === 'hollowmere') st.say('Холлоумир — встроенное приключение; его книга ждёт вашего чтения. В демо открыты «Маяк» и «Дождь».');
    else st.say('В демо книги открыты для «Маяка» и «Дождя»; эта встала на полку как новая.');
  };
  window.FORMS = window.FORMS || {};
  window.FORMS.signin = () => st.set((S) => { S.signedIn = true; });
  window.renderShelf = () => (st.S.signedIn ? shelf() : bookplate());
})();
