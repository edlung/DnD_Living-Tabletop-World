// Cards of the right page: a person, a thing, a clue, a handout, a prepared fight, the puzzle.
// Each card's buttons are the product's own commands (ADR 0074 §4); here they only change the demo's state.
(function () {
  const st = window.store, { esc, by } = st;
  const ACT = (window.ACT = window.ACT || {});
  const back = `<button class="btn quiet" data-act="uncard">← Назад к странице</button>`;
  const rows = (pairs) => `<dl>${pairs.filter(([, v]) => v && (!Array.isArray(v) || v.length)).map(([k, v]) => `<dt>${k}</dt><dd>${Array.isArray(v) ? v.map(esc).join('<br>') : esc(v)}</dd>`).join('')}</dl>`;

  window.cardOf = (arg) => {
    const [kind, key] = arg.split(':');
    const D = st.data(), book = D.book, b = st.book();
    if (kind === 'person') {
      const p = by(book.people, key), e = st.ent(key);
      return `<div class="card"><h4>${esc(p?.name || e?.name)}</h4>
        ${rows([['Как выглядит', p?.look || e?.description], ['Все знают', p?.public], ['Чего хочет', p?.want], ['Как говорит', p?.voice], ['Знает', p?.knows], ['Граница', p?.boundary], ['Предложит', p?.offer]])}
        ${p?.secret ? `<details><summary><b>Тайна — только для мастера</b></summary>${rows([['Тайна', p.secret], ['Когда раскрыть', p.reveal]])}</details>` : ''}
        <div class="row"><button class="btn" data-act="say" data-arg="Мастер говорит за персонажа: реплики уходят игрокам с его именем.">Говорить за него</button>
          <button class="btn" data-act="cast" data-arg="picture:${key}">Портрет на экран</button>
          <button class="btn" data-act="say" data-arg="Лавка персонажа: что продаёт и по какой цене — как в продукте сегодня.">Лавка</button>
          <button class="btn quiet" data-act="say" data-arg="Карточку можно исправить на месте: поля на полях страницы.">Исправить карточку</button></div>${back}</div>`;
    }
    if (kind === 'thing') {
      const e = st.ent(key);
      return `<div class="card"><h4>${esc(e?.name)}</h4><p class="read" style="font-size:15.5px;margin:0">${esc(e?.description)}</p>
        <div class="row"><button class="btn" data-act="say" data-arg="Осмотр — команда героя; мастер может сделать это за отряд.">Осмотреть</button><button class="btn" data-act="cast" data-arg="picture:${key}">На экран</button></div>${back}</div>`;
    }
    if (kind === 'clue') {
      const c = by(book.clues, key), found = b.found.includes(key);
      return `<div class="card"><h4>${esc(c.name)}</h4>${rows([['Как выглядит', c.appearance], ['Что значит', c.statement], ['Как находят', ({ inspect: 'осмотром', talk: 'в разговоре', check: 'проверкой' })[c.discovery] || c.discovery], ['Без удачи', c.fallback]])}
        ${found ? '<span class="tag ok">Отряд это знает</span>' : `<button class="btn primary" data-act="findClue" data-arg="${key}">Отряд нашёл это</button>`}${back}</div>`;
    }
    if (kind === 'handout') {
      const h = by(book.handouts, key), given = b.handouts.includes(key);
      return `<div class="card" style="background:var(--paper-3)"><h4>${esc(h.title)}</h4><p class="read" style="font-size:16px;margin:0;white-space:pre-line">${esc(h.text)}</p>
        ${rows([['Когда дать', h.unlock], ['Задание', h.task]])}
        ${given ? '<span class="tag ok">Отдано отряду</span>' : `<button class="btn primary" data-act="giveHandout" data-arg="${key}">Отдать отряду</button>`}${back}</div>`;
    }
    if (kind === 'fight') {
      const e = by(D.encounters, key);
      const foes = e.combatants.filter((c) => c.side !== 'party').map((c) => st.ent(c.entity)?.name || c.entity);
      return `<div class="card"><h4>${esc(e.title)}</h4>${rows([['Когда', e.trigger], ['Против', foes], ['Поле', `${e.battlefield.width} × ${e.battlefield.height} клеток`]])}
        ${D.battleMaps[key] ? `<img src="${D.battleMaps[key]}" alt="Карта боя" style="border-radius:4px">` : ''}
        <div class="row"><button class="btn primary" data-act="startFight" data-arg="${key}">Начать бой</button><button class="btn" data-act="say" data-arg="Добыча боя готовится здесь же, до начала.">Добыча</button></div>${back}</div>`;
    }
    if (kind === 'puzzle') {
      const ch = book.chapters[b.page.chapter], pz = ch.puzzle, shown = b.hints || 0;
      return `<div class="card"><h4>Загадка</h4><p class="read" style="font-size:16px;margin:0">${esc(pz.prompt)}</p>
        ${pz.hints.slice(0, shown).map((h, i) => `<p style="margin:0"><b>Подсказка ${i + 1}:</b> ${esc(h)}</p>`).join('')}
        <div class="row">${shown < pz.hints.length ? `<button class="btn" data-act="hint">Следующая подсказка</button>` : ''}</div>
        <details><summary><b>Решение</b></summary><p>${esc(pz.solution)}</p></details>${back}</div>`;
    }
    return '';
  };
  ACT.say = (t) => st.say(t);
  ACT.hint = () => st.set(() => { const b = st.book(); b.hints = (b.hints || 0) + 1; });
  ACT.findClue = (key) => st.set(() => { st.book().found.push(key); }, `Отряд нашёл: ${by(st.data().book.clues, key).name}`);
  ACT.giveHandout = (key) => {
    st.set(() => { st.book().handouts.push(key); }, `Отдано отряду: ${by(st.data().book.handouts, key).title}`);
    st.say('Раздатка легла вкладышем в книги героев.');
  };
})();
