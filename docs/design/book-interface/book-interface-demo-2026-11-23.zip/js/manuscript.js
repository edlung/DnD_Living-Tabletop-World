// The manuscript: the workshop as a book being written. The desk holds manuscripts; a draft opens
// as the book it will become; a page is edited where it will be read; generation proposes pages
// marked unread; an AI edit is a proofreader's marks; publishing is binding. The draft here is a
// library campaign taken into the workshop (as the workshop allows today); its text is the campaign's.
(function () {
  const st = window.store, { esc, paras } = st;
  const ACT = (window.ACT = window.ACT || {});
  const PAGES = [['title', 'Титул'], ['contents', 'Оглавление'], ['chapter', 'Глава 1'], ['cast', 'Действующие лица'], ['proposal', 'Предложено'], ['proof', 'Корректура'], ['plates', 'Иллюстрации'], ['compare', 'Сверка'], ['binding', 'Переплёт']];
  const B = () => st.D.books.rc; // the draft: «Дождь по страховому случаю», taken from the library

  function desk() {
    return `<div class="desk"><div class="desk-top">
      <h1 class="desk-title">Мастерская</h1><p class="desk-sub">Рукописи — это будущие книги. Переплетённая рукопись встаёт на полку и играется как книга из библиотеки.</p>
      <div class="desk-items">
        <button class="ms-stack" data-act="msOpen"><img src="img/ui/ltw-proof.webp" alt=""><b>${esc(B().title)}</b><small>Рукопись · ревизия ${st.S.ms.saved} · взята из библиотеки</small></button>
        <button class="ms-stack new" data-act="msNew"><img src="img/ui/ltw-quill.webp" alt=""><b>Новая рукопись</b><small>С чистого листа, из библиотеки или из файла</small></button>
        ${st.S.ms.bound ? `<button class="ms-stack" data-act="view" data-arg="shelf"><img src="img/ui/ltw-seal.webp" alt=""><b>Переплетено</b><small>Стоит на полке</small></button>` : ''}
      </div></div></div>`;
  }
  ACT.msOpen = () => st.set((S) => { S.ms.open = true; });
  ACT.msNew = () => st.say('Новая рукопись: пустая, из книги библиотеки или из файла пакета.');
  ACT.msPage = (p) => st.set((S) => { S.ms.page = p; S.ms.editing = false; });
  ACT.msClose = () => st.set((S) => { S.ms.open = false; });

  function left() {
    const ms = st.S.ms, b = B(), ch = b.book.chapters[0];
    const p = ms.page;
    if (p === 'title') return `<p class="kicker">Титул · замысел</p><h2>${esc(b.title)}</h2>
      <form class="card" data-form="msTitle"><label class="field"><span>Жанр</span><input id="ms-genre" value="${esc(b.genre)}"></label>
      <label class="field"><span>О чём</span><textarea id="ms-pitch">${esc(b.pitch)}</textarea></label>
      <div class="row"><label class="field"><span>Игроков</span><input id="ms-players" value="4" size="3"></label><label class="field"><span>Глав</span><input id="ms-chapters" value="${b.book.chapters.length}" size="3"></label></div>
      <button class="btn">Сохранить титул</button></form>`;
    if (p === 'contents') return `<p class="kicker">Оглавление</p><h2>Главы</h2><ol class="moments">${b.book.chapters.map((c, i) => `<li class="moment" style="grid-template-columns:34px 1fr auto"><b style="font-family:var(--f-display);font-size:20px">${c.number}</b><span><b>${esc(c.title)}</b><small>${c.pages.length} сцены</small></span>${i === 0 ? '<button class="btn" data-act="msPage" data-arg="chapter">Править</button>' : ''}</li>`).join('')}</ol><button class="btn quiet" data-act="say" data-arg="Новая глава добавляется в оглавление и открывается чистой страницей.">+ Глава</button>`;
    if (p === 'chapter') return `<p class="kicker">Глава 1 · ${esc(window.placeName ? (st.D.books.rc.entities.find((e) => e.key === ch.place)?.name || '') : '')}</p><h2>${esc(ch.pages[0].title)}</h2>
      <p class="voice">${ms.editing ? '<b>Правка на странице</b> — сохраняется сама' : 'Нажмите на текст, чтобы править'} · <span class="tag ok">сохранено · ревизия ${ms.saved}</span></p>
      <div class="read ms-edit" contenteditable="${ms.editing}" data-ms-edit role="textbox" aria-multiline="true" aria-label="Текст сцены" tabindex="0">${paras(ch.pages[0].text).map((t) => `<p>${esc(t)}</p>`).join('')}</div>
      <div class="row">${ms.editing ? '<button class="btn primary" data-act="msSave">Готово</button>' : '<button class="btn" data-act="msEdit">Править текст</button>'}</div>`;
    if (p === 'cast') return `<p class="kicker">Действующие лица</p><h2>Кто в этой книге</h2><ul class="grid-list">${b.entities.filter((e) => e.kind === 'npc').slice(0, 12).map((e) => `<li><span class="thumb">${st.img(e.picture)}<span>${esc(e.name)}</span></span></li>`).join('')}</ul>`;
    if (p === 'proposal') {
      const src = b.book.chapters[2].pages[0];
      return `<p class="kicker">Предложено генерацией · ${ms.proposal === 'unread' ? '<span class="tag warn">не прочитано</span>' : ms.proposal === 'accepted' ? '<span class="tag ok">принято</span>' : '<span class="tag bad">отклонено</span>'}</p>
        <h2>${esc(src.title)}</h2><p class="muted" style="font-size:13px;margin:0">В демо на месте предложенной страницы — текст главы 3 из исходника кампании, чтобы не показывать непрочитанный текст модели.</p>
        <div class="row"><button class="btn primary" data-act="msProposal" data-arg="accepted">Прочитал — вставить в книгу</button><button class="btn" data-act="msProposal" data-arg="refused">Отклонить</button></div>
        <div class="read proposal">${paras(src.text).slice(0, 2).map((t) => `<p>${esc(t)}</p>`).join('')}</div>`;
    }
    if (p === 'proof') {
      const line = ch.pages[0].check.line, m = ms.marks;
      const mark = (i, from, to) => m[i] === 'yes' ? `<ins>${esc(to)}</ins>` : m[i] === 'no' ? esc(from) : `<span class="proofmark"><del>${esc(from)}</del><ins>${esc(to)}</ins><span class="row"><button class="btn" data-act="msMark" data-arg="${i}:yes" aria-label="Принять правку">✓</button><button class="btn" data-act="msMark" data-arg="${i}:no" aria-label="Отказаться от правки">✗</button></span></span>`;
      const dc = line.match(/(DC|СЛ|Сл)\s?(\d+)/);
      const body = dc ? esc(line.slice(0, dc.index)) + mark(0, dc[0], `${dc[1]} ${+dc[2] + 1}`) + esc(line.slice(dc.index + dc[0].length)) : esc(line);
      return `<p class="kicker">Корректура</p><h2>Правки на полях</h2><p class="muted" style="margin:0">Правка помощника — пометка корректора: каждую можно принять или отказаться. Пример: сложность проверки сцены 1.</p>
        <div class="card"><p class="read" style="font-size:16px;margin:0">${body}</p></div>`;
    }
    if (p === 'plates') return `<p class="kicker">Иллюстрации</p><h2>Таблички книги</h2><ul class="grid-list">${b.entities.filter((e) => e.kind === 'location').slice(0, 8).map((e) => `<li><span class="thumb">${st.img(e.picture)}<span>${esc(e.name)}</span></span></li>`).join('')}</ul>`;
    if (p === 'compare') return `<p class="kicker">Сверка ревизий</p><h2>Ревизия ${ms.saved - 1} → ${ms.saved}</h2><div class="card"><p style="margin:0"><del>${esc(ch.title)}</del> <ins>${esc(ch.title)}</ins></p><p class="muted" style="margin:0">Изменён текст сцены 1 · одна правка корректуры.</p></div><button class="btn" data-act="say" data-arg="Вернуть старую ревизию — тоже правка, её можно отменить.">Вернуть ревизию ${ms.saved - 1}</button>`;
    return `<p class="kicker">Переплёт</p><h2>Проверка перед переплётом</h2>
      <ul class="moments"><li class="moment"><span class="tag ok">✓</span><span>Все главы на месте, ключи сходятся</span></li><li class="moment"><span class="tag ok">✓</span><span>У каждого места есть картинка</span></li>
      <li><label class="moment ack"><span class="tag warn">!</span><span>У двух людей нет голоса — играть так</span><input type="checkbox" id="w1" data-ack ${st.S.ms.ack ? 'checked' : ''}></label></li></ul>
      ${st.S.ms.bound ? '<p><span class="tag ok">Переплетено</span> Книга стоит на полке.</p>' : `<button class="btn primary" data-act="msBind" ${st.S.ms.ack ? '' : 'disabled'}>Переплести и поставить на полку</button>${st.S.ms.ack ? '' : '<p class="muted" style="margin:0">Переплёт откроется, когда все замечания приняты.</p>'}`}`;
  }
  ACT.msEdit = () => st.set((S) => { S.ms.editing = true; });
  ACT.msSave = () => st.set((S) => { S.ms.editing = false; S.ms.saved += 1; }, 'Рукопись: правка сохранена');
  ACT.msProposal = (v) => st.set((S) => { S.ms.proposal = v; }, v === 'accepted' ? 'Рукопись: страница вставлена' : 'Рукопись: страница отклонена');
  ACT.msMark = (arg) => st.set((S) => { const [i, v] = arg.split(':'); S.ms.marks[i] = v; });
  ACT.msBind = () => {
    st.set((S) => { S.ms.bound = true; }, 'Рукопись переплетена');
    st.say('Книга встала на полку.');
  };
  function right() {
    const ms = st.S.ms, b = B();
    if (ms.page === 'plates') return `<figure class="plate"><div class="plate-frame">${st.img(b.entities.find((e) => e.key === 'tram-depot')?.picture, 'Трамвайный парк')}</div><figcaption>Трамвайный парк</figcaption></figure>
      <div class="card"><h4>Новая иллюстрация</h4><label class="field"><span>Что на ней</span><input id="plate-what" value="Ворота трамвайного парка ночью"></label>
      ${ms.plates.asked ? (ms.plates.approved ? '<span class="tag ok">одобрено</span>' : '<p style="margin:0"><span class="tag warn">готов вариант</span></p><div class="row"><button class="btn primary" data-act="msPlate" data-arg="approve">Одобрить</button><button class="btn" data-act="msPlate" data-arg="redo">Ещё вариант</button></div>') : '<button class="btn" data-act="msPlate" data-arg="ask">Заказать иллюстрацию</button>'}</div>`;
    if (ms.page === 'title') return `<figure class="plate"><div class="plate-frame" style="height:auto;aspect-ratio:2/3;max-height:52vh">${st.img(b.cover, 'Обложка')}</div><figcaption>Обложка</figcaption></figure>`;
    if (ms.page === 'chapter') return `<p class="kicker">Поля страницы</p><div class="card"><h4>Сцена 1 — поля</h4><label class="field"><span>Минут</span><input id="m-min" value="${b.book.chapters[0].pages[0].minutes || 30}"></label><label class="field"><span>Проверка</span><textarea id="m-check">${esc(b.book.chapters[0].pages[0].check.line)}</textarea></label><label class="field"><span>Если не вышло</span><textarea id="m-fail">${esc(b.book.chapters[0].pages[0].failForward)}</textarea></label></div>
      <div class="card"><p style="margin:0"><span class="tag ok">свободно</span> Эту страницу правите только вы. Если откроете её во второй вкладке, она скажет, что страница занята.</p></div>`;
    return `<p class="kicker">Корректурный экземпляр</p><div class="card"><h4>Как это прочтёт мастер</h4><p style="margin:0">Рукопись в любой момент открывается как готовая книга мастера или книга героя — «в корректуре».</p><div class="row"><button class="btn" data-act="msProofDm">Открыть книгу мастера</button><button class="btn" data-act="msProofHero">Открыть книгу героя</button></div></div>`;
  }
  ACT.msPlate = (k) => st.set((S) => { if (k === 'ask' || k === 'redo') S.ms.plates.asked = true; if (k === 'approve') S.ms.plates.approved = true; });
  ACT.msProofDm = () => st.set((S) => { S.skin = 'rc'; S.view = 'dm'; });
  ACT.msProofHero = () => st.set((S) => { S.skin = 'rc'; S.view = 'hero'; });

  window.renderManuscript = () => {
    if (!st.S.ms.open) return desk();
    const ms = st.S.ms;
    return `<div class="desk"><div class="book ms-book" data-skin-ms>
      <div class="binding"><header class="head"><button class="where" data-act="msClose">← Мастерская</button><span>Рукопись: ${esc(B().title)}</span><span class="meet"><span class="tag ok" style="color:#bfe3c4">сохранено · ревизия ${ms.saved}</span></span></header>
        <div class="spread"><section class="page page-l scroll">${left()}</section><section class="page page-r scroll">${right()}</section></div>
        <footer class="foot"><img src="img/ui/rc-clip.webp" alt="" style="width:28px"><span>Рукопись сохраняется сама; отменить можно на странице «Сверка».</span></footer></div>
      <nav class="marks" aria-label="Части рукописи">${PAGES.map(([id, w]) => `<button class="mark" data-act="msPage" data-arg="${id}" ${ms.page === id ? 'aria-current="true"' : ''}>${w}${id === 'proposal' && ms.proposal === 'unread' ? '<span class="wait" aria-label="не прочитано"></span>' : ''}</button>`).join('')}</nav></div></div>`;
  };
  window.CHANGE = window.CHANGE || {};
  window.CHANGE.ack = (el) => st.set((S) => { S.ms.ack = el.checked; });
  window.FORMS = window.FORMS || {};
  window.FORMS.msTitle = () => st.set((S) => { S.ms.saved += 1; }, 'Рукопись: титул сохранён');
})();
