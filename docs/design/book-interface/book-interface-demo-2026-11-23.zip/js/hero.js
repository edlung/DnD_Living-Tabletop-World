// The hero's book, phone first: one page a screen, five bookmarks at the bottom, the dice at the
// foot, slips for what the DM sent. It shows only the player's own projection: no DM text, no DC.
(function () {
  const st = window.store, { esc, by } = st;
  const ACT = (window.ACT = window.ACT || {});
  const PARTS = [['scene', 'Сцена'], ['hero', 'Герой'], ['world', 'Мир'], ['journal', 'Журнал'], ['table', 'За столом']];
  // Whose book: the one chosen, else the hero the DM is waiting on, else the first of the party.
  const heroKey = () => {
    const S = st.S, party = st.data().party;
    if (S.hero.key && party.includes(S.hero.key)) return S.hero.key;
    return S.asks.find((a) => a.status === 'open' && a.skin === S.skin)?.hero || party[0];
  };

  function page() {
    const S = st.S, b = st.book(), D = st.data(), k = heroKey(), e = st.ent(k), part = S.hero.part;
    const place = st.ent(b.place);
    if (part === 'scene') {
      const people = D.entities.filter((x) => x.kind === 'npc' && x.placement?.location === b.place);
      return `<p class="kicker">${st.hhmm(b.time)} · ${esc(st.weatherWord(b.weather))}</p><h2>${esc(place?.name)}</h2>
        ${place?.picture ? `<img class="hero-plate" src="${place.picture}" alt="${esc(place.name)}">` : ''}
        <p class="read">${esc(place?.description)}</p>
        <h3>Здесь</h3><ul class="moments">${people.map((p) => `<li><button class="moment link" style="width:100%;border-bottom:0;text-align:left" data-act="say" data-arg="Разговор: что спросить — темы, которые герой знает.">${st.img(p.picture, '', 'avatar')}<span><b>${esc(p.name)}</b><small>Поговорить</small></span>›</button></li>`).join('') || '<li class="muted">Никого.</li>'}</ul>
        <div class="row"><button class="btn" data-act="say" data-arg="Осмотреть: мир отвечает тем, что герой видит.">Осмотреться</button><button class="btn" data-act="say" data-arg="«Что я могу сделать?» — подсказка хода.">Что я могу?</button></div>`;
    }
    if (part === 'hero') {
      const sh = e.sheet, h = b.heroes[k];
      return `<div class="row" style="flex-wrap:nowrap">${st.img(e.picture, '', 'portrait')}<div><h2>${esc(e.name)}</h2><p class="muted" style="margin:0">${st.classWords(sh)} · КД ${sh.armorClass}</p></div></div>
        <p class="tabnum" style="margin:6px 0 0">Хиты ${h.hp} / ${sh.hitPoints.max}</p><span class="hp" style="--p:${Math.round((100 * h.hp) / sh.hitPoints.max)}%"><span></span></span>
        <div class="abilities">${Object.entries(sh.abilities).map(([a, v]) => `<button class="ab" data-act="heroRoll" data-arg="ability:${a}"><small>${st.abilities[a].slice(0, 3)}</small><b>${st.sign(st.mod(v))}</b><span>${v}</span></button>`).join('')}</div>
        <h3>Навыки — нажмите, чтобы бросить</h3><div class="row">${sh.skills.proficient.map((s) => `<button class="btn" data-act="heroRoll" data-arg="skill:${s}">${st.skills[s]?.[0]} ${st.sign(st.bonus(k, { kind: 'skill', skill: s }))}</button>`).join('')}</div>
        <h3>Снаряжение</h3><p style="margin:0">${st.weaponWords(sh)}</p><p class="muted" style="margin:0">${D.possessions.filter((p) => p.holder === k).map((p) => esc(st.ent(p.item)?.name || p.catalog)).join(', ')}</p>
        <div class="row"><button class="btn quiet" data-act="say" data-arg="История героя: его прошлое и цели, видит игрок и мастер.">История героя</button><button class="btn quiet" data-act="say" data-arg="Новый уровень: выбор в этой же книге, по шагам.">Новый уровень</button></div>`;
    }
    if (part === 'world') {
      const known = D.entities.filter((x) => x.kind === 'location').slice(0, 6);
      return `<h2>Мир</h2>${D.worldMap ? `<img class="hero-plate" src="${D.worldMap}" alt="Карта мира">` : ''}
        <h3>Места, где мы были</h3><ul class="grid-list">${known.map((l) => `<li><span class="thumb">${st.img(l.picture)}<span>${esc(l.name)}</span></span></li>`).join('')}</ul>`;
    }
    if (part === 'journal') {
      const hs = b.handouts.map((h) => by(D.book.handouts, h));
      const clues = b.found.map((c) => by(D.book.clues, c));
      return `<h2>Журнал</h2><h3>Раздатки</h3>${hs.map((h) => `<div class="card"><h4>${esc(h.title)}</h4><p class="read" style="font-size:16px;margin:0;white-space:pre-line">${esc(h.text)}</p></div>`).join('') || '<p class="muted">Мастер ещё ничего не дал.</p>'}
        <h3>Что мы знаем</h3>${clues.map((c) => `<p style="margin:0 0 6px"><b>${esc(c.name)}.</b> ${esc(c.statement)}</p>`).join('') || '<p class="muted">Пока ничего.</p>'}
        <button class="btn quiet" data-act="say" data-arg="Хроника отряда: главы, которые мастер написал после встреч.">Хроника</button>`;
    }
    return `<h2>Стол</h2><div class="card"><h4>Встреча</h4><p style="margin:0">${S.meeting.state === 'open' ? (S.meeting.paused ? 'Пауза' : 'Идёт') : S.meeting.state === 'ended' ? 'Закрыта' : 'Ещё не началась'}</p>
        <div class="row"><button class="btn" data-act="say" data-arg="Просьба о паузе уходит мастеру без имени, если вы так решите.">Попросить паузу</button><button class="btn" data-act="say" data-arg="Похвала товарищу: видна на экране стола.">Похвалить</button></div></div>
      <h3>Разговор</h3><ol class="chat">${S.chat.slice(-4).map((c) => `<li><b>${esc(c.who)}:</b> ${esc(c.text)}</li>`).join('')}</ol>
      <div class="row"><button class="btn quiet" data-act="say" data-arg="Размер текста: обычный или крупный.">Размер текста</button><button class="btn quiet" data-act="say" data-arg="Договор стола: что мы обещали друг другу.">Договор стола</button></div>`;
  }

  ACT.heroRoll = (arg) => {
    const [kind, what] = arg.split(':'), k = heroKey();
    const check = kind === 'skill' ? { kind: 'skill', skill: what } : { kind: 'ability', ability: what };
    const roll = st.d(20), total = roll + st.bonus(k, check);
    st.set(() => { st.book().rolls.unshift({ total, what: `${st.checkWord(check)} (${roll}${st.sign(total - roll)})`, by: k }); }, `${st.ent(k).name.split(' ')[0]} бросает: ${st.checkWord(check)} = ${total}`);
  };
  ACT.answer = (id) => {
    const a = st.S.asks.find((x) => x.id === id), roll = st.d(20);
    st.set(() => { a.status = 'answered'; a.roll = roll; a.total = roll + st.bonus(a.hero, a.check); st.book().rolls.unshift({ total: a.total, what: st.checkWord(a.check) }); },
      `${st.ent(a.hero).name.split(' ')[0]} ответил на бросок: ${a.roll}`);
    st.say('Ответ ушёл мастеру: записка у подножия его страницы.');
  };
  ACT.heroPart = (p) => st.set((S) => { S.hero.part = p; });
  ACT.heroWho = (k) => st.set((S) => { S.hero.key = k; });

  window.renderHero = (mini) => {
    const S = st.S, b = st.book(), k = heroKey();
    const asks = S.asks.filter((a) => a.status === 'open' && a.hero === k && a.skin === S.skin);
    const given = b.handouts.length;
    const last = b.rolls.find((r) => r.by === k) || null;
    return `<div class="phone"><div class="phone-screen">
      <header class="phone-head"><span>${esc(window.placeName(b.place))}</span><span>${st.hhmm(b.time)}</span></header>
      <main class="phone-page">${asks.map((a) => `<div class="slip big" role="alert"><img src="${window.icoSrc('puzzle').replace('puzzle', 'talk')}" alt=""><span><b>Мастер просит бросок</b><br>${esc(st.checkWord(a.check))} ${st.sign(st.bonus(k, a.check))}</span><button class="btn primary" data-act="answer" data-arg="${a.id}">Бросить d20</button></div>`).join('')}
        ${page()}</main>
      <div class="phone-dice"><span>Кубики</span>${[20, 6, 8].map((n) => `<button class="die" data-act="roll" data-arg="${n}">d${n}</button>`).join('')}<span class="rolled">${last ? last.total : b.rolls[0]?.total ?? '—'}</span></div>
      <nav class="phone-marks" aria-label="Части книги героя">${PARTS.map(([id, w]) => `<button data-act="heroPart" data-arg="${id}" ${S.hero.part === id ? 'aria-current="true"' : ''}><img src="${st.icon(id === 'hero' ? 'hero' : id)}" alt="">${w}${id === 'journal' && given ? '<span class="wait"></span>' : ''}</button>`).join('')}</nav>
    </div></div>`;
  };
  window.renderHeroView = () => {
    const D = st.data(), k = heroKey();
    return `<div class="stage-phone"><div class="stage-note"><p class="kicker" style="color:var(--bar-muted)">Книга героя · так на телефоне игрока</p>
      <h2 style="margin:0;font-family:var(--f-display);font-size:30px">${esc(st.ent(k).name)}</h2>
      <p>Пять закладок внизу, кубики у подножия, записки от мастера — сверху страницы. Игрок видит только то, что видит его герой: ни текста мастера, ни сложности броска.</p>
      <label class="field" style="color:var(--bar-fg)"><span style="color:var(--bar-muted)">Чья книга</span><select id="hero-who" data-hero-who class="btn">${D.party.map((h) => `<option value="${h}" ${h === k ? 'selected' : ''}>${esc(st.ent(h).name)}</option>`).join('')}</select></label>
      <p style="color:var(--bar-muted);font-size:14px">Попробуйте: в книге мастера — «История», сцена с проверкой, «Попросить бросок»; здесь появится записка.</p></div>${window.renderHero()}</div>`;
  };
  window.CHANGE = window.CHANGE || {};
  window.CHANGE.heroWho = (el) => ACT.heroWho(el.value);
})();
