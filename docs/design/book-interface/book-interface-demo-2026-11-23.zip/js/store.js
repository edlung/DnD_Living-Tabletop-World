// One state shared by every frame of the demo: what the DM does in his book reaches the hero's
// book, the table's book and the colophon. Demo only — the product keeps all of this in the World
// Engine and its projections; nothing here is a rule.
(function () {
  const D = window.DATA;
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const paras = (t) => String(t ?? '').split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const by = (arr, key) => (arr || []).find((x) => x.key === key);

  function freshBook(skin) {
    const B = D.books[skin];
    const ent = Object.fromEntries(B.entities.map((e) => [e.key, e]));
    const heroes = B.party.map((k) => {
      const e = ent[k];
      return { key: k, hp: e.sheet.hitPoints.current, conditions: [] };
    });
    return {
      skin, part: 'story', page: { chapter: 0, leaf: 0, sub: 0 }, ribbon: { chapter: 0, leaf: 0 },
      played: [], notes: {}, card: null, place: B.world.startLocation, selected: null,
      heroes: Object.fromEntries(heroes.map((h) => [h.key, h])), found: [], handouts: [],
      time: B.world.startsAt, weather: B.world.weather, cast: { kind: 'cover' },
      fight: null, rolls: [], partPage: {}, added: [],
    };
  }

  const S = {
    view: 'shelf', skin: 'lh', signedIn: false, toast: null, toastAt: 0,
    books: { lh: freshBook('lh'), rc: freshBook('rc'), mc: freshBook('mc') },
    meeting: { state: 'closed', startedAt: null, paused: false, breakAt: 45 },
    asks: [], // rolls the DM asked of a hero: {id, hero, check, dc, group, status, total}
    chat: [{ who: 'Тэс', text: 'Я возьму пирог с собой, можно?' }], unreadDm: 1,
    colophon: [], hero: { key: null, part: 'scene', sheetTab: 'overview' },
    shelf: { open: null, mine: ['lighthouse', 'rain-check', 'hollowmere'] },
    ms: { open: false, page: 'title', proposal: 'unread', marks: { 0: null, 1: null }, bound: false, saved: 14, editing: false, plates: { asked: false, approved: false } },
    az: { filter: 'all', q: '' },
  };

  const listeners = [];
  const store = {
    S, D, esc, paras, by,
    book: () => S.books[S.skin],
    data: () => D.books[S.skin],
    ent: (key) => D.books[S.skin].entities.find((e) => e.key === key),
    on: (fn) => listeners.push(fn),
    set(mut, note) {
      mut(S);
      if (note) {
        S.colophon.unshift({ at: clock(), what: note, skin: S.skin, undo: note.undo || null });
        if (typeof note === 'string') S.colophon[0].what = note;
      }
      listeners.forEach((fn) => fn());
    },
    say(text) {
      S.toast = text; S.toastAt = Date.now();
      listeners.forEach((fn) => fn());
      setTimeout(() => { if (Date.now() - S.toastAt >= 2400) { S.toast = null; listeners.forEach((fn) => fn()); } }, 2500);
    },
    hhmm(sec) {
      const m = Math.floor(sec / 60) % (24 * 60);
      return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
    },
    d: (n) => 1 + Math.floor(Math.random() * n),
    mod: (score) => Math.floor((score - 10) / 2),
    sign: (n) => (n >= 0 ? `+${n}` : `${n}`),
    img: (src, alt = '', cls = '') => (src ? `<img src="${esc(src)}" alt="${esc(alt)}" class="${cls}" loading="lazy">` : ''),
    icon: (part) => `img/ui/${['lh', 'rc', 'mc'].includes(S.skin) && part !== 'fight' ? S.skin : 'ltw'}-part-${part}.webp`,
  };
  function clock() {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
  store.weatherWord = (w) => ({ clear: 'ясно', rain: 'дождь', storm: 'гроза', fog: 'туман', snow: 'снег', cloudy: 'облачно', wind: 'ветер' })[w] || w;
  store.skills = {
    athletics: ['Атлетика', 'str'], acrobatics: ['Акробатика', 'dex'], sleight_of_hand: ['Ловкость рук', 'dex'], stealth: ['Скрытность', 'dex'],
    arcana: ['Магия', 'int'], history: ['История', 'int'], investigation: ['Анализ', 'int'], nature: ['Природа', 'int'], religion: ['Религия', 'int'],
    animal_handling: ['Уход за животными', 'wis'], insight: ['Проницательность', 'wis'], medicine: ['Медицина', 'wis'], perception: ['Внимательность', 'wis'], survival: ['Выживание', 'wis'],
    deception: ['Обман', 'cha'], intimidation: ['Запугивание', 'cha'], performance: ['Выступление', 'cha'], persuasion: ['Убеждение', 'cha'],
  };
  const CLASSES = { fighter: 'воин', rogue: 'плут', wizard: 'волшебник', cleric: 'жрец', ranger: 'следопыт', bard: 'бард', druid: 'друид', paladin: 'паладин', barbarian: 'варвар', monk: 'монах', sorcerer: 'чародей', warlock: 'колдун' };
  const WEAPONS = { longsword: 'длинный меч', handaxe: 'ручной топор', quarterstaff: 'боевой посох', dagger: 'кинжал', shortsword: 'короткий меч', shortbow: 'короткий лук', longbow: 'длинный лук', mace: 'булава', spear: 'копьё', 'light-crossbow': 'лёгкий арбалет', light_crossbow: 'лёгкий арбалет', rapier: 'рапира', sling: 'праща', club: 'дубинка', javelin: 'метательное копьё', greataxe: 'секира', warhammer: 'боевой молот', scimitar: 'скимитар', 'hand-crossbow': 'ручной арбалет', battleaxe: 'боевой топор', greatsword: 'двуручный меч', flail: 'цеп', whip: 'кнут', unarmed: 'без оружия' };
  store.classWords = (sh) => sh.classes.map((c) => `${CLASSES[c.classId] || c.classId}, ${c.level} ур.`).join(' · ');
  store.weaponWords = (sh) => sh.weapons.map((w) => WEAPONS[w] || w.replace(/[-_]/g, ' ')).join(', ');
  store.abilities = { str: 'Сила', dex: 'Ловкость', con: 'Телосложение', int: 'Интеллект', wis: 'Мудрость', cha: 'Харизма' };
  store.checkWord = (c) => {
    if (!c) return '';
    if (c.kind === 'skill' || c.skill) return store.skills[c.skill]?.[0] || c.skill;
    if (c.kind === 'save') return `спасбросок: ${store.abilities[c.ability] || c.ability}`;
    return store.abilities[c.ability] || c.ability || '';
  };
  store.bonus = (heroKey, check) => {
    const e = store.ent(heroKey);
    if (!e?.sheet) return 0;
    const sh = e.sheet, lvl = sh.classes.reduce((a, c) => a + c.level, 0), prof = 2 + Math.floor((lvl - 1) / 4);
    if (check?.skill || check?.kind === 'skill') {
      const sk = check.skill, ab = store.skills[sk]?.[1] || 'wis';
      return store.mod(sh.abilities[ab]) + (sh.skills.proficient.includes(sk) ? prof : 0) + (sh.skills.expertise.includes(sk) ? prof : 0);
    }
    if (check?.kind === 'save') return store.mod(sh.abilities[check.ability]) + (sh.savingThrows.includes(check.ability) ? prof : 0);
    return store.mod(sh.abilities[check?.ability || 'wis']);
  };
  window.store = store;
})();
