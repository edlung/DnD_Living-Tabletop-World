// The demo's frame: which book is open, which campaign, one render, one set of event handlers.
(function () {
  const st = window.store, { esc } = st;
  const ACT = window.ACT, FORMS = window.FORMS, CHANGE = window.CHANGE;
  const VIEWS = [['shelf', 'Полка'], ['dm', 'Книга мастера'], ['hero', 'Книга героя'], ['table', 'Экран стола'], ['manuscript', 'Мастерская'], ['az', 'А–Я']];
  const BOOKS = [['lh', 'Маяк'], ['rc', 'Дождь'], ['mc', 'Корона']];
  const root = document.getElementById('app');

  ACT.view = (v) => st.set((S) => { S.view = v; S.shelf.open = null; if (v !== 'shelf' && !S.signedIn) S.signedIn = true; });
  ACT.skin = (k) => st.set((S) => { S.skin = k; });

  function skinOf() {
    const S = st.S;
    if (S.view === 'shelf' || S.view === 'az') return 'ltw';
    if (S.view === 'manuscript') return S.ms.open ? 'rc' : 'ltw';
    return S.skin;
  }
  function bar() {
    const S = st.S, campaign = ['dm', 'hero', 'table'].includes(S.view);
    return `<header class="demo-bar"><span class="demo-mark"><img src="img/ui/ltw-emblem.webp" alt="">Книги стола</span>
      <nav class="demo-views" aria-label="Книги">${VIEWS.map(([id, w]) => `<button data-act="view" data-arg="${id}" ${S.view === id ? 'aria-current="page"' : ''}>${w}</button>`).join('')}</nav>
      ${campaign ? `<div class="demo-books" role="group" aria-label="Кампания"><span>Кампания:</span>${BOOKS.map(([id, w]) => `<button data-act="skin" data-arg="${id}" aria-pressed="${S.skin === id}">${w}</button>`).join('')}</div>` : ''}</header>`;
  }
  function view() {
    const v = st.S.view;
    if (v === 'shelf') return window.renderShelf();
    if (v === 'dm') return window.renderDm();
    if (v === 'hero') return window.renderHeroView();
    if (v === 'table') return window.renderTableView();
    if (v === 'manuscript') return window.renderManuscript();
    return window.renderAz();
  }
  function dialog() {
    const d = st.S.dialog;
    if (!d) return '';
    return `<div class="dlg" role="dialog" aria-label="Картинка крупно"><div class="dlg-box"><img src="${esc(d.src)}" alt=""><button class="btn" data-act="closeDialog">Закрыть</button></div></div>`;
  }

  let lastFocus = null;
  function render() {
    const active = document.activeElement;
    lastFocus = active && active !== document.body ? (active.id ? `#${active.id}` : active.dataset.act ? `[data-act="${active.dataset.act}"][data-arg="${CSS.escape(active.dataset.arg || '')}"]` : null) : null;
    const scrolls = [...root.querySelectorAll('.scroll, .scroll-y')].map((e) => e.scrollTop);
    document.documentElement.dataset.skin = skinOf();
    root.innerHTML = `<div class="app">${bar()}<main class="view" data-view="${st.S.view}">${view()}${dialog()}${st.S.toast ? `<p class="toast" role="status">${esc(st.S.toast)}</p>` : ''}</main></div>`;
    [...root.querySelectorAll('.scroll, .scroll-y')].forEach((e, i) => { if (scrolls[i]) e.scrollTop = scrolls[i]; });
    if (lastFocus) { try { root.querySelector(lastFocus)?.focus({ preventScroll: true }); } catch { /* gone */ } }
    paginate();
  }
  // The story's text turns instead of scrolling: columns as wide as the page, one shown at a time.
  function paginate() {
    const flow = root.querySelector('[data-flow]');
    if (!flow) return;
    const inner = flow.firstElementChild, w = flow.clientWidth, gap = 48;
    if (!w || window.matchMedia('(max-width: 900px)').matches) { flow.dataset.subs = 1; return; }
    inner.style.columnWidth = `${w}px`; inner.style.columnGap = `${gap}px`; inner.style.height = `${flow.clientHeight}px`;
    const subs = Math.max(1, Math.round((inner.scrollWidth + gap) / (w + gap)));
    const sub = Math.min(st.book().page.sub || 0, subs - 1);
    flow.dataset.subs = subs; flow.dataset.sub = sub;
    inner.style.transform = `translateX(${-sub * (w + gap)}px)`;
    const folio = root.querySelector('[data-folio]');
    if (folio && subs > 1) folio.textContent += ` · экран ${sub + 1} из ${subs}`;
  }

  root.addEventListener('click', (ev) => {
    const el = ev.target.closest('[data-act]');
    if (!el || el.disabled) return;
    const fn = ACT[el.dataset.act];
    if (fn) { ev.preventDefault(); fn(el.dataset.arg || '', el); }
  });
  root.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const fn = FORMS[ev.target.dataset.form];
    if (fn) fn(ev.target);
  });
  root.addEventListener('change', (ev) => {
    const t = ev.target;
    if (t.matches('[data-weather]')) CHANGE.weather(t);
    if (t.matches('[data-hero-who]')) CHANGE.heroWho(t);
    if (t.matches('[data-ack]')) CHANGE.ack(t);
  });
  root.addEventListener('input', (ev) => {
    if (ev.target.matches('[data-note]')) CHANGE.note(ev.target);
    if (ev.target.matches('[data-rule-q]')) {
      const q = ev.target.value.trim().toLowerCase();
      root.querySelectorAll('[data-rule-index] li').forEach((li) => { li.hidden = q !== '' && !li.textContent.toLowerCase().includes(q); });
    }
  });
  document.addEventListener('keydown', (ev) => {
    if (ev.key !== 'Escape') return;
    const S = st.S, b = st.book();
    if (S.dialog) ACT.closeDialog();
    else if (S.shelf.open) ACT.unpeek();
    else if (b.mapOpen) ACT.unmap();
    else if (b.card) ACT.uncard();
  });
  window.addEventListener('resize', () => { clearTimeout(window.__rz); window.__rz = setTimeout(render, 120); });
  // The meeting's clock in the running head.
  setInterval(() => { if (st.S.meeting.state === 'open' && st.S.view === 'dm' && !root.contains(document.activeElement?.closest('textarea,input'))) render(); }, 30000);
  // A view worth sending: #shelf, #dm, #hero, #table, #manuscript, #az (and #lh, #rc, #mc for the campaign).
  function fromHash() {
    const h = location.hash.slice(1);
    if (VIEWS.some(([id]) => id === h)) st.set((S) => { S.view = h; if (h !== 'shelf') S.signedIn = true; });
    if (BOOKS.some(([id]) => id === h)) st.set((S) => { S.skin = h; S.view = 'dm'; S.signedIn = true; });
  }
  window.addEventListener('hashchange', fromHash);
  st.on(render);
  render();
  fromHash();
})();
